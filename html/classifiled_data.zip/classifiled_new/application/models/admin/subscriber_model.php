<?php
class Subscriber_model extends CI_Model {
	
	function insert(){
		$insertArray['title'] = $this->input->post('title');
		$insertArray['subject'] = $this->input->post('subject');
		$insertArray['description'] = $this->input->post('description');
		
		$this->db->insert('tbl_newsletter_subscriber', $insertArray);        
		return $this->db->insert_id();
	}

	function doActionPages(){		
		if($this->input->post('action')){
			$checkbox = $this->input->post('chk');	
			for($i=0;$i<count($checkbox);$i++){
				if($this->input->post('action') == 'Active' || $this->input->post('action') == 'Inactive'){
					$data=array('status' =>	$this->input->post('action'));
					$this->db->where('id', $checkbox[$i]);
					$this->db->update('tbl_newsletter_subscriber',$data);
					$this->session->set_flashdata('actionmsg', 'Status successfully changed.');
				}
				if($this->input->post('action') == 'Delete'){
					$this->db->delete('tbl_newsletter_subscriber', array('id' => $checkbox[$i]));
					$this->session->set_flashdata('actionmsg', 'Newsletter Email Template successfuly removed.');										
				}
			}
			
			redirect(base_url().'admin/banner/lists/'.$this->uri->rsegment(3));
		}
	}
	
	function dataCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
		 	$this->db->like('email',$key);		
	 	}
		if($skey){
			if(in_array($skey,searchkey())){
				$this->db->like('email',$skey,'after');
			}else if($skey == 'active' ||$skey == 'inactive' ) {
				$status = ($skey == '1') ? '1' : '0'; 
				$this->db->where('status',$status);
				$this->session->set_userdata('status', $skey);
			}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == '1') ? '1' : '0';
			$this->db->where('status',$status);
		}	
      	$query = $this->db->get('tbl_newsletter_subscriber');
      	return $query->num_rows(); 
    }
		
	function getAll($limit=null, $start=null,$skey=null){
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('email',$key);			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('email',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("email", $this->uri->segment(4)); 
		}
		$this->db->where('isDeleted','0');
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_newsletter_subscriber');
		//echo $this->db->last_query();
		return $query->result_array();
    }
}
?>