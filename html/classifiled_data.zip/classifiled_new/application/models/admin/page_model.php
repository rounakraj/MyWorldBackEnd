<?php
class Page_model extends CI_Model {
	
	################# Create unique Slug #################
	
	public function create_unique_slug($string, $table)
	{
		$slug = url_title($string);
		$slug = strtolower($slug);
		$i = 0;
		$params = array ();
		$params['slug'] = $slug;
		if ($this->input->post('id')) {
			$params['id !='] = $this->input->post('id');
		}
		
		while ($this->db->where($params)->get($table)->num_rows()) {
			if (!preg_match ('/-{1}[0-9]+$/', $slug )) {
				$slug .= '-' . ++$i;
			} else {
				$slug = preg_replace ('/[0-9]+$/', ++$i, $slug );
			}
			$params ['slug'] = $slug;
			}
		return $slug;
	}  
	
	################# Duplicate enter check #################
	
	public function duplicate_check($string,$field,$table)
	{
		$params = array();
		$params[$field] = $string;
		return $this->db->where($params)->get($table)->num_rows();
	}	
	
	################# Add New Page #################	
	
	function addNew()
	{
		$data=array(
			'page_title'		=>	$this->input->post('page_title'),
			'page_heading'		=>	$this->input->post('page_heading'),
			'meta_keywords'		=>	$this->input->post('meta_keywords'),
			'slug'				=>	$this->create_unique_slug($this->input->post('page_title'),'tbl_pages'),
			'meta_description'	=>	$this->input->post('meta_description'),
			'parent_page'		=>	$this->input->post('parent_page'),
			'page_content'		=>	$this->input->post('page_content'),
			'page_type'			=>	'dynamic',
			'display_on'		=>	$this->input->post('display_on'),
			'status'			=>	'Active'
		);
			
		if($this->duplicate_check($this->input->post('page_title'),'page_title','tbl_pages')>0){			
			return false;
		}
		else
		{
			$this->db->insert('tbl_pages',$data);
			return true;
		}		
	}
	
	################# Edit Page #################	
	
	function editPage($page_id)
	{
		$data=array(
			'page_title'		=>	$this->input->post('page_title'),
			'page_heading'		=>	$this->input->post('page_heading'),
			'meta_keywords'		=>	$this->input->post('meta_keywords'),	
			'meta_description'	=>	$this->input->post('meta_description'),
			'parent_page'		=>	$this->input->post('parent_page'),
			'page_content'		=>	$_POST['page_content'],
			'page_type'			=>	'dynamic',
			'display_on'		=>	$this->input->post('display_on'),
			'status'			=>	'1'
		);
		$this->db->where('id', $page_id);
		$this->db->update('tbl_pages',$data);
		return true;
	}
	################# Delete Page #################	
	function deletePage($id)
	{
		$this->db->delete('tbl_pages', array('id' => $id));
	}
		
	############################### Bulk Delete/Active/Inactive Member ###############################
	function doActionPages(){		
		if($this->input->post('action')){
			$checkbox = $this->input->post('chk');	
			for($i=0;$i<count($checkbox);$i++){
				if($this->input->post('action') == 'Active' || $this->input->post('action') == 'Inactive'){
					$data=array('status' =>	$this->input->post('action'));
					$this->db->where('id', $checkbox[$i]);
					$this->db->update('tbl_pages',$data);
					$this->session->set_flashdata('actionmsg', 'Status successfully changed.');
				}
				if($this->input->post('action') == 'Delete'){
					$this->db->delete('tbl_pages', array('id' => $checkbox[$i]));
					$this->session->set_flashdata('actionmsg', 'Page successfuly removed.');										
				}
			}
			$adminfolder = $this->Common_model->getValue('master_settings','admin_folder',array('id'=>1));
			redirect(base_url().$adminfolder.'/pages/all-pages/'.$this->uri->rsegment(3));
		}
	}
	function pageCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('page_title',$key);
			$this->db->or_like('page_content',$key);  
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('page_title',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? '1' : '0';
			$this->db->where('status',$status);
		}	
		
		
	  	
      	$query = $this->db->get('tbl_pages');
      	return $query->num_rows(); 
    }
	
	 function pageGetAll($limit=null, $start=null,$skey=null){
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('page_title',$key);
			$this->db->or_like('page_content',$key);  
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('page_title',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'Active' : 'Inactive'; 
					//$status = $skey;
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("page_title", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("order","ASC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_pages');
		//echo $this->db->last_query();
		return $query->result_array();
    }
	
	function getPageMenu($display_on = 1){
		
		$this->db->select('id,page_title,page_heading,slug,parent_page');
		$where = array('status' => 'Active', 'display_on' => $display_on );
		$this->db->where($where);
		$this->db->from('tbl_pages');
		$query = $this->db->get();
		return $query->result_array();
		
		
	}	
	
}
?>