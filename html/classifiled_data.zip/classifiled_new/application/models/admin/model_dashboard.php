<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_dashboard extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}
	
   
    /*---------------Administrator general Start--------------------*/
	function admin_val()
	{
		
        $this->load->database();
        $query=$this->db->query("select * from tbl_option_value");
        return $query->row_array();
	
	}
    
    function option_val($email,$title,$keyword,$description)
    {
        $this->load->database();
        $data = array(
          'global_meta_title'=>$title,
          'global_meta_keywords'=>$keyword,
          'global_meta_description'=>$description,
          'email'=>$email
        );
        
        $this->db->where('id',1);
        $this->db->update('tbl_option_value',$data);  
        return 1;
    
    }
    /*---------------Administrator general End--------------------*/

   /*---------------Administrator settings Start--------------------*/
	function admin_data_val()
    {
        
        $this->load->database();
        $query=$this->db->query("select * from tbl_admin");
        return $query->row_array();
    
    }
    /*Admin info start*/
    function admin_info($fname,$lname,$uname)
    {
        $this->load->database();
        $data = array(
          'fname'=>$fname,
          'lname'=>$lname,
          'admin_user'=>$uname
        );
        
        $this->db->where('admin_id',1);
        $this->db->update('tbl_admin',$data);  
        return 1;
    
    }
    /*Admin info end*/
    /*Admin password start*/
    function admin_pass($npass)
    {
        $this->load->database();
        $data = array(
          'admin_pass'=>$npass
        );
        
        $this->db->where('admin_id',1);
        $this->db->update('tbl_admin',$data);  
        return 1;
    
    }
    /*Admin password end*/
    /*---------------Administrator settings End--------------------*/
    /*---------------Static Page settings start--------------------*/
    function get_static_page_value($id){
    $this->load->database();
    //$query = $this->db->get_where('tbl_static_page',array('id'=>$id));
    //return $query->row_array(); 
     $query=$this->db->query("select * from tbl_static_page where id=$id");
     return $query->row_array();
   
    }
    
    function static_page($keyword,$description,$title,$id)
    {
        $this->load->database();
        $data = array(
          'link_name'=>$title,
          'keyword'=>$keyword,
          'description'=>$description,
        );
        
        $this->db->where('id',$id);
        $this->db->update('tbl_static_page',$data);  
        return 1;
    
    }
   /*---------------Static Page settings End--------------------*/
}

/* End of file model_login.php */
/* Location: ./application/models/model_login.php */