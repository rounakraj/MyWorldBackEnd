<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_email_template extends CI_Model {

	function __construct(){
		parent::__construct();
	}
	
	function emailTemplateCount($skey=null){
    
	/***************  Search Key Setting ***********************/
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}
				
		 	$this->db->like('title',$key);
			$this->db->or_like('subject',$key);
			$this->db->or_like('message',$key);   
	 	}
		else  if($skey){
				$this->db->like('title',$skey,'after');
				
		}	
		/***************  Search Key Setting ***********************/
		
      	$query = $this->db->get('tbl_email_notification');
		return $query->num_rows(); 
    }
    function emailTemplateGetAll($limit=null, $start=null,$skey=null){
		
		/***************  Search Key Setting ***********************/
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}
				
		 	$this->db->like('title',$key);
			$this->db->or_like('subject',$key);
			$this->db->or_like('message',$key);   
	 	}
		else  if($skey){
				$this->db->like('title',$skey,'after');
				
		}	
		/***************  Search Key Setting ***********************/
		$this->db->order_by("rank",'ASC'); 
		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("title", $this->uri->segment(4)); 
		}
    																   
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_email_notification');
		return $query->result_array();
    }	
}

/* End of file model_login.php */
/* Location: ./application/models/model_login.php */