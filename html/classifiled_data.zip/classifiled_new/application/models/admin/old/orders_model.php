<?php
class Orders_model extends CI_Model {
	
	function getAllOrders($user_id){
		$this->db->select('O.id,O.invoice,O.transaction_id,O.payment_status,O.order_status,O.order_date,OD.category,OD.image,OD.qty,OD.price,OD.size');
		$this->db->from('tbl_order O');
		$this->db->join('tbl_order_detail OD','O.id = OD.order_id','LEFT');
		$this->db->where('O.user_id',$user_id);
		$query = $this->db->get();
		return $query->result_array();
	}	
}
?>