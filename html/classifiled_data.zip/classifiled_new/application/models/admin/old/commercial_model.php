<?php
class Commercial_model extends CI_Model {
	
	function insert(){
		$insertArray['title'] = $this->input->post('title');
		if($_FILES)
			$uploadedPhoto = $this->moveFiles();
		if(isset($uploadedPhoto) && !empty($uploadedPhoto)){
			foreach($uploadedPhoto as $row){
				$insertArray['image'] = $row['img'];
				$this->db->insert('tbl_commercial', $insertArray);        
			}
			return $this->db->insert_id();
		}			
	}

	function moveFiles(){
		$image_name ='';		
		$total_image = count($_FILES['commercial']['name']);
		if($total_image > 0){
			for($i=0; $i < $total_image; $i++){
				$dest = '';
				$temp = explode(".",$_FILES['commercial']['name'][$i]);
				$file_name = mt_rand() . '.' .end($temp);				
				$dest = "uploads/commercial/".$file_name;
				$temp_name = $_FILES['commercial']['tmp_name'][$i];
				if(move_uploaded_file ($temp_name ,$dest)){
					$image_name[$i]['img'] = $file_name;
					$commercial_thumb = 'uploads/commercial/thumbs/'.$file_name;
					$commercial_thumb_360 = 'uploads/commercial/thumbs_360_360/'.$file_name;
					$this->imgResize($dest,$commercial_thumb, 260,'300');	
					$this->imgResize2($dest,$commercial_thumb_360, 360,'360');	
				}		
			}
			return $image_name;
		}
	}	
	
	function imgResize($inFile, $outFile="", $width=100, $height=100){
		$CI =& get_instance();
		$config['image_library'] = 'gd2';
		$config['source_image'] = $inFile;
		$config['wm_text'] = 'Copyright 2006 - John Doe';
		$config['wm_type'] = 'text';
		$config['new_image'] = $outFile;
		$config['thumb_marker'] = '';
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = $width;
		$config['height'] = $height;
		$CI->image_lib->initialize($config);
		$CI->image_lib->watermark();
		$CI->image_lib->resize();		  
    }	
	
	function imgResize2($inFile, $outFile="", $width=100, $height=100){
		$CI = &get_instance();
		$config['image_library'] = 'gd2';
		$config['source_image'] = $inFile;
		$config['new_image'] = $outFile;
		$config['thumb_marker'] = '';
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = FALSE;
		$config['width'] = $width;
		$config['height'] = $height;
		$CI->image_lib->initialize($config);
		$CI->image_lib->watermark();
		$CI->image_lib->resize();
		
    }
	
	function photoCount($skey){
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}
		 	$this->db->like('title',$key);
	 	}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
      	$query = $this->db->get('tbl_commercial');
      	return $query->num_rows(); 
    }
	
	
	 function getAll($limit=null, $start=null,$skey=null){
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('title',$key);
	 	}
		if($skey){
			if(in_array($skey,searchkey())){
				$this->db->like('title',$skey,'after');
			}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("title", $this->uri->segment(4)); 
		}
	 	$this->db->limit($limit, $start);
		$this->db->where('isDeleted','0');
      	$query = $this->db->get('tbl_commercial');
		
		//echo $this->db->last_query();
		return $query->result_array();
    }
}
?>