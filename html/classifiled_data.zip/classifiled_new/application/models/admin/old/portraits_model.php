<?php
class Portraits_model extends CI_Model {
	
	function insert(){
		$insertArray['title'] = $this->input->post('title');
		if($_FILES)
			$uploadedPhoto = $this->moveFiles();
		if(isset($uploadedPhoto) && !empty($uploadedPhoto)){
			foreach($uploadedPhoto as $row){
				$insertArray['image'] = $row['img'];
				$this->db->insert('tbl_portraits', $insertArray);        
			}
			return $this->db->insert_id();
		}			
	}

	function moveFiles(){
		$image_name ='';		
		$total_image = count($_FILES['portraits']['name']);
		if($total_image > 0){
			for($i=0; $i < $total_image; $i++){
				$dest = '';
				$temp = explode(".",$_FILES['portraits']['name'][$i]);
				$file_name = mt_rand() . '.' .end($temp);				
				$dest = "uploads/portraits/".$file_name;
				$temp_name = $_FILES['portraits']['tmp_name'][$i];
				if(move_uploaded_file ($temp_name ,$dest)){
					$image_name[$i]['img'] = $file_name;
					$portraits_266_194 = 'uploads/portraits/portraits_266_194/'.$file_name;
					$portraits_360_360 = 'uploads/portraits/portraits_360_360/'.$file_name;
					$this->imgResize($dest,$portraits_266_194, 266,'300');	
					$this->imgResize2($dest,$portraits_360_360, 360,'360');	
					//$this->watermark($dest,$portraits_266_194);
					//$this->watermark($dest,$portraits_360_360);
				}		
			}
			return $image_name;
		}
	}	
	
	function imgResize($inFile, $outFile="", $width=100, $height=100){
		$config['image_library'] = 'gd2';
		$config['source_image'] = $inFile;
		$config['new_image'] = $outFile;
		$config['thumb_marker'] = '';
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = $width;
		$config['height'] = $height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();		
    }
	
	function imgResize2($inFile, $outFile="", $width=100, $height=100){
		$config['image_library'] = 'gd2';
		$config['source_image'] = $inFile;
		$config['new_image'] = $outFile;
		$config['thumb_marker'] = '';
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = FALSE;
		$config['width'] = $width;
		$config['height'] = $height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();
		
    }
	
	
	/*function imgResize($inFile, $outFile="", $width=100, $height=100){
		$config['image_library'] = 'gd2';
		$config['source_image'] = $inFile;		
		$config['new_image'] = $outFile;
		$config['thumb_marker'] = '';
		$config['create_thumb'] = TRUE;
		$config['maintain_ratio'] = FALSE;
		$config['width'] = $width;
		$config['height'] = $height;
		$this->image_lib->initialize($config);
		$this->image_lib->resize();		  
    }*/
	
	
	function watermark($inFile, $outFile="") {
        $this->load->library('image_lib');
        $config['image_library'] = 'GD2';
        $config['source_image'] = $outFile;
        $config['new_image'] = $outFile;
        $config['wm_type'] = 'text';
		$config['wm_text'] = '@Photohouse Photography';
		//$config['wm_type'] = 'overlay';
        //$config['wm_overlay_path'] = 'frontend/images/logo.png';
		$config['wm_font_size'] = 50;
        //$config['wm_opacity'] = '50';
        $config['wm_vrt_alignment'] = 'bottom'; 
        $config['wm_hor_alignment'] = 'right';
        //$config['wm_hor_offset'] = '5';
        //$config['wm_vrt_offset'] = '5';
  
       // $data = $config;
        $this->image_lib->initialize($config);

        if (!$this->image_lib->watermark()) {
            echo $this->image_lib->display_errors();
        }
        $this->image_lib->clear();

       // $this->load->view('watermark', $data);
    }
	
	function photoCount($skey){
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}
		 	$this->db->like('title',$key);
	 	}
		$this->db->where('isDeleted','0');
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
      	$query = $this->db->get('tbl_portraits');
      	return $query->num_rows(); 
    }
	
	
	 function getAll($limit=null, $start=null,$skey=null){
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('title',$key);
	 	}
		if($skey){
			if(in_array($skey,searchkey())){
				$this->db->like('title',$skey,'after');
			}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("title", $this->uri->segment(4)); 
		}
	 	$this->db->limit($limit, $start);
		$this->db->where('isDeleted','0');
      	$query = $this->db->get('tbl_portraits');
		
		//echo $this->db->last_query();
		return $query->result_array();
    }
}
?>