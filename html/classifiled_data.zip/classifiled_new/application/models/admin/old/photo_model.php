<?php

class Photo_model extends CI_Model {
	
	function insert(){
		$insertArray['album_id'] = $this->input->post('album_id');
		$insertArray['user_id'] = $this->input->post('user_id');
		$insertArray['unique_id'] = mt_rand();
		if($_FILES){
			$uploadedPhoto = $this->moveFiles();
			//pr($uploadedPhoto); exit;
			if(isset($uploadedPhoto) && !empty($uploadedPhoto)){
				
				$photoDetail = $this->common_model->getSingle('tbl_photo_detail', array('album_id'=>$insertArray['album_id'],'user_id'=>$insertArray['user_id']));
				if(isset($photoDetail) && !empty($photoDetail)){
					$insertid = $photoDetail->id;
				}else{
					$this->db->insert('tbl_photo_detail', $insertArray); 			  
					$insertid = $this->db->insert_id();
				}
				if(isset($uploadedPhoto) && !empty($uploadedPhoto)){
					foreach($uploadedPhoto as $row){
						$photoArray = array('photo_detail_id'=>$insertid,
											'image'=>$row['img']
											);
						$this->db->insert('tbl_photo', $photoArray);        
					}
				}
				return $insertid;
			}
			
			return false;
		}		
	}
	
	function moveFiles(){
		$image_name ='';		
		 $total_image = count($_FILES['photo']['name']);
		if($total_image > 0){
			for($i=0; $i < $total_image; $i++){
				$dest = '';
				$temp = explode(".",$_FILES['photo']['name'][$i]);
				//$file_name = mt_rand() . '.' .end($temp);				
				$file_name = $_FILES['photo']['name'][$i];
				if (count(explode(' ', $_FILES['photo']['name'][$i])) > 1) {
				  pr(explode(' ', $_FILES['photo']['name'][$i]));
				  return $image_name; exit;
				} 
				
				$dest = "uploads/photo/".$file_name;
				
				
				$temp_name = $_FILES['photo']['tmp_name'][$i];
				if(move_uploaded_file ($temp_name ,$dest)){
					$image_name[$i]['img'] = $file_name;
					$photo_watermark = 'uploads/photo/watermark/'.$file_name;				
					$this->watermark($dest,$photo_watermark,'wlarge.png');
					$dest2 = "uploads/photo/watermark/".$file_name;
					$photo_266_194 = 'uploads/photo/photo_266_194/'.$file_name;
					$photo_755_505 = 'uploads/photo/photo_755_505/'.$file_name;						
					imgResize($dest2,$photo_266_194, 266,300);	
					imgResize($dest2,$photo_755_505, 755,505);
					
					//$this->watermark($photo_266_194,$photo_266_194,'wsmall.png');
					//$this->watermark($photo_755_505,$photo_755_505,'wlarge.png');
										
				}		
			}
		}
		
		return $image_name;
	}	

	function watermark($inFile, $outFile="",$imagesSize) {
        $this->load->library('image_lib');
        $config['image_library'] = 'GD2';
        $config['source_image'] = $inFile;
        $config['new_image'] = $outFile;
        $config['wm_type'] = 'overlay';
        $config['wm_overlay_path'] = 'frontend/images/'.$imagesSize;
        $config['wm_vrt_alignment'] = 'middle';  
        $config['wm_hor_alignment'] = 'center';
        //$config['wm_hor_offset'] = '5';
        //$config['wm_vrt_offset'] = '5';
        $this->image_lib->initialize($config);
		if (!$this->image_lib->watermark()) {
            echo $this->image_lib->display_errors();
        }
        $this->image_lib->clear();
    }

	/*function watermark($inFile, $outFile="",$fontSize) {
        $this->load->library('image_lib');
        $config['image_library'] = 'GD2';
        $config['source_image'] = $inFile;
        $config['new_image'] = $outFile;
        $config['wm_type'] = 'text';
		$config['wm_text'] = '@Photohouse Photography';
		$config['wm_font_path'] = 'frontend/font/ebrima.ttf';
		$config['wm_font_color'] = 'ffffff';
		$config['wm_font_size'] = $fontSize;
        $config['wm_vrt_alignment'] = 'bottom'; 
        $config['wm_hor_alignment'] = 'right';
        $this->image_lib->initialize($config);
		if (!$this->image_lib->watermark()) {
            echo $this->image_lib->display_errors();
        }
        $this->image_lib->clear();
    }*/

	function search_result($album_id=NULL, $user_id=NULL){
		$this->db->select('P.*');
		$this->db->from('tbl_photo P');
		$this->db->join('tbl_photo_detail as PD','P.photo_detail_id = PD.id','LEFT');
		$this->db->where('P.isDeleted','0');
		if($album_id)
			$this->db->where('PD.album_id',$album_id);
		if($user_id)
			$this->db->where('PD.user_id',$user_id);
		$query = $this->db->get();
		//echo $this->db->last_query();
		return $query->result_array();	
		
	}
	
	function dataGetAll($limit=NULL, $start=NULL,$skey=NULL){
		 
		$this->db->select('tbl_photo.*');
				 
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('title',$key);
	 	}
		if($skey){
			if(in_array($skey,searchkey())){
				$this->db->like('photo_detail_id',$skey,'after');
			}else if($skey == '1' ||$skey == '0' ) {
				$status = $skey; 
				$this->db->where('status',$status);
				$this->session->set_userdata('status', $skey);
			}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("photo_detail_id", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("id","DESC"); 
		}
		
		$this->db->from('tbl_photo');
		$this->db->where(array('isDeleted'=>'0','status'=>'1'));		
	 	//$this->db->limit($limit, $start);
		//$this->db->join('tbl_user', 'tbl_album.user_id = tbl_user.id','LEFT');
      	$query = $this->db->get();
		//echo $this->db->last_query();
		return $query->result_array();
		
    }
	
	
			function getAll($table,$where_clause=NULL,$order_by_fld=NULL,$order_by=NULL,$limit=NULL,$offset=NULL) {
		if($where_clause != '')
			$this->db->where($where_clause);

        if($order_by_fld != '')
		    $this->db->order_by($order_by_fld,$order_by);

		if($limit != '' && $offset !='')
		    $this->db->limit($limit,$offset);		

		$this->db->select('*');
		$this->db->from($table);
		$query = $this->db->get();  
		return $query->result();
	}
	
}

?>