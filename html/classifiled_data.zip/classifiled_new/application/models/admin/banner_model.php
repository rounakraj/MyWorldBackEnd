<?php
class Banner_model extends CI_Model {
	
	function insert(){
		$insertArray['title'] = $this->input->post('title');
		$insertArray['alt'] = $this->input->post('alt');
		$insertArray['caption'] = $this->input->post('caption');
		$insertArray['width'] = $this->input->post('width');
		$insertArray['height'] = $this->input->post('height');
		
		if($_FILES)
			$uploadedPhoto = $this->moveFiles($insertArray['width'], $insertArray['height']);
		if(isset($uploadedPhoto) && !empty($uploadedPhoto)){
			foreach($uploadedPhoto as $row){
				$insertArray['image'] = $row['img'];
				$this->db->insert('tbl_banner', $insertArray);        
			}
			return $this->db->insert_id();
		}			
	}

	function moveFiles($width, $height){
		$image_name ='';		
		$total_image = count($_FILES['banner']['name']);
		if($total_image > 0){
			for($i=0; $i < $total_image; $i++){
				$dest = '';
				$temp = explode(".",$_FILES['banner']['name'][$i]);
				$file_name = mt_rand() . '.' .end($temp);				
				$dest = "uploaded/banner/".$file_name;
				$temp_name = $_FILES['banner']['tmp_name'][$i];
				if(move_uploaded_file ($temp_name ,$dest)){
					$image_name[$i]['img'] = $file_name;
					$banner_thumb = 'uploaded/banner/thumbs/'.$file_name;
					$thumbs_200_150 = 'uploaded/banner/thumbs_200_150/'.$file_name;
					imgResize($dest,$thumbs_200_150, 200, 150);	
					imgResize2($dest,$banner_thumb, $width, $height);	
				}		
			}
			return $image_name;
		}
	}	
	
	
	function doActionPages(){		
		if($this->input->post('action')){
			$checkbox = $this->input->post('chk');	
			for($i=0;$i<count($checkbox);$i++){
				if($this->input->post('action') == 'Active' || $this->input->post('action') == 'Inactive'){
					$data=array('status' =>	$this->input->post('action'));
					$this->db->where('id', $checkbox[$i]);
					$this->db->update('tbl_banner',$data);
					$this->session->set_flashdata('actionmsg', 'Status successfully changed.');
				}
				if($this->input->post('action') == 'Delete'){
					$this->db->delete('tbl_banner', array('id' => $checkbox[$i]));
					$this->session->set_flashdata('actionmsg', 'Page successfuly removed.');										
				}
			}
			$adminfolder = $this->Common_model->getValue('master_settings','admin_folder',array('id'=>1));
			redirect(base_url().$adminfolder.'/banner/lists/'.$this->uri->rsegment(3));
		}
	}
	
	function dataCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
		 	$this->db->like('title',$key);
			$this->db->or_like('caption',$key);  
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('title',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == '1') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == '1') ? '1' : '0';
			$this->db->where('status',$status);
		}	
      	$query = $this->db->get('tbl_banner');
      	return $query->num_rows(); 
    }
		
	function getAll($limit=null, $start=null,$skey=null){
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('title',$key);
			$this->db->or_like('caption',$key);  
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('title',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("title", $this->uri->segment(4)); 
		}
		$this->db->where('isDeleted','0');
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_banner');
		//echo $this->db->last_query();
		return $query->result_array();
    }
}
?>