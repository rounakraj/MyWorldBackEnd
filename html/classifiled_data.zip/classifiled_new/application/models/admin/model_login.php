<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Model_login extends CI_Model {
	function __construct(){
		parent::__construct();
	}

	function authentication($username, $password){
	$query = $this->db->query("SELECT admin_id,admin_user,admin_pass,fname,lname FROM tbl_admin WHERE admin_user = '$username' LIMIT 1");
		
		if ($query->num_rows()){
			$row =  $query->row();
			
			$db_password = $this->encrypt->decode($row->admin_pass);
			//$db_password = $row->admin_pass;
			if($password == $db_password)
				return $row; 
				
		} 
	}	
}
/* End of file model_login.php */
/* Location: ./application/models/model_login.php */