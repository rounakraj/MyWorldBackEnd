<?php
class Category_model extends CI_Model {
	
	function insert(){
		$insertArray['parent_id'] = $this->input->post('parent_id');
		$insertArray['title'] = $this->input->post('title');
		$insertArray['slug'] = create_unique_slug($insertArray['title'],'tbl_category');
		$insertArray['image'] = '';
		$insertArray['page_heading'] = $this->input->post('page_heading');
		
		$insertArray['meta_keywords'] = $this->input->post('meta_keywords');
		$insertArray['meta_description'] = $this->input->post('meta_description');
		$insertArray['description'] = $this->input->post('description');
		
		if($_FILES){
			$uploadedImage = $this->moveFiles();
			if($uploadedImage){
				$insertArray['image'] = $uploadedImage;
			}
		}
		$lastCategoryId = $this->db->insert('tbl_category', $insertArray);
		return $lastCategoryId;
	}
	
	function update_category(){
		$updateArray['parent_id'] = $this->input->post('parent_id');
		$updateArray['title'] = $this->input->post('title');
		$updateArray['image'] = '';
		$updateArray['page_heading'] = $this->input->post('page_heading');
		
		$updateArray['meta_keywords'] = $this->input->post('meta_keywords');
		$updateArray['meta_description'] = $this->input->post('meta_description');
		$updateArray['description'] = $this->input->post('description');
		$updateArray['image'] = $this->input->post('prev_image');
		$category_id = $this->input->post('category_id');
		
		if($_FILES){
			$uploadedImage = $this->moveFiles();
			if($uploadedImage){
				$updateArray['image'] = $uploadedImage;
			}
		}
		$lastCategoryId = $this->db->update('tbl_category', $updateArray, array('id'=>$category_id));
		return $lastCategoryId;
	}
	
	function moveFiles(){
		$image_name ='';		
		$dest = '';
		$temp = explode(".",$_FILES['image']['name']);
		$file_name = mt_rand() . '.' .end($temp);				
		$dest = "uploaded/category/".$file_name;
		$temp_name = $_FILES['image']['tmp_name'];
		if(move_uploaded_file ($temp_name ,$dest)){
			$image_name = $file_name;
			$thumb_250_150 = 'uploaded/category/thumb_250_150/'.$file_name;
			$thumb_750_550 = 'uploaded/category/thumb_750_550/'.$file_name;						
			imgResize($dest,$thumb_250_150, 250,150);	
			imgResize($dest,$thumb_750_550, 750,550);
		}		
		return $image_name;
	}	

	function search_result(){
		$this->db->select('C.*');
		$this->db->from('tbl_category C');		
		$this->db->where('C.isDeleted','0');		
		$query = $this->db->get();
		return $query->result_array();	
	}
	
	function pageCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}				
				
		 	$this->db->like('title',$key);
			$this->db->or_like('description',$key);  
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('title',$skey,'after');
				}else if($skey == '1' || $skey == '0' ) {
					
					$this->db->where('status',$skey);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == '1') ? '1' : '0';
			$this->db->where('status',$status);
		}	
		$this->db->where(array('parent_id'=>0, 'isDeleted'=>'0'));		  	
      	$query = $this->db->get('tbl_category');
      	return $query->num_rows(); 
    }
	
	function getAllData($limit=NULL, $start=NULL,$skey=NULL){
		$this->db->select('tbl_category.*');
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('title',$key);
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('title',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("id", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("id","DESC"); 
		}
		
		$this->db->from('tbl_category');
		$this->db->where(array('parent_id'=>0, 'isDeleted'=>'0'));
		
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get();
		return $query->result_array();
		
    }
}

?>