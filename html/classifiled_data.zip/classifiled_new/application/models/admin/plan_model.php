<?php
class Plan_model extends CI_Model {
	
	
	function addNew(){
		$data=array(
			'name'				=>	$this->input->post('name'),
			'price'				=>	$this->input->post('price'),
			'priceFormate'		=>	$this->input->post('priceFormate'),
			'month'				=>	$this->input->post('month'),
			'totalproperties'	=>	$this->input->post('totalproperties'),
			'description'		=>	$this->input->post('description'),
		);
		// 
		if($this->input->post('plan_id') > 0){
				$where = array('id' => $this->input->post('plan_id'));
				$this->db->update('tbl_plan',$data,$where);
		}
		else{
				$this->db->insert('tbl_plan',$data);
				$this->db->insert_id();;
		}
		return true;		
	}
	
	function AllCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('name',$key);
	 	}
		
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'active' : 'inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? 'active' : 'inactive';
			$this->db->where('status',$status);
		}
		
      	$query = $this->db->get('tbl_plan');
      	return $query->num_rows(); 
    }
	
	function GetAll($limit=null, $start=null,$skey=null){
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('name',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'Active' : 'Inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("name", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("id","DESC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_plan');
		return $query->result_array();
    }
	
	function moveFiles($width=265, $height = 250){
		$image_name ='';		
		$dest = '';
		$temp = explode(".",$_FILES['item_image']['name']);
		$file_name = mt_rand() . '.' .end($temp);				
		
		$dest = "uploaded/items/".$file_name;
		$temp_name = $_FILES['item_image']['tmp_name'];
		
		if(move_uploaded_file ($temp_name ,$dest)){
				$thumb = 'uploaded/items/thumb/'.$file_name;
				$thumbs_900_900 = 'uploaded/items/thumbs_900_900/'.$file_name;
				
				
				imgResize($dest,$thumbs_900_900, 200, 150);	
				imgResize($dest,$thumb, $width, $height);	
			}		
		
		return $file_name;
		
	}
	
	function getSingleItem($id){
		$this->db->select('I.*,group_concat(distinct(IA.area_id)) area_id ,group_concat(distinct(A.area_name)) area_name,C.city_name,C.id as city_id');
		$this->db->from('tbl_plan I');
		$this->db->join('item_area IA','I.id = IA.item_id');
		$this->db->join('tbl_city_area A','A.id = IA.area_id');
		$this->db->join('tbl_city C','C.id = IA.city_id');
		$this->db->where('I.id',$id);
		$query = $this->db->get('tbl_plan');
		return $query->row_array();
		
	}	
}
?>