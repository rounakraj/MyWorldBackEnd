<?php
class doctor_model extends CI_Model {
	
	
	function addNew(){
		$data=array(
			'name'		=>	$this->input->post('name'),
			'code'			=>	$this->input->post('code'),
			'status'		=>	$this->input->post('status'),
		);
		
		if($this->input->post('doctor_id') > 0){
				$where = array('id' => $this->input->post('doctor_id'));
				$this->db->update('tbl_doctors',$data,$where);
				$doctor_id = $this->input->post('doctor_id');
				
		}
		else{
				$this->db->insert('tbl_doctors',$data);
				$doctor_id = $this->db->insert_id();;
		}
		
		//pr($this->input->post()); die("dddddddddddd");
		if($this->input->post('sub_clients')){
			
			$this->db->delete('tbl_doctor_subclinet', array('doctor_id' => $doctor_id)); 
			foreach($this->input->post('sub_clients') as $sub_client_id){
				$datas =array(
					'doctor_id'			=>	$doctor_id,
					'clinet_sub_id'		=>	$sub_client_id,
				);
				$this->db->insert('tbl_doctor_subclinet',$datas);
			}
		}
		return true;		
	}
	
	function AllCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('doctor_name',$key);
	 	}
		
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('doctor_name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'active' : 'inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? 'active' : 'inactive';
			$this->db->where('status',$status);
		}
		
      	$query = $this->db->get('tbl_doctors');
      	return $query->num_rows(); 
    }
	
	function GetAll($limit=null, $start=null,$skey=null){
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('doctor_name',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('doctor_name',$skey,'after');
				}
				else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'Active' : 'Inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("doctor_name", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("id","DESC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_doctors');
		return $query->result_array();
    }
	
	function moveFiles($width=265, $height = 250){
		$image_name ='';		
		$dest = '';
		$temp = explode(".",$_FILES['item_image']['name']);
		$file_name = mt_rand() . '.' .end($temp);				
		
		$dest = "uploaded/items/".$file_name;
		$temp_name = $_FILES['item_image']['tmp_name'];
		
		if(move_uploaded_file ($temp_name ,$dest)){
				$thumb = 'uploaded/items/thumb/'.$file_name;
				$thumbs_900_900 = 'uploaded/items/thumbs_900_900/'.$file_name;
				
				
				imgResize($dest,$thumbs_900_900, 200, 150);	
				imgResize($dest,$thumb, $width, $height);	
			}		
		
		return $file_name;
		
	}
	
	function getSingleItem($id){
		$this->db->select('I.*,group_concat(distinct(IA.area_id)) area_id ,group_concat(distinct(A.area_name)) area_name,C.city_name,C.id as city_id');
		$this->db->from('tbl_doctor I');
		$this->db->join('item_area IA','I.id = IA.item_id');
		$this->db->join('tbl_city_area A','A.id = IA.area_id');
		$this->db->join('tbl_city C','C.id = IA.city_id');
		$this->db->where('I.id',$id);
		$query = $this->db->get('tbl_doctor');
		return $query->row_array();
		
	}	
}
?>