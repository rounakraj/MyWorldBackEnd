<?php
class Job_model extends CI_Model {
	
	function AllCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('JobFileName',$key);
	 	}
		
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('JobFileName',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'active' : 'inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? 'active' : 'inactive';
			$this->db->where('status',$status);
		}
		
      	$query = $this->db->get('tbl_jobs');
      	return $query->num_rows(); 
    }
	
	function GetAll($limit=null, $start=null,$skey=null){
		
		
			$this->db->select('tbl_jobs.*, tbl_clients.client_name');
			$this->db->from('tbl_jobs');
			$this->db->join('tbl_clients','tbl_clients.id = tbl_jobs.clientId','INNER');
			
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('tbl_jobs.JobFileName',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('JobFileName',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'Active' : 'Inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("tbl_jobs.JobFileName", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("tbl_jobs.id","DESC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get();
		return $query->result_array();
    }
	
	
}
?>