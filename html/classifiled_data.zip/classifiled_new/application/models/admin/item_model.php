<?php
class Post_model extends CI_Model {
	
	function addNew(){
		
		$post['title'] = $this->input->post('name');
		$post['category_name'] = $this->input->post('category_name');
		$post['category_id'] = $category['id']; 
		$post['title'] = $this->input->post('title');
		$post['description'] = $this->input->post('description');
		$post['contact'] = $this->input->post('contact');
		$post['address'] = $this->input->post('address');
		
		if($_FILES['image']['name']){
			$image = $this->moveFiles();
			$data['item_image'] = $image;
		}
		if($this->input->post('item_id') > 0){
				$where = array('id' => $this->input->post('item_id'));
				$this->db->update('tbl_items',$data,$where);
				$this->itemAddArea($this->input->post('item_id'));
				
		}
		else{
				$this->db->insert('tbl_items',$data);
				$this->db->insert_id();;
				$this->itemAddArea($this->db->insert_id());
				
			
		}
		return true;		
	}
	
	function itemAddArea($item_id){
		
		if($this->input->post('area')){
			$where = array('item_id' => $item_id);
			$this->db->delete('item_area', $where); 
			$count = count($this->input->post('area'));
			$area = $this->input->post('area');
			
			for($i=0; $i< $count; $i++){
				$row['item_id'] = $item_id;
				$row['city_id'] = $this->input->post('city');
				$row['area_id'] = $area[$i];
				$this->db->insert('item_area',$row);
				//echo $this->db->last_query();
			}
			
		}
	}
	
	function AllCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('item_name',$key);
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('item_name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'active' : 'inactive'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? 'active' : 'inactive';
			$this->db->where('status',$status);
		}
		
      	$query = $this->db->get('tbl_items');
      	return $query->num_rows(); 
    }
	
	function GetAll($limit=null, $start=null,$skey=null){
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('item_name',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('item_name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? 'Active' : 'Inactive'; 
					//$status = $skey;
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("item_name", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("id","DESC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_items');
		//echo $this->db->last_query();
		return $query->result_array();
    }
	
	function moveFiles($width=265, $height = 250){
		$image_name ='';		
		$dest = '';
		$temp = explode(".",$_FILES['image']['name']);
		$file_name = mt_rand() . '.' .end($temp);				
		$dest = "assets/uploaded/post/".$file_name;
		$temp_name = $_FILES['item_image']['tmp_name'];
		if(move_uploaded_file($temp_name ,$dest)){
			return $file_name;
		}
		else{
			return false;
		}
		
	}
	
	function getSingleItem($id){
		$this->db->select('I.*,group_concat(distinct(IA.area_id)) area_id ,group_concat(distinct(A.area_name)) area_name,C.city_name,C.id as city_id');
		$this->db->from('tbl_items I');
		$this->db->join('item_area IA','I.id = IA.item_id');
		$this->db->join('tbl_city_area A','A.id = IA.area_id');
		$this->db->join('tbl_city C','C.id = IA.city_id');
		$this->db->where('I.id',$id);
		$query = $this->db->get('tbl_items');
		return $query->row_array();
		
	}	
}
?>