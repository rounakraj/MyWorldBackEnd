<?php
class User_model extends CI_Model {
	
	function add_new(){
		$data=array(
			'name'				=>	$this->input->post('name'),
			'username'			=>	$this->input->post('username'),
			'password'			=>	$this->encrypt->encode($this->input->post('password')),
			'user_role'			=>	$this->input->post('user_type'),
			
			'login_desc'		=>	$this->input->post('login_desc'),
			'MTQA'				=>	$this->input->post('MTQA'),
			'MTQAUSER'			=>	$this->input->post('MTQAUSER'),
			'FranchiseUserName'	=>	$this->input->post('FranchiseUserName'),
		);
		
		$insertId = $this->db->insert('tbl_user',$data);
		
		if($this->input->post('send_password')){	
			$this->load->library('email');
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'iso-8859-1';
			$config['wordwrap'] = TRUE;
			$this->email->initialize($config);
			$this->email->set_mailtype("html");
			$this->email->from(ADMIN_EMAIL);
			$this->email->to($data['email']);
			$this->email->subject("User : Registration Detail");				
			
			$msg = "Hi, ".$data['name'];
			$msg.='<br><a href="#">Click here</a> to Login';
			$msg.='<br>Email'.$data['email'];
			$msg.='<br>Password'.$data['password'];
			$msg.='<br><br>Thanks';
			$msg.='<br>Sitename Team';
			
			$this->email->message($msg);		
			$this->email->send();
		}
		
		if($insertId > 0)
			return true;
		else
			return false;
	}
	
	function update($user_id){
		$data=array(
			'name'				=>	$this->input->post('first_name'),
			'username'			=>	$this->input->post('username'),
			'password'			=>	$this->encrypt->encode($this->input->post('password')),
			'user_role'			=>	$this->input->post('user_type'),
			
			'login_desc'		=>	$this->input->post('login_desc'),
			'MTQA'				=>	$this->input->post('MTQA'),
			'MTQAUSER'			=>	$this->input->post('MTQAUSER'),
			'FranchiseUserName'	=>	$this->input->post('FranchiseUserName'),
		);
		
		/*if($this->input->post('send_password')){	
			$this->load->library('email');
			$config['protocol'] = 'sendmail';
			$config['mailpath'] = '/usr/sbin/sendmail';
			$config['charset'] = 'iso-8859-1';
			$config['wordwrap'] = TRUE;
			$this->email->initialize($config);
			$this->email->set_mailtype("html");
			$this->email->from(ADMIN_EMAIL);
			$this->email->to($data['email']);
			$this->email->subject("User : Registration Detail");				
			
			$msg = "Hi, ".$data['name'];
			$msg.='<br><a href="#">Click here</a> to visit your album.';
			$msg.='<br>Email'.$data['email'];
			$msg.='<br>Password'.$data['password'];
			$msg.='<br><br>Thanks';
			$msg.='<br>Site Name Team';
			
			$this->email->message($msg);		
			$this->email->send();
		} */

		$this->db->where('id', $user_id);
		$this->db->update('tbl_user',$data);
		//echo $this->db->last_query();exit;
		return true;
	}
		
	function dataCount($skey){
     
	 	if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
				
				$key  = $this->session->userdata('search_key');
			}
				
				
		 	$this->db->like('name',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		$this->db->str_open_braket = true;
		$this->db->str_close_braket = true;	
		
		if($this->session->userdata('status')){
			$status = ($this->session->userdata('status') == 'active') ? '1' : '0';
			$this->db->where('status',$status);
		}	
		
		
	  	
      	$query = $this->db->get('tbl_user');
      	return $query->num_rows(); 
    }
	
	function dataGetAll($limit=null, $start=null,$skey=null){
     	
		if($this->input->post('search_key') || $this->session->userdata('search_key') ){
		 	$key =trim($this->input->post('search_key'));
			if($this->input->post('search_key')){
				$this->session->set_userdata('search_key', $key);
			}
			else if( $this->session->userdata('search_key')){
			
				$key  = $this->session->userdata('search_key');
			}	
		 	$this->db->like('name',$key);
			
	 	}
		if($skey){
				if(in_array($skey,searchkey())){
					$this->db->like('name',$skey,'after');
				}else if($skey == 'active' ||$skey == 'inactive' ) {
					$status = ($skey == 'active') ? '1' : '0'; 
					$this->db->where('status',$status);
					$this->session->set_userdata('status', $skey);
				}
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC'){
			$this->db->order_by("name", $this->uri->segment(4)); 
		}else{
			$this->db->order_by("name","ASC"); 
		}
	 	$this->db->limit($limit, $start);
      	$query = $this->db->get('tbl_user');
		return $query->result_array();
    }
}
?>