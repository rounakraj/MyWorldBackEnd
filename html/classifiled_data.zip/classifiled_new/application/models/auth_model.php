<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Auth_model extends CI_Model {
	function __construct(){
		parent::__construct();
	}

	function login(){
		$mobile = $this->input->post('mobile');
		if($mobile){
			return $this->checkUser($mobile);
		}else{
			return FALSE;
		}
	}
	
	function userlogin(){
		$mobile = $this->input->post('mobile');
		$pos = strpos($mobile, '@');
		if($pos === false ){
			return $this->checkUser1($mobile,'mobile');
		}else{
			return $this->checkUser1($mobile,'email');
		}
	}
	
	function checkUser1($mobile,$field){
		$tbl = 'tbl_user';
		
		$where = array($field => $mobile, 'status' => 'active');
		$this->db->select('id,name,password');
		$this->db->from($tbl);
		$this->db->where($where);
		$query = $this->db->get();
		
		if($query -> num_rows() == 1){
			$row = $query->row_array();
			
			if(isset($row) && !empty($row) && $row['password'] ==  $this->input->post('password')){
				
					$session_data['id'] = $row['id'];
					$session_data['name'] = $row['name'];
					
					$this->session->set_userdata('sessionUser', $session_data);
					$this->session->set_userdata('sessionLoged', 'user');
					return 	$session_data;	
				
								
			}
			else 
		 		return false;
		}
		else{
	     	return false;
	   }
	   exit;
	}

	function checkUser($mobile){
		$tbl = 'tbl_vendor';
		$field = 'id,name,password';
		$where = array('mobile' => $mobile, 'status' => 'active');
		$this->db->select($field);
		$this->db->from($tbl);
		$this->db->where($where);
		$query = $this->db->get();
		echo $this->db->last_query(); 
		if($query -> num_rows() == 1){
			$row = $query->row_array();
			
			if(isset($row) && !empty($row) && $row['password'] ==  $this->input->post('password')){
				
					$session_data['id'] = $row['id'];
					$session_data['name'] = $row['name'];
					
					$this->session->set_userdata('sessionUser', $session_data);
					$this->session->set_userdata('sessionLoged', 'vendor');
					return 	$session_data;	
				
								
			}
			else 
		 		return false;
		}
		else{
	     	return false;
	   }
	   exit;
	}
	
	
}

/* End of file model_login.php */
/* Location: ./application/models/model_login.php */