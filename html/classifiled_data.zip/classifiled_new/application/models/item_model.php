<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Item_model extends CI_Model {
	
	function __construct(){
		parent::__construct();
		
	}
	
	function getAllTiffines($vendor_id= NULL,$item_id=NULL){
		$this->db->select('T.*,V.name as vendor_name,city.city_name,group_concat(area.area_name) area_name ,C.title category');
		$this->db->from('tbl_items T');
		$this->db->join('tbl_vendor V' , 'T.vendor_id = V.id');
		$this->db->join('tbl_category C' , 'T.category_id = C.id');
		$this->db->join('item_area TA' , 'T.id = TA.item_id');
		$this->db->join('tbl_city city' , 'TA.city_id = city.id');
		$this->db->join('tbl_city_area area' , 'TA.area_id = area.id');
		$this->db->group_by('T.id');
		$this->db->where('V.status','active');
		
		
		if($vendor_id){
			$this->db->where('v.id',$vendor_id);
		}
		if($item_id){
			$this->db->where('T.id',$item_id);
		}
		
		if($this->input->post()){
			
			if($this->input->post('city')){
				$this->db->where('city.id', $this->input->post('city'));
			}
			if($this->input->post('area')){
				$this->db->where('area.id', $this->input->post('area'));
			}
			if($this->input->post('category')){
				$this->db->where('T.category_id',$this->input->post('category'));
			}
			if($this->input->post('minVal') > 1 ){
				$this->db->where('T.price > ', $this->input->post('minVal'));
			}
			if($this->input->post('maxVal') > 10){
				$this->db->where('T.price < ',$this->input->post('maxVal'));	
			}
		}
		/*
		if(isset($this->input->post()) && $this->input->post()){
			
			if(!empty($this->input->post('city')))
				$this->db->where('city.id',$this->input->post('city'));
			if(!empty($this->input->post('area')))
				$this->db->where('area.id',$this->input->post('area'));
			
			if(!empty($this->input->post('category')))
				$this->db->where('T.category_id',$this->input->post('category'));
			
			if( !empty($this->input->post('minVal')))
				$this->db->where('T.price > ',$this->input->post('minVal'));
			
			if(!empty($this->input->pomaxValst('maxVal')))
				$this->db->where('T.price < ',$this->input->post('maxVal'));		
			
		} 
		*/
		$query = $this->db->get();
	
	
		return $query->result();
		
	}
	public function getTiffine($item_id){
		$tiffin = $this->getAllTiffines('',$item_id);
		return $tiffin[0];
	}
}	
?>	