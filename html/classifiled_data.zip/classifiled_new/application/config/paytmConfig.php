<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*

Paytm Config

Author : Dharmendra Kumar 

HTSM Pvt Ltd.


define('PAYTM_ENVIRONMENT', 'TEST'); // PROD
define('PAYTM_MERCHANT_KEY', 'xxxxxxxxxxxxxxxxxxxxxxxx'); //Change this constant's value with Merchant key downloaded from portal
define('PAYTM_MERCHANT_MID', 'xxxxxxxxxxxxxxxxxxxxxxx'); //Change this constant's value with MID (Merchant ID) received from Paytm
define('PAYTM_MERCHANT_WEBSITE', 'xxxxxxx'); //Change this constant's value with Website name received from Paytm


*/





$config['environment']	= 'AUTO';
$config['merchant_key'] = '';
$config['merchant_mid']	= 'english';
$config['website'] = TRUE;








/* End of file config.php */

/* Location: ./application/config/config.php */

