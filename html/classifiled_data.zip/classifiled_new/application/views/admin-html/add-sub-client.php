<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.css">

<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>

  
  
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/clients/all_clients'?>">Client &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Select Client Name:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Type Sub-Client Name:</td>
              </tr>
              
              <tr>
				<td align="left" valign="top">
				<select class="styled select" name="client_id">
						<?php foreach($Allclients as $obj) { ?>
						<option value="<?=$obj->id ?>" ><?=$obj->client_name?> </option>
						<?php } ?>
				   </select>
                </td>
				
                <td align="left" valign="top">
                    <input type="text"name="name" placeholder="Client Name" value="<?=($client->name) ? ($client->name) :  set_value('name')?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>"/>
                </td>
              </tr>
              
              <tr>
                <td align="left" valign="top">Type Sub-Client Code:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Status:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="code" placeholder="unit price" value="<?=($client->code) ? ($client->code) :  set_value('code')?>" class="input <?php if(form_error('Code')){ echo 'error'; } ?>"/>
                </td>
                
                 <td align="left" valign="top">
                   <select class="styled select" name="status">
						<option value="1"  <?=($client->status == '1') ? "Selected='selected'" :  "" ?> >Active</option>
						<option value="0"  <?=($client->status == '0') ? "Selected='selected'" :  "" ?> >Inactive</option>
					</select>
                </td>  
                  
                
              </tr>
             <tr>
				<input type="hidden" name="sub_client_id" value="<?php echo $client->id ?>" >
                <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
  </div></td>
