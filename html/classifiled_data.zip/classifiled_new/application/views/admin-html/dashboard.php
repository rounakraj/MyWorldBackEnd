<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  });
  </script>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="#url">Admin Dashboard</a></p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <table class="dashboard">
      <tbody>
      <tr>
	  <td width="50%">
	   <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Select Client:<span class="reqired"> *</span></td>
              </tr>
              
              <tr>
				<td align="left" valign="top">
				<select class="styled select" name="client_id">
						<?php foreach($Allclients as $obj) { ?>
						<option value="<?=$obj->id ?>" ><?=$obj->client_name?> </option>
						<?php } ?>
				   </select>
                </td>
			</tr>
			
			<tr>
                <td align="left" valign="top">Select Date:<span class="reqired"> *</span></td>
              </tr>
              
              <tr>
				<td align="left" valign="top">
				<input type="text"name="name" id="datepicker" placeholder="Client Name" value="<?=($client->name) ? ($client->name) :  set_value('name')?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>"/>
                </td>
			</tr>	
			<tr>
			
			
				<input type="hidden" name="sub_client_id" value="<?php echo $client->id ?>" >
                <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
		</td>
		<td rowspan="0" width="50%">
			<div> 
			
				<h2>How it works !</h2>
				<p><strong>Steps:</strong></p>
				
				<ul style="pending: 10px;"> 
					<li>1.Please choose Client from the dropdown.</li>
					<li>2.Click the date for which you want to see the jobs, on the calendar. </li>
					<li> We will automatically direct you to the "Jobs View" page. </li>
				</ul>
			
			
			</div>
		
		</td>
		<tr > 
		</tr>
		
		</td>
	  </tr>		
	 </tbody>
    </table>
	
  </div>
  </td>