<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/socialNetwork/'?>"><?=$title?> &raquo; </a>Edit</p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error");?>
    <form action="" method="post" id="frmUpload" name="frmUpload"  enctype="multipart/form-data" >
      <table width="636" class="add_leader">
        <tbody>
          <tr>
            <td width="184" align="left" valign="top">Media Name: <span class="required">*</span></td>
            <td width="184" align="left" valign="top">Link: </td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="title" value="<?php echo $result['social_media']?>" class="input"  /></td>
            <td align="left" valign="top"><input type="text" name="link" value="<?php echo $result['link']?>" class="input"  /></td>
          </tr>
          <tr>
            <td align="left" valign="top">Logo :</td>
          </tr>
          <tr>
            <td align="left" valign="top"><div class="file" style="width: 380px !important; ">
                <input type="file" class="file" style="display:none;" name="image" style="width:280px;">
                <input type="text" style=" height:28px; width:280px; float:left; background:transparent;" readonly="true" name="txtFakeText">
                <input type="button" style=" width:76px; height:28px; float:right; background:url(<?=base_url()?>admin-html/images/browse.png) no-repeat; cursor:pointer;" value="" onclick="HandleFileButtonClick();">
              </div></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="submit"  name="submit2"  value="Update It" class="submit" /></td>
          </tr>
        </tbody>
      </table>
    </form>
  </div></td>
<script language="JavaScript" type="text/javascript">
  function HandleFileButtonClick()
  {
    document.frmUpload.image.click();
    document.frmUpload.txtFakeText.value = document.frmUpload.flvid.value;
  }
</script>