 <td width="80%" align="left" valign="top"><div class="rightPnl">
           <div class="brdCumbPnl">
            <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/emailTemplate/index/'?>">Template &raquo; </a> <?=$title?></p>
            <?php echo $this->load->view("admin-html/include/view-site-icon"); ?>
          </div>
		
       <?php echo $this->load->view("admin-html/include/search-form"); ?>
	   
	   <form name="iform1" action="" id="iform1" method="post" enctype="multipart/form-data">
	   
          <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabCht1">
            <thead>
              <tr>
                <th align="left" valign="top" width="20%">
				<input type="checkbox" name="allchk" id="allchk" value=""  />
				 <a href="<?=$action.$order;?>" style="color:#fff"> Title
				 <?php if($order == 'DESC') { echo '<img src="'.base_url().'admin-html/images/down.png" style="margin:3px;position:absolute">'; } else {
				 echo '<img src="'.base_url().'admin-html/images/up.png" style="margin:3px;position:absolute">';
				 } ?> </a>
				 </th>
				 
                <th align="left" valign="top" width="20%" >Subject</th>
				<th align="left" valign="top" width="40%" >Message</th>
				<th align="left" valign="top" width="40%" >status</th>
				<th align="right" valign="top" width="20%" >Action</th>
              </tr>
            </thead>
            <tbody><?php if($result) { ?>
            <?php foreach($result as $key=>$row){ if($row['status'] == '1') {
				$status = '0';
				$image_path  = base_url().'admin-html/images/active.png';		
				$image_path = $image_path;	
				$image_path = '<img src="'.$image_path.'">';	
			} else {
				$image_path  = base_url().'admin-html/images/inactive.png';	
				$status = 1;
				$image_path = '<img src="'.$image_path.'">';	
			} 
			
			?>	
			  <tr>
			  
                <td align="left" valign="top" width="20%" >
				<input type="checkbox" name="chk[]" value="<?php echo $row['id'];?>" class="chk_id" />
				<?php echo $row['title'];?>
				
				</td>
				<td align="left" valign="top" width="25%" ><?php echo $row['subject'];?></td>
				<td align="left" valign="top" width="50%" ><?php echo substr(strip_tags($row['message']),0,200);?></td>
				<td width="10%" valign="top">
				<a href="<?=base_url().'admin/emailTemplate/changeStatus/'.$row['id'].'/'.$status?>" > <?=$image_path?></a>
				</td >
				<td align="left" valign="top" width="5%">
				<a href="<?=site_url("admin/emailTemplate/email_template/".$row['id']);?>">
				<img src="<?php echo base_url()?>admin-html/images/editIcon.png" class="cls" alt="" /></a>
				</td>
              </tr>

			 <?php } ?>
        <?php }  ?>

            </tbody>
          </table>
		</form>
		<div class="btmButtonPnl">
           
            <div class="inBtn"><a href="javascript:void(0)" onclick="makeInactive();">Make Inactivie</a></div>
            <div class="actBtn"><a href="javascript:void(0)" onclick="makeActive();">Make Activie</a></div>
          </div>	
          
          <div class="pagintPnl">
		  <ul><?php echo $links; ?></ul> 
          </div> 
        </div></td>
		
<script type="text/javascript">
						 
function makeActive(){
	var action =  "<?=site_url("admin/emailTemplate/makeChangeStatus/1");?>";
	if ($(".chk_id:checked").length > 0){
		document.iform1.action = action;
		$("#iform1").submit();
		}
		else{
		alert("Please, First Checked  One Or More Lists.");
		}
} 

function makeInactive(){
	var action =  "<?=site_url("admin/emailTemplate/makeChangeStatus/0");?>";
	if ($(".chk_id:checked").length > 0){
			document.iform1.action = action;
			$("#iform1").submit();
		}
		else{
		alert("Please, First Checked  One Or More Lists.");
		}
} 
		
								 
$(function(){
	
	 $("#allchk").click(function () {
	 
	        $('input[type=checkbox]').prop('checked', $(this).prop('checked'));
	  });

});		
		
</script> 
	