<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/doctors/all_doctors'?>">Doctor &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Doctor Name:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Doctor Code:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="name" placeholder="doctor Name" value="<?=($doctor->name) ? ($doctor->name) :  set_value('name')?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>"/>
                </td>
                  
				 <td align="left" valign="top">
                    <input type="text"name="code" placeholder="Code" value="<?=($doctor->code) ? ($doctor->code) :  set_value('code')?>" class="input <?php if(form_error('code')){ echo 'error'; } ?>"/>
                </td>
               </tr>
              
              <tr>
                <td align="left" valign="top">Select Sub Clients:</td>
              </tr>
              
              <tr>
                
                 <td align="left" valign="top">
                   <select  class="styled select" multiple="true" name="sub_clients[]">
					<?php foreach($subclient as $obj) {?>
						<option value="<?php echo $obj->id ?>" > <?php echo $obj->name ?></option>
					<?php } ?>
					</select>
                </td>  
                  
                
              </tr>
             <tr>
				<input type="hidden" name="doctor_id" value="<?php echo $doctor->id ?>" >
                <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
  </div></td>
