<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/pages/all_pages'?>"> Pages &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
        <tbody>
          <tr>
            <td align="left" valign="top">Page Title:<span class="reqired"> *</span></td>
            <td align="left" valign="top">Meta Keywords:</td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text"name="page_title" placeholder="Page Title" value="<?=set_value('page_title')?>" class="input <?php if(form_error('page_title')){ echo 'error'; } ?>"  /></td>
            <td align="left" valign="top" rowspan="3"><textarea class="textarea description" placeholder="Meta Keywords" name="meta_keywords"><?=set_value('meta_keywords')?></textarea></td>
          </tr>
          <tr>
            <td align="left" valign="top">Page Heading:</td>
          </tr>
        <td align="left" valign="top"><input type="text" name="page_heading" class="input" value="<?=set_value('page_heading')?>"/></td>
        <tr>
          <td align="left" valign="top">Parent Page (required):</td>
          <td align="left" valign="top">Meta Description:</td>
        </tr>
        <tr>
          <td align="left" valign="top"><select class="styled select" name="parent_page">
              <option value="0" <?php echo set_select('parent_page', '0', TRUE); ?>>(no parent)</option>
              <?php foreach ($parentpages as $row){
				$optparent = ($parentpages == $row->id ? true : false);
			  ?>
              <option value="<?php echo $row->id; ?>" <?php echo set_select('parent_page', $row->id, $optparent); ?>><?php echo $row->page_title; ?></option>
              <?php } ?>
            </select></td>
          <td align="left" valign="top" rowspan="3"><textarea class="textarea description" id="meta_description" name="meta_description" placeholder="Meta Description goes here" ><?=set_value('meta_description')?></textarea></td>
        </tr>
        <tr>
          <td align="left" valign="top">Display On:</td>
        </tr>
        <tr>
          <td align="left" valign="top"><select class="styled select" name="display_on" >
              <option value=""> Select Area </option>
              <option value="1">Header</option>
              <option value="2">Footer</option>
              <option value="3">Header &Footer</option>
              <option value="4">Other</option>
            </select></td>
        </tr>
        <tr>
          <td align="left" valign="top">Page Content : </td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2"><div style="width: 670px;; height: 425px;" <?php if(form_error('page_content')){ echo 'class="error"'; } ?>>
           <textarea name="page_content" cols="200" rows="200" id="page_content" style="width:550px; height:400px;"><?=set_value('page_content')?></textarea>
            </div>
            <br></td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
        </tr>
        </tbody>
        
      </table>
    </form>
  </div></td>
