<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="#">Setting &raquo; </a>
        <?=$title?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post" enctype="multipart/form-data" >
      <table width="636" class="add_leader">
        <tbody>
          <tr>
            <td width="184" align="left" valign="top">Site Name: <span class="required">*</span></td>
            <td width="184" align="left" valign="top">Phone No: <span class="required">*</span></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="name" value="<?php echo $site_info['company_name']?>" class="input"  />
            <td align="left" valign="top"><input type="text" name="phone" value="<?php echo $site_info['phone_no']?>" class="input"  /></td>
          </tr>
          <tr>
            <td width="184" align="left" valign="top">Email: <span class="required">*</span></td>
            <td width="184" align="left" valign="top">Mobile: <span class="required">*</span></td>
            
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="email" value="<?php echo $site_info['email']?>" class="input"  /></td>
            <td align="left" valign="top"><input type="text" name="mobile_no" value="<?php echo $site_info['mobile_no']?>" class="input"  /></td>
          </tr>
          <tr>
          	<td width="184" align="left" valign="top">Meta Title: </td>
            <td width="184" align="left" valign="top">Address: </td>           
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="meta_title" value="<?php echo $site_info['meta_title']?>" class="input"  /></td>
            <td><textarea id="question" class="textarea description" name="address" style="width: 335px; height:60px;"><?php echo $site_info['address']?></textarea></td>
          </tr>
          <tr>
          	<td width="184" align="left" valign="top">Meta Description:</td>
            <td width="184" align="left" valign="top">Meta Key Word: </td>
            <!--<td align="left" valign="top">Logo :</td>--> 
          </tr>
          <tr>
            <td><textarea id="question" class="textarea description" name="meta_description" style="width: 335px;"><?php echo $site_info['meta_description']?> </textarea></td>
            <td><textarea id="question" class="textarea description" name="meta_keyword" style="width: 335px;"><?php echo $site_info['meta_keyword']?> </textarea></td>
			<!--<td align="left" valign="top">
				<div class="file" style="width: 380px !important; ">
                	<input type="file" class="file" style="display:none;" name="logo" style="width:280px;">
                    <input type="text" style=" height:28px; width:280px; float:left; background:transparent;" readonly="true" name="txtFakeText"><input type="button" style=" width:76px; height:28px; float:right; background:url(<?=base_url()?>admin-html/images/browse.png) no-repeat; cursor:pointer;" value="" onclick="HandleFileButtonClick();">
         		</div>
			</td>--> 
          </tr>
          
          <tr>
          	<td width="184" align="left" valign="top">Google Analytics:</td>
            <td width="184" align="left" valign="top">Google Map:</td>
            <!--<td align="left" valign="top">Logo :</td> -->
          </tr>
          <tr>
             <td><textarea id="question" class="textarea description" name="google_analytics" style="width: 335px;"><?php echo $site_info['google_analytics']?> </textarea></td>
             <td><textarea id="question" class="textarea description" name="google_map" style="width: 335px;"><?php echo $site_info['google_map']?> </textarea></td>
            <!--<td align="left" valign="top">
				<div class="file" style="width: 380px !important; ">
                	<input type="file" class="file" style="display:none;" name="logo" style="width:280px;">
                    <input type="text" style=" height:28px; width:280px; float:left; background:transparent;" readonly="true" name="txtFakeText"><input type="button" style=" width:76px; height:28px; float:right; background:url(<?=base_url()?>admin-html/images/browse.png) no-repeat; cursor:pointer;" value="" onclick="HandleFileButtonClick();">
         		</div>
			</td> -->
          </tr>
          
          <tr>          	
            <td align="left" valign="top">Logo :</td> 
          </tr>
          <tr>
            <td align="left" valign="top">
               <input type="file" class="file" name="image" style="width:280px;" value="">                    
			</td> 
          </tr>
          
          <tr>
            <td align="left" valign="top"><input type="submit"  name="submit2"  value="<?=$title?>" class="submit" /></td>
          </tr>
        </tbody>
      </table>
    </form>
  </div></td>
