<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
       $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "admin-html/images/ico9.png",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
	
	
	$("#datepicker").change(function(){
		$(".date1").html(this.value);
			
	});
  });
  
  var myVar = setInterval(myTimer, 1000);
	function myTimer() {
		var d = new Date();
		document.getElementById("date_time").value = d.toLocaleTimeString();
	}
</script>
  
  
  
<td width="80%" align="left" valign="top">
<div class="rightPnl">
	<div class="brdCumbPnl">
	  <p><a href="#url">Admin Dashboard</a></p>
	  <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> 
	</div>
    <table class="dashboard">
      <tbody>
      <tr>
	  <td width="50%">
	   <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Download Date:<span class="reqired"> *</span></td>
				<td align="left" valign="top"></td>
				<td align="left" valign="top"></td>
              </tr>
              
              <tr>
				<td align="left" valign="top">
				<input type="text"name="download_date" id="datepicker" placeholder="Client Name" value="<?php echo date("d/m/Y");  ?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>">
				</td>
				<td align="left" valign="top"> 
				
				<input style="font: 14px 'proxima_nova_rgregular' !important" type="button" value="Click to get enter jobs name" onclick="$('#leader').show(); $('.date1').html($('#datepicker').val());" class="submit left" /></td>
				<td align="left" valign="top">
				
				</td>
			</tr>
			</tr>
         </tbody>
       </table>
	   
	   
	  <table width="100%" class="add_leader" id="leader" style="display:none">
	  <tbody>
		<tr>
			<th align="left" valign="top"  width="10%">Srl No.</th><th align="left" valign="top"  width="30%">Job File Name</th><th align="left" valign="top"  width="30%">Download date</th><th align="left" valign="top"  width="30%">Time</th>
		</tr>
		<?php for($i=1;$i < 11 ; $i++) {?>
		<tr>
			<td width="10%" align="left" valign="top" ><?=$i?></td>
			<td width="30%" align="left" valign="top"><input type="text" name="jobname[]" class="input" ></td>
			<td width="30%" align="left" valign="top"><span class="date1" style="width:120px;"> </td>
			<td width="30%" align="left" valign="top"><input type="text" name="time[]"  class="input" value="12:56" ></td>
		</tr>
		<?php } ?>
		</tbody>
		
			<tr> 
			<td width="10%" align="left" valign="top" ></td>
			<td align="left" colspan="2">
				<select class="styled select" name="client_id" >
						<option value=""selected="selected" > Select Client</option>
						<?php foreach($Allclients as $obj) { ?>
						<option value="<?=$obj->id ?>" ><?=$obj->client_name?> </option>
						<?php } ?>
				 </select>
			</td>
			<td align="left">
			<input style="font: 14px 'proxima_nova_rgregular' !important" type="submit" value="Submit" class="submit left" />
			</td>
		
		</tr>
		</table>
    </form>
		</td>
	</tr>
			
	</table>
	
  </div>
  </td>