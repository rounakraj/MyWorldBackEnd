<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Login</title>
<link href="<?php echo base_url()?>admin-html/css/fonts.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>admin-html/css/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="<?=site_url("admin-html/js/jquery-1.9.0.min.js");?>"></script>
<script language="javascript" type="text/javascript" src="<?=site_url("admin-html/js/jquery.form-validator.js");?>"></script>
</head>
<style>
div.form-error {
	background-attachment: scroll;
	background-clip: border-box;
	background-color: #FFE5ED;
	background-image: none;
	background-origin: padding-box;
	background-position: 0 0;
	background-repeat: repeat;
	background-size: auto auto;
	border-bottom-left-radius: 4px;
	border-bottom-right-radius: 4px;
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
	color: #8B0000;
	line-height: 180%;
	margin-top:100px;
	margin-bottom: 22px;
	padding-bottom: 6px;
	padding-left: 40px;
	padding-right: 40px;
	padding-top: 10px;
	position: fixed;
	float:right;
	margin-left: 236px;
}
input.error {
	color: #8B0000;
}
input.valid {
	color: #002f00;
	border-color: #96b796 !important;
}
.help-block {
	display:none;
}
</style>
<body>
<div class="loginPnlMain">
  <div class="logPnlLftBg">
    <div class="logPnlRhtBg">
      <div class="lgnCntr">
        <div class="lgnCntrInr">
          <?php if($this->session->flashdata('msg')){ ?>
          <div id="form-error" class="form-error"> <?php echo $this->session->flashdata('msg'); ?> </div>
          <?php } ?>
          <div class="form-error" style="display:none"> </div>
          <!--<div class="lgnLogo"><a href="<?=base_url();?>" target="_blank"><img src="<?=base_url()?>admin-html/images/logo.png" class="logo" alt=""" /></a></div>-->
          <form action="<?=site_url("index.php/admin/login/authentication");?>" method="post" class="niceform">
            <div class="lgnPnl">
              <div id="login">
                <input type="text" placeholder="User Name " name="username" id="username" value="<?=$setuser?>" size="54" data-validation="required" />
                <input  type="password" class="password" placeholder="Password" name="userpass" id="userpass" value="<?=$setpass?>"  data-validation="required"/>
                <!--<label class="remb">
                  <input type="checkbox" name="remenber_me" id="" value="1" <?php if($remenber_me == 1 ) echo 'checked="checked"'; ?> />
                  Remember me</label>-->
                <input name="" type="submit" value="Enter" />
              </div>
              <div id="forgotdiv" style="display:none">
                <input class="" type="text" placeholder="Enter Your Email Id" name="email" id="email" size="54" />
                <input name="" id="forgotbtn" type="button" value="Submit" />
              </div>
              <div class="lgnBot"> <a id="forgot" href="javascript:void(0)">Have you Forgot password?</a></div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="lgnFooter">
  <p class="lgnLft"><a href="javascript:void(0);">Admin Panel</a> </p>
  <p class="lgnRht">&copy; Copyright 2014.</p>
</div>
<script type="text/javascript">
$.validate({
 	validateOnBlur : true, // disable validation when input looses focus
    errorMessagePosition : 'top', // Instead of 'element' which is default
    scrollToTopOnError : false // Set this property to true if you have a long form
});

$(function(){
	$("#form-error").show();

	$("#forgot").click(function(){
		$(".form-error").hide();
		$("#forgotdiv").toggle();
		$("#login").toggle();
		if($('#forgotdiv').is(':visible'))
			$("#forgot").html('Login Panel.');
		else 
			$("#forgot").html('Have you Forgot password?');	
	});

	$("#forgotbtn").click(function(){ 
		email = $("#email").val();
		if(email == "" ){
			$("#email").css('border','2px solid #BA313C');
			$(".form-error").html("<strong>Please Enter Email.</strong");
			$(".form-error").show();
			//$("#email")('error');
		}else if( !isValidEmailAddress( email ) ){
			$("#email").css('border','2px solid #BA313C');
			$(".form-error").html("<strong> Opps Error ! <br> Please Enter Valid Email.</strong>");
			$(".form-error").show();
		}else {
			$(".form-error").hide();
			var url_post = "<?php echo base_url()?>admin/login/forgotPassword"; 
			$.post(url_post,{email:email},function(data){
				if(data != 'true'){
					$(".form-error").html(data);
					$(".form-error").show();
					$("#email").css('border','2px solid #BA313C');
				}
			

				else{

					$(".form-error").html('<strong style="color:green"> Check Your Mail, <br> Admin detail has to sent on your email id.</strong>');

					$(".form-error").show();

					$("#email").css('border','2px solid green');

				}

					

			});

			

		}

	});

	

})





function isValidEmailAddress(emailAddress) {

    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);

    return pattern.test(emailAddress);

};



</script>
</body>
</html>