
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/socialNetwork/'?>"><?=$title?> &raquo; </a>Lists</p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <form name="iform1" action="" id="iform1" method="post" enctype="multipart/form-data">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabCht1">
        <thead>
          <tr>
          	<th align="left" valign="top" width="10%"> Sl. No. </th>
            <th align="left" valign="top" width="25%"> Social Media Name </th>
            <th align="left" valign="top" width="40%" >Link</th>
            <th align="left" valign="top" width="10%" >image</th>
            <th align="right" valign="top" width="15%" >Action</th>
            <th align="right" valign="top" width="10%" >Order</th>
          </tr>
        </thead>
        <tbody>
          <?php if($result) : $i = 1; ?>
          <?php foreach($result as $key=>$row):
			$icon = '';
			if($row['image']){
				$icon  = base_url().'uploaded/social-media/'.$row['image'];
			}else{
				//$icon  = base_url().'front-html/images/'.$row['defalut_image'];
			}

			?>
          <tr>
          	<td align="left" valign="top" width="10%" ><?php echo $i;?>.</td>
            <td align="left" valign="top" width="25%" ><?php echo $row['social_media'];?></td>
            <td align="left" valign="top" width="40%" ><?php echo $row['link'];?></td>
            <td align="left" valign="top" width="10%" ><img src="<?php echo $icon;?>" alt="" /></td>
            <td align="left" valign="top" width="15%"><a href="<?=site_url("admin/socialNetwork/editSocialInfo/".$row['id']);?>"> <img src="<?php echo base_url()?>admin-html/images/closeIcon.png" class="cls" alt="" /></a>  <a href="<?=site_url("admin/socialNetwork/editSocialInfo/".$row['id']);?>"> <img src="<?php echo base_url()?>admin-html/images/editIcon.png" class="cls" alt="" /></a></td>
            <td><input type="text" name="rank" size="1"  id="<?php echo $row['id'];?>" value="<?php echo $row['rank'];?>" onchange="reSetOrder(this);"  /></td>
          </tr>
          <?php $i++; endforeach; ?>
          <?php endif;  ?>
        </tbody>
      </table>
    </form>
    <div class="pagintPnl">
      <ul>
      </ul>
    </div>
  </div></td>
<script type="text/javascript" >

function reSetOrder(test){

	var field_name  = test.name;

	var filed_val = test.value;

	var id = test.id;

    var base_url = "<?php echo base_url()?>";	

	var url = base_url+'admin/socialNetwork/reSetOrder';

	$.post(url,{field_name:field_name,filed_val:filed_val,id:id},function(data){

		if(data){

			$(".valid_box").show()

			$(".valid_box").html(" Page Order Update Successfully");

			$(".valid_box").fadeOut(8000);

		}

	});

	

}			

</script>
