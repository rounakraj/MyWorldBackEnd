<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>

<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>



<td width="80%" align="left" valign="top"><div class="rightPnl">

          <div class="brdCumbPnl">

            <p><a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/emailTemplate/index'?>"> Email Template &raquo; </a><?=$title;?></p>

             <?php echo $this->load->view("admin-html/include/view-site-icon"); ?>

          </div>

			<?php echo $this->load->view("admin-html/include/validation-error"); ?>

			

		  <table class="add_leader">

         <form action="" method="post" name="frmUpload" enctype="multipart/form-data">

           	  <tbody>

            	<tr><td align="left" valign="top">Plan Name: <span class="required">* </span> </td></tr>
            	
				<tr>
				<td align="left" valign="top"><input type="text"  name="name" value="<? echo $result['name']; ?>" class="input" /></td>
				</tr>
				
				<tr><td align="left" valign="top">Pice: <span class="required">* </span> </td></tr>
            	
				<tr>
				<td align="left" valign="top"><input type="text"  name="price" value="<? echo $result['price']; ?>" class="input" /></td>
				</tr>
				
				
				<tr><td align="left" valign="top">Month: <span class="required">* </span> </td></tr>
            	
				<tr>
				<td align="left" valign="top"><input type="text"  name="month" value="<? echo $result['month']; ?>" class="input" /></td>
				</tr>
				
				<tr><td align="left" valign="top">Limit Properties: <span class="required">* </span> </td></tr>
            	
				<tr>
				<td align="left" valign="top"><input type="text"  name="totalproperties" value="<? echo $result['totalproperties']; ?>" class="input" /></td>
				</tr>
				<tr>
				<td>Description :</td>
				</tr>

				<tr>

				<td>

				<textarea name="description" id="page_content" style="width:550px; height:400px;">

				<? echo $result['description']; ?>

				</textarea>

				</td>

				</tr>

			<tr>

                	<td align="center" valign="top" colspan="3">

					<input type="submit" name="submit1" value="<?=$title?>" class="submit"/>

					</td>

                    <td align="left" valign="top"></td>

			</tr>

			

                </tbody>

                </form>

            </table>

        </div></td>

