<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <?=$title?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post" class="niceform">
      <table width="636" class="add_leader">
        <tbody>
          <tr>
            <td width="184" align="left" valign="top">First Name: <span class="required">*</span></td>
            <td width="194" align="left" valign="top">Last Name: <span class="required">*</span></td>
            <td width="242" align="left" valign="top">Email: <span class="required">*</span></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="fname" value="<?php echo $query['fname'];?>" class="input"  /></td>
            <td align="left" valign="top"><input type="text" name="lname" value="<?php echo $query['lname'];?>" class="input" /></td>
            <td align="left" valign="top"><input type="text" name="email"  value="<?php echo $query['email_address'];?>" class="input" /></td>
          </tr>
          <tr>
            <td align="left" valign="top">User Name:</td>
            <td align="left" valign="top">Password:<span class="required">*</span></td>
            <td align="left" valign="top">Confirm Password:</td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text"  name="uname" value="<?php echo $query['admin_user'];?>" class="input"  /></td>
            <td align="left" valign="top"><input type="text" name="pass" value="<?php echo $admin_pass ;?>"  class="input" /></td>
            <td align="left" valign="top"><input type="text" name="cpass" value="<?php echo $admin_pass ;?>" class="input" /></td>
          </tr>
          <tr>
            <td></td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="submit"  name="submit2"  value="<?=$title?>" class="submit" /></td>
          </tr>
        </tbody>
      </table>
    </form>
    <!------------------>
  </div></td>
