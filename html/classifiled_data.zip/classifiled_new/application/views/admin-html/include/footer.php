</tr>
</table>
</div>
<div class="lgnFooter">
  <p class="lgnLft"><a href="<?php echo base_url().'admin/dashboard'; ?>">Admin Panel</a> </p>
  <p class="lgnRht">&copy; Copyright 2015. All Rights Reserved</p>
</div>
<script type="text/javascript" >
function datadelete(val){
	action = $(val).attr('rel')
	if(confirm("Do you want to delete.")){
		window.location = action;
	}
}
</script>
</body></html>