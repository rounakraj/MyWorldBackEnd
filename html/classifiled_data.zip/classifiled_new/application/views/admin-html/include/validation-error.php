<?php if(validation_errors()) { ?>

	<div class="errorPnl">

		<?php //echo validation_errors(); ?> 

			Oops!!<br />

			<span>

			Marked fields are required. Please fill them and try again. <br>

			<?php if($this->session->userdata('error')) echo $this->session->userdata('error');

				  $this->session->unset_userdata('error'); ?>

			</span>

	</div> 

<?php } ?>

<?php if(isset($error)) { ?>

				<div class="errorPnl">

				Oops!!<br /><span>

				<?php  echo $error ; ?>

				</span>

				</div>

<?php }  ?>

<?php if($this->session->flashdata('msg')) { ?>

<div class="successPnl">

          	Yippee !!<br />

			<span> <?php echo $this->session->flashdata('msg'); ?></span>

</div>

<?php } ?>	

<?php if($this->uri->segment('2') != 'theme') { ?>						 

    <span style="float:right;margin-top:-20px;color:#FF0000"> <span style="font-size:18px;">(*)</span>Fields are Required. </span>

<?php } ?>

<?php if($this->session->userdata('error')) { ?>

				<div class="errorPnl" style="float:left">

				Oops!!<br /><span>

				<?php  echo $this->session->userdata('error'); ?>

				</span>

				</div>

<?php } $this->session->unset_userdata('error');  ?>