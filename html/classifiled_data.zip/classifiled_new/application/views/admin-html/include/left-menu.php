<td width="20%" align="left" valign="top"><div class="leftPnl">
   
   <h3><a class="submenuheader" href="#"><img src="<?php echo base_url()?>admin-html/images/ico9.png" class="ico" alt="" />View Job</a></h3>
   <div class="submenu">
			<ul>
				<li><a href="<?=site_url("admin/dashboard/");?>">View Job</a></li>
				<li><a href="<?=site_url("admin/dashboard/viewStatus/");?>">Job Status</a></li>
			</ul>
	</div>		
    
   <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico9.png" class="ico" alt="" />Client</a></h3>
    
	<div class="submenu">
      <ul>
        <li><a href="<?=site_url("admin/client/add/");?>">Add Client</a></li>
        <li><a href="<?=site_url("admin/client/all/");?>">All ClientsLIst</a></li>
		
		 <li><a href="<?=site_url("admin/subclient/add/");?>">Add Sub Client</a></li>
        <li><a href="<?=site_url("admin/subclient/all/");?>">All Sub Client List</a></li>
		
		
      </ul>
    </div>
	
	
	 <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico9.png" class="ico" alt="" />User</a></h3>
    
	<div class="submenu">
      <ul>
        <li><a href="<?=site_url("admin/user/allUsers");?>">User List</a></li>
        <li><a href="<?=site_url("admin/user/add_new");?>">Add User</a></li>
      </ul>
    </div>
 	
    <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico_email-template.png" class="ico" alt="" />Email Template</a></h3>
      <div class="submenu">
        <ul>
          <li><a href="<?=site_url("admin/emailTemplate/index");?>">Email Templates</a></li>
        </ul>
      </div>
	  
	  <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico_email-template.png" class="ico" alt="" />Doctor</a></h3>
      <div class="submenu">
      
      <ul>
        <li><a href="<?=site_url("admin/user/allUsers");?>">Doctor List</a></li>
        <li><a href="<?=site_url("admin/user/add_new");?>">Add New Doctor</a></li>
      </ul>
      </div>
	  
	  
	    <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico_email-template.png" class="ico" alt="" />Job Update</a></h3>
      <div class="submenu">
	  <ul>
			<li><a href="<?=site_url("admin/Job/read_file");?>">Read File</a></li>
			<li><a href="<?=site_url("admin/Job/read_file");?>">Read Directory</a></li>
			<li><a href="<?=site_url("admin/Job/manualEntry");?>">Manual Entry</a></li>
			<li><a href="<?=site_url("admin/Job/deleteJobs");?>">Delete Jobs</a></li>
			<li><a href="<?=site_url("admin/Job/editJobsDetails");?>">Edit Jobs Details</a></li>
			<li><a href="<?=site_url("admin/Job/editJobsDetails");?>">Edit Jobs Details</a></li>
		</ul>
	  </div>
	   
	  
	   <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico_email-template.png" class="ico" alt="" />Report</a></h3>
      <div class="submenu">
      
      <ul>
        <li><a href="<?=site_url("admin/user/allUsers");?>">Details Invoice</a></li>
        <li><a href="<?=site_url("admin/user/add_new");?>">Summary Invoice</a></li>
        <li><a href="<?=site_url("admin/user/add_new");?>">Beverly Report</a></li>
        <li><a href="<?=site_url("admin/user/add_new");?>">Other Report</a></li>
      </ul>
	  </div>
	  
	  <h3><a class="submenuheader" href="#url"><img src="<?php echo base_url()?>admin-html/images/ico_email-template.png" class="ico" alt="" />SpecialAllocation</a></h3>
      <div class="submenu">
      
      <ul>
        <li><a href="<?=site_url("admin/user/allUsers");?>"SpecialAllocation log</a></li>
      </ul>
	  </div>
    
   </div></td>
