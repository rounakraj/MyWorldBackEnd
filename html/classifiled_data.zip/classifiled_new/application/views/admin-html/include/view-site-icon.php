<div class="rghtImg"><a href="<?php echo base_url().'admin/dashboard/db_backup'?>">
	<img src="<?=base_url().'admin-html/'?>images/db-backup.png" alt="" /></a>
</div>
<div class="view"><p><a href="<?php echo base_url()?>" target="_blank">Visit Site</a></p></div>

