 <style type="text/css">
 .lactive{
 	font-weight:normal!impotrant;
 }
 </style>
<?php if($this->session->flashdata('msg')) { ?>
<div class="successPnl">
          	Yippee !!<br />
			<span> <?php echo $this->session->flashdata('msg'); ?></span>
</div>
<?php } ?>
<?php if($this->session->userdata('error')) { ?>
				<div class="errorPnl">
				Oops!!<br /><span>
				<?php  echo $this->session->userdata('error'); ?>
				</span>
				</div>
<?php } $this->session->unset_userdata('error');  ?>


 <div class="searchPnl">
 		<form  id="seacrh_form" method="post"  action="<?php echo $action ;?>" >
            <div class="srchFldArea">
			<input  type="text" name="search_key" id="search_key" placeholder="Enter your keywords here" size="50" value="<?php echo $this->session->userdata('search_key'); ?>" />
              
              <input name="" type="submit" value="Search" />
            </div>
		</form>	
            <p>
			<?php foreach(  searchkey() as $keyalpha) {?>
				<a href="<?=$action.$keyalpha ?>" <?php if($this->uri->segment(4) == $keyalpha ) echo 'class="lactive"'; ?>   > <?=$keyalpha?> </a>
			<?php } ?>
			</p>
			<p style="margin-top:10px;">
			<a  style="border:none" href="<?=$action?>" <?php if($this->session->userdata('status')== '' && $this->session->userdata('status') !== 0) {echo 'class="lactive"';} ?> > All </a> 
			<?php if(isset($statuslink)) {?>
			 |
			<a style="border:none" href="<?=$action?>active" <?php if($this->session->userdata('status') == 'active') echo 'class="lactive"'; ?> > Active </a> | 
			<a style="border:none" href="<?=$action?>inactive" <?php if($this->session->userdata('status') === 'inactive') echo 'class="lactive"'; ?> > Inactive </a>
			<?php } ?>
			</p>
          </div>
