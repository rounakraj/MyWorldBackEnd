<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/pages/all_pages'?>"> Pages &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error");?>
    <form action="<?php echo base_url().'admin/pages/page_update/'.$page_id ?>" method="post">
      <table class="add_leader">
        <tbody>
          <tr>
            <td align="left" valign="top"><span class="reqired"> *</span>Page Title:</td>
            <td align="left" valign="top">Meta Keywords:</td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text" name="page_title" value="<?=$update_page_display->page_title?>" placeholder="Page Title" class="input"  /></td>
            <td align="left" valign="top" rowspan="3"><textarea class="textarea description" placeholder="Meta Keywords" name="meta_keywords" ><?=$update_page_display->meta_keywords;?>
</textarea></td>
          </tr>
          <tr>
            <td align="left" valign="top">Page Heading:</td>
          </tr>
        <td align="left" valign="top"><input type="text" name="page_heading"  class="input" value="<?=$update_page_display->page_heading?>" /></td>
        <tr>
          <td align="left" valign="top">Parent Page (required):</td>
          <td align="left" valign="top">Meta Description:</td>
        </tr>
        <tr>
          <td align="left" valign="top"><select class="styled select" name="parent_page">
              <option value="0" <?php echo set_select('parent_page', '0', TRUE); ?>>(no parent)</option>
              <?php	foreach ($parentpages as $row){
				$optparent = ($update_page_display->parent_page == $row->id ? true : false);
			  ?>
              <option value="<?php echo $row->id; ?>" <?php echo set_select('parent_page', $row->id, $optparent); ?>><?php echo $row->page_title; ?></option>
              <?php } ?>
            </select></td>
          <td align="left" valign="top" rowspan="3"><textarea class="textarea description" id="meta_description" name="meta_description" placeholder="Meta Description goes here" ><?=$update_page_display->meta_description?>
</textarea></td>
        </tr>
        <tr>
          <td align="left" valign="top">Display On:</td>
        </tr>
        <tr>
          <td align="left" valign="top"><select class="styled select" name="display_on" >
              <option value=""> Select Area </option>
              <option value="1" <?php if($update_page_display->display_on == '1') echo 'selected="selected"'; ?> >Header</option>
              <option value="2" <?php if($update_page_display->display_on == '2') echo 'selected="selected"'; ?>  >Footer</option>
              <option value="3" <?php if($update_page_display->display_on == '3') echo 'selected="selected"'; ?>  >Header & Footer</option>
              <option value="4" <?php if($update_page_display->display_on == '4') echo 'selected="selected"'; ?>  >Other</option>
            </select></td>
        </tr>
        <tr>
          <td align="left" valign="top">Page Content : <span class="reqired"> *</span></td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2"><textarea name="page_content" cols="200" rows="200" id="page_content" style="width:550px; height:400px;"><?=$update_page_display->page_content?>

					</textarea></td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2" ><input type="submit" value="Update It" class="submit left" /></td>
        </tr>
        </tbody>
        
      </table>
    </form>
  </div></td>
