<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/clients/all_clients'?>">Client &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Client Name:<span class="reqired"> *</span></td>
                <td align="left" valign="top">User Type:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="client_name" placeholder="Client Name" value="<?=($client->client_name) ? ($client->client_name) :  set_value('client_name')?>" class="input <?php if(form_error('client_name')){ echo 'error'; } ?>"/>
                </td>
                  
                <td align="left" valign="top">
                   <select class="styled select" name="user_type">
						<option value="2">2</option>
						<option value="0">0</option>
				   </select>
                </td>
                  
              </tr>
              
              <tr>
                <td align="left" valign="top">Price Unit:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Status:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="unit_price" placeholder="unit price" value="<?=($client->unit_price) ? ($client->unit_price) :  set_value('unit_price')?>" class="input <?php if(form_error('priceFormate')){ echo 'error'; } ?>"/>
                </td>
                
                 <td align="left" valign="top">
                   <select  class="styled select" name="status">
						<option value="1"  <?=($client->status == '1') ? "Selected='selected'" :  "" ?> >Active</option>
						<option value="0"  <?=($client->status == '0') ? "Selected='selected'" :  "" ?> >Inactive</option>
					</select>
                </td>  
                  
                
              </tr>
             <tr>
				<input type="hidden" name="client_id" value="<?php echo $client->id ?>" >
                <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
  </div></td>
