<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/Plans/all_Plans'?>"> Plan &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Plan Title:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Plan Price:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="name" placeholder="Plan Title" value="<?=($plan->name) ? ($plan->name) :  set_value('name')?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>"/>
                </td>
                  
                <td align="left" valign="top">
                    <input type="text"name="price" placeholder="Plan Price" value="<?=($plan->price) ? ($plan->price) :  set_value('price')?>" class="input <?php if(form_error('price')){ echo 'error'; } ?>"/>
                </td>
                  
              </tr>
              
              <tr>
                <td align="left" valign="top">Price Formate:<span class="reqired"> *</span></td>
                <td align="left" valign="top">Valid Month</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="priceFormate" placeholder="Price Formate" value="<?=($plan->priceFormate) ? ($plan->priceFormate) :  set_value('priceFormate')?>" class="input <?php if(form_error('priceFormate')){ echo 'error'; } ?>"/>
                </td>
                
                 <td align="left" valign="top">
                    <input type="text"name="month" placeholder="Month" value="<?=($plan->month) ? ($plan->month) :  set_value('month')?>" class="input <?php if(form_error('month')){ echo 'error'; } ?>"/>
                </td>  
                  
                
              </tr>
              
              <tr>
                <td align="left" valign="top">Total Properties Limit Listings</td>
                <td align="left" valign="top">Description :<span class="reqired"> *</span></td>
                
              </tr>
              
              <tr>
                 
                  <td align="left" valign="top">
                    <input type="text"name="totalproperties" placeholder="Total Properties" value="<?=($plan->totalproperties) ? ($plan->totalproperties) :  set_value('totalproperties')?><?=set_value('totalproperties')?>" class="input <?php if(form_error('totalproperties')){ echo 'error'; } ?>"/>
                </td>      
                      
                  <td align="left" valign="top" rowspan="3">
                      <textarea class="textarea description" id="description" name="description" placeholder="Description goes here" >
                          <?=($plan->description) ? ($plan->description) :  set_value('description')?>
                      </textarea>
                  <input type="hidden" name="plan_id" value="<?=$plan->id?>"/>
                  
                  </td>
              </tr>     
              
              <tr>
                <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
  </div></td>
