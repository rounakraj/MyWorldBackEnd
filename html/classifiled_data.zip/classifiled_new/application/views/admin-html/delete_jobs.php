<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
       $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "admin-html/images/ico9.png",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  });
  
  var myVar = setInterval(myTimer, 1000);
	function myTimer() {
		var d = new Date();
		document.getElementById("date_time").value = d.toLocaleTimeString();
	}
</script>
  
  
  
<td width="80%" align="left" valign="top">
<div class="rightPnl">
	<div class="brdCumbPnl">
	  <p><a href="#url">Admin Dashboard</a></p>
	  <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> 
	</div>
    <table class="dashboard">
      <tbody>
      <tr>
	  <td width="50%">
	   <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">Jobs Status For:<span class="reqired"> *</span></td>
				<td align="left" valign="top">Last refreshed at:</td>
				<td align="left" valign="top"></td>
              </tr>
              
              <tr>
				<td align="left" valign="top">
				<input type="text"name="name" id="datepicker" placeholder="Client Name" value="<?php echo date("d/m/Y");  ?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>">
				</td>
				<td align="left" valign="top">
				<input type="text"name="date_time" id="date_time" value="" class="input">
				</td>
				<td align="left" valign="top"> <input style="font: 14px 'proxima_nova_rgregular' !important" type="submit" value="Click to View/Refresh Status" class="submit left" /></td>
			</tr>
			
            </tr>
         </tbody>
        
      </table>
    </form>
		</td>
	</tr>
			
	</table>
	
  </div>
  </td>