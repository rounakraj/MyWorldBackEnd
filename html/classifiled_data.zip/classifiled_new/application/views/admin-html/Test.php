<?php 

	$csrf = array(
        'name' => $this->security->get_csrf_token_name(),
        'hash' => $this->security->get_csrf_hash()
);

?>



<?php echo form_open('',array( 'id' => 'login', 'class' => 'login' ));?>
<input type="text" name="username" />
<input type="hidden" name="token" value="<?=$csrf['hash'];?>" />
<input type="password" name="password" />
<input type="submit" name="submit" value="Submit" />
<?php echo form_close();?>
