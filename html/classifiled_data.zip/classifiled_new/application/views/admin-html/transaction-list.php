<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/transaction/lists'?>"> <?php echo $title ?>  &raquo; </a>
        <?=$title?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/search-form"); ?>
    <form name="iform1" action="" id="iform1" method="post" enctype="multipart/form-data">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabCht1">
        <thead>
          <tr>
           
            <th align="left" valign="top" >Sub Id</th>
            <th align="left" valign="top" >Plan</th>
            <th align="left" valign="top" >Order Id</th>
            <th align="center" valign="top" >Amount</th>
            <th align="center" valign="top" >Date</th>
            <th align="center" valign="top" >Status</th>
            <th align="center" valign="top" >Response Data</th>
              
           <!-- <th align="left" valign="top" >Order</th>-->
          </tr>
        </thead>
        <tbody>
          <?php if($result){ ?>
          <?php foreach($result as $row): 

				if($row['status'] == 'TXN_SUCCESS'){

					$status = '0';

					$image_path  = base_url().'admin-html/images/active.png';		

					$image_path = $image_path;	

					$image_path = '<img src="'.$image_path.'">';				

				}else {

					$image_path  = base_url().'admin-html/images/inactive.png';	

					$status = '1';

					$image_path = '<img src="'.$image_path.'">';	

				}?>
          <tr>
            <td align="left" valign="top"><input type="checkbox" name="chk[]" value="<?php echo $row['id'];?>" class="chk_id" />
              <?php echo $row['subscriber_id'];?></td>
              
            <td align="left" valign="top" ><?php echo $row['plan'];?></td>
            <td align="left" valign="top" ><?php echo $row['orderId'];?></td>
            <td align="left" valign="top" ><?php echo $row['amount'];?></td>
            <td align="left" valign="top" ><?php echo $row['date'];?></td>
            <td align="left" valign="top" ><?php echo $row['status'];?></td>
              <?php $tt = strip_tags($row['responsedata']) ?> 
            <td align="left" valign="top" title='<?php echo $tt ; ?>' >   <?php echo substr($row['responsedata'],0,10);?></td>
              
              
            
          
          <?php endforeach;  ?>
          <?php }else{ ?>
			  <tr>
            <td align="center" valign="top" colspan="5">No record founds!
            </td>
		 <?php } ?>
        </tbody>
      </table>
    </form>
    <?php if($result) : ?>
    <div class="btmButtonPnl">
      <div class="delBtn"><a href="javascript:void(0)" onclick="deleteFrom();">Delete selected</a></div>
      <div class="inBtn"><a href="javascript:void(0)" onclick="makeInactive();">Make Inactivie</a></div>
      <div class="actBtn"><a href="javascript:void(0)" onclick="makeActive();">Make Activie</a></div>
    </div>
    <?php endif; ?>
    <div class="pagintPnl">
      <ul>
        <?php echo $links; ?>
      </ul>
    </div>
  </div></td>
<script type="text/javascript">



function deleteFrom(){

	 var action =  "<?=site_url("admin/transaction/delmul/");?>";

	if ($(".chk_id:checked").length > 0){

		

		total = $(".chk_id:checked").length ;

		if(confirm("Do You Want to delete all ")){

		document.iform1.action = action;

		$("#iform1").submit();

		}

		}

		else{

		alert("Please, First Checked  One Or More Lists.");

		}

} 



function makeActive(){

	var action =  "<?=site_url("admin/transaction/makeChangeStatus/1");?>";

	if ($(".chk_id:checked").length > 0){

		document.iform1.action = action;

		$("#iform1").submit();

		}

		else{

		alert("Please, First Checked  One Or More Lists.");

		}

} 



function makeInactive(){

	var action =  "<?=site_url("admin/transaction/makeChangeStatus/0");?>";

	if ($(".chk_id:checked").length > 0){

			document.iform1.action = action;

			$("#iform1").submit();

		}

		else{

		alert("Please, First Checked  One Or More Lists.");

		}

} 
				 

$(function(){

	

	 $("#allchk").click(function () {

	 

	        $('input[type=checkbox]').prop('checked', $(this).prop('checked'));

	  });

	 



});	

		

</script>
