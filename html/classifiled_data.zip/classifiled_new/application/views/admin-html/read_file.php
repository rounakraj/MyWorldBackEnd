<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
       $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "admin-html/images/ico9.png",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  });
  
  var myVar = setInterval(myTimer, 1000);
	function myTimer() {
		var d = new Date();
		document.getElementById("date_time").value = d.toLocaleTimeString();
	}
</script>
<td width="80%" align="left" valign="top">
<div class="rightPnl">
	<div class="brdCumbPnl">
	  <p><a href="#url">Admin Dashboard</a></p>
	  <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> 
	</div>
    <table class="dashboard">
      <tbody>
      <tr>
	  <td width="50%">
	   <form action="" method="post">
      <table style="border-collapse: collapse" id="AutoNumber3" width="93%" height="1" cellspacing="0" cellpadding="0" bordercolor="#111111" border="0">
      <tbody><tr>
        <td width="22%" height="25"><b><i>
        <font size="2" color="#000080" face="Verdana">&nbsp;</font></i></b></td>
        <td width="6%" height="25">&nbsp;</td>
        <td width="152%" height="25">&nbsp;</td>
      </tr>
      <tr>
        <td width="22%" height="25"><b><i>
        <font size="2" color="#000080" face="Verdana">&nbsp;</font></i></b></td>
        <td width="6%" height="25">&nbsp;</td>
        <td width="152%" height="25">&nbsp;</td>
      </tr>
      <tr>
        <td width="22%" height="25"><b><i>
        <font size="2" color="#000080" face="Verdana">&nbsp; </font></i></b></td>
        <td width="6%" height="25">&nbsp;</td>
        <td width="152%" height="25">&nbsp;</td>
      </tr>
      <tr>
        <td width="22%" height="25"><b><font size="2" color="#000080">
        <font face="Verdana"><i>Welcome!!</i></font></font></b></td>
        <td width="6%" height="25">&nbsp;</td>
        <td width="152%" height="25"><b><font size="2" color="red">
        <font face="Verdana"><i>Please enter the complete path to get files.</i></font></font></b></td>
      </tr>
      <tr>
        <td width="22%" height="1"></td>
        <td width="6%" height="1">     </td>
        <td width="152%" height="1"><input name="PathName" size="63" value="" type="text"></td>
      </tr>
      <tr>
        <td width="22%" height="1"></td>
        <td width="6%" height="1">     </td>
        
        
        <td width="152%" height="1"><font size="1" color="Green">Eg: C:\DownloadFiles\IQMax\Jobs</font></td>
        
      </tr>
      <tr>
        <td width="22%" height="1"></td>
        <td width="6%" height="1">     </td>
        <td width="152%" height="1"><b>Download Date:</b>
		<input name="DownloadDT" readonly=""  size="11" value="" type="text" id="datepicker">
        <b>
        &nbsp; Download Time:</b> <input name="DownloadTime"  size="11" value="<?=date("H:i:s");?>" type="text"></td>
      </tr>
      <tr>
        <td width="22%" height="1"></td>
        <td width="6%" height="1">     </td>
        <td width="152%" height="1"><b>Add File Extension:</b><input name="FileEXT" value="ON" type="checkbox"><font size="2" color="Red"> Must Check for .d## file and without Extension files</font></td>
      </tr>
      <tr>
        <td width="22%" height="1"></td>
        <td width="6%" height="1">     </td>
        <td width="152%" height="1"><b>Affix before file name:</b>
        <input name="FileAffix" size="11" value="" type="text">
        <input value="Click to get file" class="submit" style="width: 150px;height: 25px; background: #303030; border-radius: 3px;margin: 0px 0px 8px 0px; border: none; color: #EFC70B; font: 20px 'proxima_nova_rgregular'; text-align: center;cursor: pointer;" name="Submit" onclick="return Validate()" type="submit"></td>
      </tr>
      <tr>
        <td width="22%" height="54" background="../Picture/homeglobe.jpg">&nbsp;</td>
        <td width="6%" height="54">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     </td>
        <td width="152%" height="54"><p>


</p>
       
<table style="border-collapse: collapse" id="AutoNumber1" width="94%" cellspacing="3" cellpadding="0" bordercolor="#111111" border="0">
	<tbody>
		<tr>
		<td width="44%" bgcolor="#C0C0C0"><b><font size="2" color="red">Invalid Folder name!folder not Exists</font></b>
		</td>
		</tr>
	</tbody>
</table>

&nbsp;<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
&nbsp;</td></tr></tbody></table>


    </form>
		</td>
	</tr>
			
	</table>
	
  </div>

	<?php
		/*
		date_default_timezone_set('Asia/Kolkata');
		$files = array();
		$path = ($this->input->post('path'))? $this->input->post('path') : 'payment/PaytmApp/';   
		$dir = new DirectoryIterator($path);
		
		foreach($dir as $fileinfo) {
			$time = filemtime("payment/PaytmApp/".$fileinfo->getFilename());
			$files[$time] = $fileinfo->getFilename();
		}
		
		
		krsort($files);
		*/ 
		
		if($files){
		?>
		<table width="80%" align="center" class="tabCht1"> 
		<form name="iform1" action="" id="iform1" method="post" enctype="multipart/form-data">
		<thead>
		<tr> <th width="20%" align="left">  <input type="checkbox" name="allchk[]" id="allchk" value=""  /> File Name </th> <th width="20%" align="left"> Date and Time </th> </tr>
		<input type="text" name= "download_date"  id="download_date" value="<?php echo $download_date ?>"> 
		<input type="text" name= "download_time"  id="time" value="<?php echo $download_time ?>"> 
		
		</thead>
		<?php 
			$i =0;
			foreach($files as $file){
				
				echo '<tr> <td width="20%" align="left"> <input type="checkbox" name="chk[]" value="'.$i .'" class="chk_id" />  <strong>'.$file["file_name"]. '</strong></td> <td width="20%" align="left"> <strong>'.date("F d Y.",$file["download_date"]).'</strong> <input type="text" name="jobname[]" value ="'.$file["base_file_name"].'"></td>';  
				$i++;
			}
		
		
		} ?>
		
		<tr>
			<td align="left">
			
			<?php ?>
			<select class="styled select" name="client_id" style="width: 71%; background: #f7f7f7; padding: 10px; border: 1px solid #ccc; border-radius: 7px;">
				<option value=""selected="selected" > Select Client</option>
				<?php foreach($Allclients as $obj) {  ?>
				<option value="<?=$obj->id ?>" ><?=$obj->client_name?> </option>
				<?php } ?>
			</select>
			</td>
			<td> 
			
			<div class="btmButtonPnl">
				<div class="inBtn"><a href="javascript:void(0)" onclick="makeInactive();">Submit</a></div>
			</div>
			
			</td>
		</tr>
			</form>
	  </table>			
 </td>
 
 <script> 
 
 
function makeInactive(){

	var action =  "<?=site_url("admin/job/addJobs/");?>";
	
	alert(action);

	if ($(".chk_id:checked").length > 0){

		document.iform1.action = action;

		$("#iform1").submit();

		}

		else{

		alert("Please, First Checked  One Or More Lists.");

		}

} 

$(function(){
	$("#allchk").click(function () {
			$('input[type=checkbox]').prop('checked', $(this).prop('checked'));
	});
	
	$("#datepicker").change(function(){
		alert($(this).val());
		$("download_date").value = $(this).val(); 
	})
});	
 
 
 
 </script>