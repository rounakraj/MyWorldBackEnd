<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
        <p>
            <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> 
            <a href="<?=base_url().'admin/user/allUsers'?>"> Users &raquo; </a><?=$title;?>
        </p>
         <?php echo $this->load->view("admin-html/include/view-site-icon"); ?>
    </div> 
    <!------------------>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
		<?php echo form_open(); ?>
    <table class="add_leader">
      <tbody>
        <tr>
          <td align="left" valign="top">Name:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Login Description:<span class="reqired"> *</span></td>          
        </tr>
		
        <tr>
          
			<td align="left" valign="top">
				<input type="text" name="name" value="<?=set_value('name')?>" class="input <?php if(form_error('name')){ echo 'error'; } ?>" />
			</td>
			       
         
		 <td align="left" valign="top">
			<input type="text" name="login_desc" value="<?=set_value('login_desc')?>" class="input <?php if(form_error('login_desc')){ echo 'error'; } ?>" />
			<br> <strong> (E.g. MT, QA, MT_QA etc.) </strong>
		</td>
          
        </tr>
        
		<tr>
          <td align="left" valign="top">Username:<span class="reqired"> *</span></td>
          <td align="left" valign="top">MT-QA:<span class="reqired"> *</span></td>
        </tr>
		
        <tr>
			<td align="left" valign="top">
				<input type="text" name="username" value="<?=set_value('username')?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" />
			</td>          
			<td align="left" valign="top">
				<select class="styled select" name="MTQA">
					<option value="1">True</option>
					<option value="0">False</option>
				</select>
			</td>
		</tr>
        
		<tr>          
          <td align="left" valign="top">Password :</td>
          <td align="left" valign="top">MT-QA User Name:</td>  
        </tr>
        <tr>
			<td align="left" valign="top">
				<input type="text" name="password" value="" class="input"  />
			</td>
			<td align="left" valign="top">
				<input type="text" name="MTQAUSER" value="" class="input"  />
			</td>
	    </tr>
		
        <tr>
          <td align="left" valign="top">Login Type:</td>
          <td align="left" valign="top">Franchise User Name:</td>
        </tr>
        
		<tr>
          <td align="left" valign="top">
		  
		  <!--  1 for MT, 2 for QA, 3 for SUP, 4 for Engineer, 5 for Admin -->
		  
            <select class="styled select" name="user_type">
               <option value="5">Admin</option>
               <option value="4">Engineer</option>
               <option value="3">SUP</option>
               <option value="2">QA</option>
               <option value="1">MT</option>
            </select>
          </td>
          <td align="left" valign="top"><input type="text" name="FranchiseUserName" value="" class="input" /></td>
          
		 
        </tr>
       
        <tr>
          <td></td>
        </tr>
        <tr>
          <td align="left" valign="top"><input type="submit" value="Submit" class="submit" /></td>
        </tr>
      </tbody>
    </table>
    </form>
    <!------------------> 
  </div></td>
