<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/doctors/all_doctors'?>">Edit Job &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <form action="" method="post">
      <table class="add_leader">
          <tbody>
               <tr>
                <td align="left" valign="top">JobFiles:</td>
                <td align="left" valign="top">Import(IST):</td>
                <td align="left" valign="top">MT:</td>
				<td align="left" valign="top">MT Line65:</td>
              </tr>
              
              <tr>
                <td align="left" valign="top">
                    <input type="text"name="JobFileName"  value="<?=($job->JobFileName) ? ($job->JobFileName) :  set_value('JobFileName')?>" class="input <?php if(form_error('JobFileName')){ echo 'error'; } ?>"/>
                </td>
				
				 <td align="left" valign="top">
                    <input type="text"name="MTTimeIn" value="<?=($job->MTTimeIn) ? ($job->MTTimeIn) :  set_value('MTTimeIn')?>" class="input <?php if(form_error('MTTimeIn')){ echo 'error'; } ?>"/>
                </td>
                 
				 <td align="left" valign="top">
                    <input type="text"name="MT"  value="<?=($job->MT) ? ($doctor->MT) :  set_value('MT')?>" class="input <?php if(form_error('MT')){ echo 'error'; } ?>"/>
                </td>
				
				<td align="left" valign="top">
                    <input type="text"name="MTTotLine_65"  value="<?=($job->MTTotLine_65) ? ($job->MTTotLine_65) :  set_value('MTTotLine_65')?>" class="input <?php if(form_error('MTTotLine_65')){ echo 'error'; } ?>"/>
                </td>
                 
				 
               </tr>
              
			  <tr>
                <td align="left" valign="top">MTNormal:</td>
                <td align="left" valign="top">QA:</td>
                <td align="left" valign="top">QA Line65:</td>
                <td align="left" valign="top">QANormal:</td>
              </tr>
              
			  <tr>
                <td align="left" valign="top">
                    <input type="text"name="MTTotLine_normal"  value="<?=($job->MTTotLine_normal) ? ($job->MTTotLine_normal) :  set_value('MTTotLine_normal')?>" class="input <?php if(form_error('MTTotLine_normal')){ echo 'error'; } ?>"/>
                </td>
				
				 <td align="left" valign="top">
                    <input type="text"name="QA" value="<?=($job->QA) ? ($job->QA) :  set_value('QA')?>" class="input <?php if(form_error('QA')){ echo 'error'; } ?>"/>
                </td>
				
				
				 <td align="left" valign="top">
                    <input type="text"name="QATotLine_65"  value="<?=($job->QATotLine_65) ? ($job->QATotLine_65) :  set_value('QATotLine_65')?>" class="input <?php if(form_error('QATotLine_65')){ echo 'error'; } ?>"/>
                </td>
                 
				
				
				<td align="left" valign="top">
                    <input type="text"name="QATotLine_normal"  value="<?=($job->QATotLine_normal) ? ($job->QATotLine_normal) :  set_value('QATotLine_normal')?>" class="input <?php if(form_error('QATotLine_normal')){ echo 'error'; } ?>"/>
                </td>
                 
				 
               </tr>
              
			  
              <tr>
				<input type="hidden" name="job_id" value="<?php echo $job->id ?>" >
                <td align="left" valign="top" colspan="2" ><input type="submit" value="Submit" class="submit left" /></td>
              </tr>
         </tbody>
        
      </table>
    </form>
  </div></td>
