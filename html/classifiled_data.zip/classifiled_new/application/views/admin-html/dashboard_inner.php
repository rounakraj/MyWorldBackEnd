<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="#url">Admin Dashboard</a></p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <table class="dashboard">
      <tbody>
        <tr>
        	<td align="left" valign="top"><a href="<?php echo base_url().'admin/user'?>" class="student">User</a></td>
            <td align="left" valign="top"><a href="<?php echo base_url().'admin/pages/all_pages'?>" class="static_pages">CMS Page</a></td>
          <td align="left" valign="top"><a href="<?php echo base_url().'admin/dashboard/siteInfo'?>" class="setting">Setting</a></td>
        </tr>
      </tbody>
    </table>
  </div></td>