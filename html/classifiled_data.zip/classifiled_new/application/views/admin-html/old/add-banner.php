<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/banner/lists'?>"> Banner &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?> 
	<?php echo form_open_multipart(); ?>
    <table class="add_leader">
      <tbody>
        <tr>
          <td align="left" valign="top">Banner Title :<span class="reqired"> *</span></td>
          <td align="left" valign="top">Alt:</td>
        </tr>
        <tr>
          <td align="left" valign="top">
          	<input type="text" name="title" value="<?=set_value('title')?>" class="input <?php if(form_error('title')){ echo 'error'; } ?>" style="width:50%;" />
          </td>
          <td align="left" valign="top">
          	<input type="text" name="alt" value="<?=set_value('alt')?>" class="input <?php if(form_error('alt')){ echo 'error'; } ?>" style="width:60%;" />
          </td>
        </tr>
        <tr>
          <td align="left" valign="top">Width (in pixel):<span class="reqired"> *</span></td>
          <td align="left" valign="top">Height (in pixel):<span class="reqired"> *</span></td>
        </tr>
        <tr>
          <td align="left" valign="top">
          	<input type="text" name="width" value="<?=set_value('width')?>" class="input <?php if(form_error('width')){ echo 'error'; } ?>" style="width:50%;" />
            <?=form_error('width');?>
          </td>
          <td align="left" valign="top">
          	<input type="text" name="height" value="<?=set_value('height')?>" class="input <?php if(form_error('height')){ echo 'error'; } ?>" style="width:60%;" />
            <?=form_error('height');?>
          </td>
        </tr>
        <tr>
          <td align="left" valign="top">Caption : </td>
          <td align="left" valign="top">Select Image : </td>
          
        </tr>
        <tr>
        	<td align="left" valign="top" ><div style="width: 350px;; height: 200px;" class="input <?php if(form_error('caption')){ echo "error"; } ?>">
           <textarea name="caption" id="page_content" style="width:350px; height:200px;"><?=set_value('caption')?></textarea>
            </div>
            <br></td>
          <td align="left" valign="top">
          	<input type="file" name="banner[]" class="" value="" multiple />
          </td>
        </tr>
        
        <tr>
          <td></td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" /></td>
        </tr>
      </tbody>
    </table>
    <?php echo form_close();?> </div></td>
