<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/sub_category/listing'?>"> Sub Category &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
    <?php echo form_open_multipart(); ?>
      <table class="add_leader">
        <tbody>
          <tr>
            <td align="left" valign="top">Title:<span class="reqired"> *</span></td>
            <td align="left" valign="top">Meta Keywords:</td>
          </tr>
          <tr>
            <td align="left" valign="top"><input type="text"name="title" placeholder="Sub Category Title" value="<?=set_value('title')?>" class="input <?php if(form_error('title')){ echo 'error'; } ?>"  /></td>
            <td align="left" valign="top" rowspan="3"><textarea class="textarea description" placeholder="Meta Keywords" name="meta_keywords"><?=set_value('meta_keywords')?></textarea></td>
          </tr>
          <tr>
            <td align="left" valign="top">Page Heading:</td>
          </tr>
        <td align="left" valign="top"><input type="text" name="page_heading" class="input" value="<?=set_value('page_heading')?>" placeholder="Page Heading"/></td>
        <tr>
          <td align="left" valign="top">Is Active:</td>
          <td align="left" valign="top">Meta Description:</td>
        </tr>
        <tr>
          <td align="left" valign="top">
              <select name="status" class="styled select">
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select></td>
          <td align="left" valign="top" rowspan="3"><textarea class="textarea description" id="meta_description" name="meta_description" placeholder="Meta Description goes here" ><?=set_value('meta_description')?></textarea></td>
        </tr>
        <tr>
          <td align="left" valign="top">Image:</td>
        </tr>
        <tr>
          <td align="left" valign="top"> <input id="uploadBtn" type="file" class="upload" name="image" /></td>
        </tr>
        <tr>
          <td align="left" valign="top">Description : </td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2"><div style="width: 670px;; height: 425px;" <?php if(form_error('description')){ echo 'class="error"'; } ?>>
           <textarea name="description" cols="200" rows="200" id="page_content" style="width:550px; height:400px;"><?=set_value('description')?></textarea>
            </div>
            <br></td>
        </tr>
        <tr>
          <td align="left" valign="top" colspan="2" ><input type="submit" value="<?=$title?>" class="submit left" name="submit" /></td>
        </tr>
        </tbody>
        
      </table>
    </form>
  </div></td>
