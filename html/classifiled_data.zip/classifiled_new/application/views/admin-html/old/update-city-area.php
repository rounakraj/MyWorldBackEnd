<td width="80%" align="left" valign="top"><div class="rightPnl">
<div class="brdCumbPnl">
<p>
	<a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> 
 	<a href="<?=base_url().'admin/city_area/all'?>"> City Area &raquo; </a><?=$title;?>
</p>
<?php echo $this->load->view("admin-html/include/view-site-icon"); ?>
</div> 
		<?php echo $this->load->view("admin-html/include/validation-error");?>
		<?php echo form_open('admin/city_area/update/'.$detail->id); ?>
        <table class="add_leader">
      <tbody>
        <tr>
          <td align="left" valign="top">City Name:<span class="reqired"> *</span></td>
          
          <td align="left" valign="top">City Area Name:<span class="reqired"> *</span></td>
                
        </tr>
        <tr>
          
          <td align="left" valign="top">
        	<select name="city_id" class=" styled select <?php if(form_error('city_id')){ echo 'error'; }?>" >
        		<option value="" > Select City </option>
        		<?php foreach($city_detail as $obj) { ?>
        			<option value="<?php echo $obj->id?>" ><?php echo $obj->city_name?> </option>
        		<?php } ?>
        	</select>
        	
        </td>
          
          <td align="left" valign="top"><input type="text" name="area_name" value="<?=$detail->area_name?>" class="input <?php if(form_error('city_name')){ echo 'error'; } ?>" />
        </tr>
       
        <tr>
          <td align="left" valign="top"><input type="submit" value="Submit" class="submit" /></td>
        </tr>
      </tbody>
    </table>
    
         </form>
        </div></td>
  