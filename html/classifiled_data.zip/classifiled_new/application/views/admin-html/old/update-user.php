<td width="80%" align="left" valign="top"><div class="rightPnl">
<div class="brdCumbPnl">
<p>
	<a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> 
 	<a href="<?=base_url().'admin/user/allUsers'?>"> User &raquo; </a><?=$title;?>
</p>
<?php echo $this->load->view("admin-html/include/view-site-icon"); ?>
</div> 
		<?php echo $this->load->view("admin-html/include/validation-error");?>
		<?php echo form_open('admin/user/update/'.$user_detail->id); ?>
        <table class="add_leader">
      <tbody>
        <tr>
          <td align="left" valign="top">Name:<span class="reqired"> *</span></td>
          
          <td align="left" valign="top">Email:<span class="reqired"> *</span></td>          
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="name" value="<?=$user_detail->name?>" class="input <?php if(form_error('nmae')){ echo 'error'; } ?>" /></td>
              
          <td align="left" valign="top"><input type="text" name="email" value="<?=$user_detail->email?>" class="input <?php if(form_error('email')){ echo 'error'; } ?>" /></td>
          
        </tr>
        <tr>
          <td align="left" valign="top">Username:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Password:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Confirm Password:<span class="reqired"> *</span></td>
          
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="username" value="<?=$user_detail->username?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" readonly="readonly" /></td>          
          <td align="left" valign="top"><input type="text" name="password" value="<?=$this->encrypt->decode($user_detail->password)?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" /></td>
          <td align="left" valign="top"><input type="text" name="conf_pass" value="<?=$this->encrypt->decode($user_detail->password)?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" /></td>
         
        </tr>
        <tr>          
          <td align="left" valign="top">Address:</td>
          <td align="left" valign="top">Zip Code:</td>  
          <td align="left" valign="top">Country:</td>        
        </tr>
        <tr>
          <td align="left" valign="top"><textarea name="address" rows="3" cols="37" class="input" ><?=$user_detail->address?></textarea></td>
          <td align="left" valign="top"><input type="text" name="zipcode" value="<?=$user_detail->zipcode?>" class="input"  /></td>
          <td align="left" valign="top">
          	<select class="styled select" name="country_id">
              <option value="">Select Country</option>
              <?php if($countryDetail):
			  	foreach($countryDetail as $countryObj): ?>
			  <option value="<?=$countryObj->country_id?>" <?php if($user_detail->country_id==$countryObj->country_id){ echo 'selected="selected"'; } ?>><?=$countryObj->name?></option>
			 <?php endforeach;
			  endif;
			  ?>              
            </select>
          </td>
        </tr>
        <tr>
          <td align="left" valign="top">Phone:</td>
          <td align="left" valign="top">Mobile:</td>
          <!--<td align="left" valign="top">Select Sex:</td>
          <td align="left" valign="top">Role :</td>-->
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="phone" value="<?=$user_detail->phone?>" class="input" /></td>
          <td align="left" valign="top"><input type="text" name="mobile" value="<?=$user_detail->mobile?>" class="input" /></td>
         <!--
          <td align="left" valign="top">
            <select class="styled select" name="user_type">
               <option value="Admin" <?php if($user_detail->user_role == 'Admin'){ echo 'selected="selected"'; } ?>>Admin</option>
               <option value="Super Admin" <?php if($user_detail->user_role == 'Super Admin'){ echo 'selected="selected"'; } ?>>Super Admin</option>
            </select>
          </td>-->
          
        </tr>
        <!--<tr>
          <td align="left" valign="top">Send Mail:</td>          
        </tr> 
        <tr>
          <td align="left" valign="top">
          <input type="checkbox" value="1" id="send_password" name="send_password"> Send this password to the new user by email.</td>         
        </tr>
        <tr>
          <td></td>
        </tr>-->
        <tr>
          <td align="left" valign="top"><input type="submit" value="Submit" class="submit" /></td>
        </tr>
      </tbody>
    </table>
    
         </form>
        </div></td>
  