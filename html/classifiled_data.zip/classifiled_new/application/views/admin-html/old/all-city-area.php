<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p><a href="<?=base_url().'admin/dashboard'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/city_area/all'?>"> City Area&raquo; </a>
        <?=$title?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/search-form"); ?>
    <form name="iform1" action="" id="iform1" method="post" enctype="multipart/form-data">
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabCht1">
        <thead>
          <tr>
            <th align="left" valign="top" > <input type="checkbox" name="allchk" id="allchk" value=""  />
              <a href="<?=$action.$order;?>" style="color:#fff"> Araa Name
              <?php if($order == 'DESC') { echo '<img src="'.base_url().'admin-html/images/down.png" style="margin:3px;position:absolute">'; } else {

				 echo '<img src="'.base_url().'admin-html/images/up.png" style="margin:3px;position:absolute">';

				} ?>
              </a> </th>
            
            <th align="left" valign="top">City Name</th>
            <th align="left" valign="top">Status</th>
            <th align="right" valign="top">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if($result) { ?>
          <?php foreach($result as $row){ 

				if($row['status'] == 'active'){

					$status = 0;

					$image_path  = base_url().'admin-html/images/active.png';		

					$image_path = $image_path;	

					$image_path = '<img src="'.$image_path.'">';				

				}else {

					$image_path  = base_url().'admin-html/images/inactive.png';	

					$status = 1;

					$image_path = '<img src="'.$image_path.'">';	

				}?>
          <tr>
            <td align="left" valign="top"><input type="checkbox" name="chk[]" value="<?php echo $row['id'];?>" class="chk_id" />
              <?php echo $row['area_name'];?>
              
            </td>
            
             <td align="left" valign="top"> <?php echo $row['city_name'];?> </td> 
            <td><a href="<?=base_url().'admin/city_area/changeStatus/'.$row['id'].'/'.$status?>" >
              <?=$image_path?>
              </a>
            </td>
           
            <td align="left" valign="top" width="10%"><a href="<?=site_url("admin/city_area/del/".$row['id']);?>" class="ask"> <img src="<?php echo base_url()?>admin-html/images/closeIcon.png" class="cls" alt="" /></a> <a href="<?=site_url("admin/city_area/update/".$row['id']);?>"> <img src="<?php echo base_url()?>admin-html/images/editIcon.png" class="cls" alt="" /></a></td>
          </tr>
          <?php } ?>
          <?php }  ?>
        </tbody>
      </table>
    </form>
    <div class="btmButtonPnl">
      <div class="delBtn"><a href="javascript:void(0)" onclick="deleteFrom();">Delete selected</a></div>
      <div class="inBtn"><a href="javascript:void(0)" onclick="makeInactive();">Make Inactivie</a></div>
      <div class="actBtn"><a href="javascript:void(0)" onclick="makeActive();">Make Activie</a></div>
    </div>
    <div class="pagintPnl">
      <ul>
        <?php echo $links; ?>
      </ul>
    </div>
  </div></td>
<script type="text/javascript">

function deleteFrom(){
	 var action =  "<?=site_url("admin/city_area/delmul/");?>";
	if ($(".chk_id:checked").length > 0){
		total = $(".chk_id:checked").length ;
		if(confirm("Do You Want to delete all ")){
			document.iform1.action = action;
			$("#iform1").submit();
		}
	}
	else{
		alert("Please, First Checked  One Or More Lists.");
	}

} 

function makeActive(){

	var action =  "<?=site_url("admin/city_area/makeChangeStatus/1");?>";

		if ($(".chk_id:checked").length > 0){
			document.iform1.action = action;
			$("#iform1").submit();
		}

		else{
			alert("Please, First Checked  One Or More Lists.");

		}

} 

function makeInactive(){

	var action =  "<?=site_url("admin/city_area/makeChangeStatus/0");?>";

	if ($(".chk_id:checked").length > 0){

			document.iform1.action = action;

			$("#iform1").submit();

		}

		else{

		alert("Please, First Checked  One Or More Lists.");

		}

} 
					 

$(function(){
	$("#allchk").click(function () {
        $('input[type=checkbox]').prop('checked', $(this).prop('checked'));

	});
});	

</script>
