<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
        <p>
            <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> 
            <a href="<?=base_url().'admin/user/allUsers'?>"> Users &raquo; </a><?=$title;?>
        </p>
         <?php echo $this->load->view("admin-html/include/view-site-icon"); ?>
    </div> 
    <!------------------>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
		<?php echo form_open(); ?>
    <table class="add_leader">
      <tbody>
        <tr>
          <td align="left" valign="top">First Name:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Last Name:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Email:<span class="reqired"> *</span></td>          
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="first_name" value="<?=set_value('first_name')?>" class="input <?php if(form_error('first_name')){ echo 'error'; } ?>" /></td>
          <td align="left" valign="top"><input type="text" name="last_name" value="<?=set_value('last_name')?>" class="input <?php if(form_error('last_name')){ echo 'error'; } ?>" /></td>         
          <td align="left" valign="top"><input type="text" name="email" value="<?=set_value('email')?>" class="input <?php if(form_error('email')){ echo 'error'; } ?>" /></td>
          
        </tr>
        <tr>
          <td align="left" valign="top">Username:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Password:<span class="reqired"> *</span></td>
          <td align="left" valign="top">Confirm Password:<span class="reqired"> *</span></td>
          
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="username" value="<?=set_value('username')?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" /></td>          
          <td align="left" valign="top"><input type="text" name="password" value="<?=set_value('password')?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" /></td>
          <td align="left" valign="top"><input type="text" name="conf_pass" value="<?=set_value('conf_pass')?>" class="input <?php if(form_error('password')){ echo 'error'; } ?>" /></td>
         
        </tr>
        <tr>          
          <td align="left" valign="top">Address:</td>
          <td align="left" valign="top">Zip Code:</td>  
          <td align="left" valign="top">Country:</td>        
        </tr>
        <tr>
          <td align="left" valign="top"><textarea name="address" rows="3" cols="37" class="input" ></textarea></td>
          <td align="left" valign="top"><input type="text" name="zipcode" value="" class="input"  /></td>
          <td align="left" valign="top">
          	<select class="styled select" name="country_id">
              <option value="">Select Country</option>
              <?php if($countryDetail):
			  	foreach($countryDetail as $countryObj):
			  echo '<option value="'.$countryObj->country_id.'">'.$countryObj->name.'</option>';
			  endforeach;
			  endif;
			  ?>              
            </select>
          </td>
        </tr>
        <tr>
          <td align="left" valign="top">Phone:</td>
          <td align="left" valign="top">Mobile:</td>
          <!--<td align="left" valign="top">Select Sex:</td>-->
          <td align="left" valign="top">Role :</td>
        </tr>
        <tr>
          <td align="left" valign="top"><input type="text" name="phone" value="" class="input" /></td>
          <td align="left" valign="top"><input type="text" name="mobile" value="" class="input" /></td>
          <!--<td align="left" valign="top">
            <div class="left">
              <div class="radio" id="">
                <input type="radio" id="Male" name="gender" value="Male" checked >
              </div>
              <label for="male">Male</label>
            </div>
            <div class="left">
              <div class="radio" id="">
                <input type="radio" id="female" name="gender" value="Female">
              </div>
              <label for="female">Female</label>
            </div>
          </td>-->
          <td align="left" valign="top">
            <select class="styled select" name="user_type">
               <option value="admin">Admin</option>
               <option value="Super Admin">Super Admin</option>
            </select>
          </td>
        </tr>
        <tr>
          <td align="left" valign="top">Send Mail:</td>          
        </tr>
        <tr>
          <td align="left" valign="top">
          <input type="checkbox" value="1" id="send_password" name="send_password"> Send this password to the new user by email.</td>         
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr>
          <td align="left" valign="top"><input type="submit" value="Submit" class="submit" /></td>
        </tr>
      </tbody>
    </table>
    </form>
    <!------------------> 
  </div></td>
