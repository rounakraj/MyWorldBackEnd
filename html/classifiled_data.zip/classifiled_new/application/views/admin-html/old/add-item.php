<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce.js"></script>
<link rel="stylesheet" href="<?php echo base_url()?>admin-html/js/choose/chosen.css">

<script src="<?php echo base_url()?>/admin-html/js/choose/chosen.jquery.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?=base_url()?>admin-html/tiny_mce/tiny_mce_config.js"></script>-->
<?php $this->load->view('admin-html/editor'); ?>
<td width="80%" align="left" valign="top"><div class="rightPnl">
    <div class="brdCumbPnl">
      <p> <a href="<?=base_url().'admin/dashboard/'?>">Admin Dashboard &raquo;</a> <a href="<?=base_url().'admin/items/all'?>"> Items &raquo; </a>
        <?=$title;?>
      </p>
      <?php echo $this->load->view("admin-html/include/view-site-icon"); ?> </div>
    <?php echo $this->load->view("admin-html/include/validation-error"); ?>
   <?php //pr($vendor); ?>
    <?php //pr($city); ?>
    <form action="" method="post" enctype="multipart/form-data">
    	<input  type="hidden" name="item_id" value="<?=$item_data['id']?>"/>
      <table class="add_leader">
        <tbody>
          <tr>
            <td align="left" valign="top">Item name:<span class="reqired"> *</span></td>
            <td align="left" valign="top">Item Category:</td>
          </tr>
          <tr>
            <td align="left" valign="top">
            <input type="text"name="item_name" placeholder="Item Name" value="<?=$item_data['item_name'] ?> <?=set_value('item_name')?>" class="input <?php if(form_error('item_name')){ echo 'error'; } ?>"  />
            </td>
            <td align="left" valign="top" >
            
            <select name="item_category" id="item_category" class="styled select">
            	
            	<?php foreach($category as $obj) { ?>
            	<option value="<?php echo $obj->id?>" <?php if($item_data['category_id'] == $obj->id) { echo 'selected="selected"';} ?>  ><?php echo $obj->title?> </option>
            	<?php } ?>
            	
            </select>
            
            </td>
          </tr>

 			<tr>
            <td align="left" valign="top">Select Vdendor:<span class="reqired"> *</span></td>
            <td align="left" valign="top"><span class="reqired"> *</span>Select City:</td>
          </tr>
          <tr>
            <td align="left" valign="top">
            <select name="vendor" id="vendor" class="styled select <?php if(form_error('vendor')){ echo 'error'; } ?>">
            	<option value="">Selete Vendor</option> 	
            	<?php foreach($vendor as $obj) {  ?>
            	<option value="<?php echo $obj->id?>" <?php if($item_data['vendor_id'] == $obj->id) { echo 'selected="selected"';} ?>><?php echo $obj->name;?> </option>
            	<?php } ?>
            	
            </select>
            </td>
            <td align="left" valign="top" >
            
            <select name="city" id="city" class="styled select  <?php if(form_error('city')){ echo 'error'; } ?>">
            	<option value="" selected="">Selete City</option> 	
            	<?php foreach($city as $obj) {  pr($obj); ?>
            	<option value="<?php echo $obj->id?>" <?php if($item_data['city_id'] == $obj->id) { echo 'selected="selected"';} ?>><?php echo $obj->city_name;?> </option>
            	<?php } ?>
            	
            </select>
            
            </td>
          </tr>
        
        
        <tr>
            <td align="left" valign="top">Select City Ares:<span class="reqired"> *</span></td>
            <td align="left" valign="top">Item Details:<span class="reqired"> *</span></td>
          </tr>
          <tr>
            <td align="left" valign="top" >
            <?php $area_id = explode(',',$item_data['area_id']); ?>
            <?php $area_name = explode(',',$item_data['area_name']); ?>
            <select name="area[]" id="area" class="styled select chosen-select <?php if(form_error('area')){ echo 'error'; } ?> " multiple="TRUE">
            <?php for($i=0; $i< count($area_id); $i++ ){ ?>
            <option selected="selected" value="<?php echo $area_id[$i]?>" ><?php echo $area_name[$i]?></option> 	
            <?php } ?>	
            	
            </select>
            </td>
            <td align="left" valign="top">
            
            <textarea class="textarea description" id="item_details" name="item_details" placeholder="Item Details" ><?php echo $item_data['item_details']?><?=set_value('item_details')?></textarea>
            
            </td>
          </tr>
         
        <tr>
          <td align="left" valign="top">Item Price <span class="reqired"> *</span>:</td>
          <td align="left" valign="top">Item Offer Price:</td>
        </tr>
        <tr>
        
            <td align="left" valign="top">
            <input type="text"name="item_price" placeholder="Item Price" value="<?php echo $item_data['price']?><?=set_value('item_price')?>" class="input <?php if(form_error('item_price')){ echo 'error'; } ?>"  />
            </td>
           <td align="left" valign="top">
           <input type="text"name="item_offer_price" placeholder="Item Offer Price" value="<?php echo $item_data['offer_price']?><?=set_value('item_offer_price')?>" class="input"  /></td>
        </tr>
        
        <tr>
          <td align="left" valign="top">Item Image:<span class="reqired"> *</span></td>
          <td align="left" valign="top"></td>
          
        </tr>
        <tr>
        
            <td align="left" valign="top">
            	<input type="file" name="item_image" value=""/>
            </td>
            <td>
            <img height="50" src="<?php echo base_url('uploaded/items/thumb'). '/'.$item_data['item_image']?>"/>
           </td>
        </tr>
       <tr>
          <td align="left" valign="top"><input type="submit" value="Submit" class="submit" /></td>
        </tr>
       
        </tbody>
        
      </table>
    </form>
  </div></td>
  
  <script type="text/javascript">
  	var base_url = "<?php echo base_url()?>";
  	$(function(){
  		$("#city").change(function(){
	    	var city = $("#city").val();
	    	$.post(base_url+'index/get_area/'+city, {},function(data){ $("#area").html(data);});
    	});
  	})
  </script>
