<!-- BREADCRUMB -->
    <!-- details -->
    <section id="details" class="about">
        <div class="container">

            <!-- SECTION HEAD -->
            <div class="section-head text-center">
                <h2 class="h4 text-uppercase">Subscription Details</h2>
                <!--<p class="sub-title text-uppercase">We’re branding &amp; digital studio from Viet nam</p>-->
            </div>
            <!-- END / SECTION HEAD -->
            
            <!-- DESCRIPT -->
           
           
           <?php
           
           		
           		if($user->month == '1'){
					$planName = 'Trial';
				}
           		
	           	if($user->month == '3'){
					$planName = 'QUARTERLY';
					
				}
				if($user->month == '6'){
					$planName = 'HALF YEARLY';
				}
				if($user->month == '12'){
					$planName = 'ANNUAL';
				}
				
				if($user->month == 1){
					$expDate = strtotime("+".$user->month."months", strtotime($user->dateSubscription));
					$expDate = date('d-m-Y',$expDate);
				}
				else{
					$expDate = $user->planValidDate ; //date('d-m-Y',$effectiveDate);
					$expDate = date('d-m-Y',strtotime($user->planValidDate)) ; //date('d-m-Y',$effectiveDate);
				} 
				
				$startDate = date('d-m-Y',strtotime($user->dateSubscription));
				$limit = $user->prop_view_limit;
				$leftLimit = $user->prop_view_limit - $user->userPropertyViewCount;
				
				$threeMonthExpDate = strtotime("+3 months", strtotime($expDate));
				$threeMonthExpDate = date('d-m-Y',$threeMonthExpDate);
				
				$sixMonthExpDate = strtotime("+6 months", strtotime($expDate));
				$sixMonthExpDate = date('d-m-Y',$sixMonthExpDate);
				
				$twelveMonthExpDate = strtotime("+12 months", strtotime($expDate));
				$twelveMonthExpDate = date('d-m-Y',$twelveMonthExpDate);
			?>
            
            <div class="row" >
            	<div class="col-sm-6">
            		<table class="table table-bordered">
            			<tbody>
            			<th colspan="2" align="center">SUBSCRIBER DETAILS</th>
            			
            				<tr>
            					<td><strong>Name</strong></td>
            					<td><?php echo ucfirst($user->subscriberName) ?></td>
            				</tr>
							<tr>
            					<td><strong>Mobile</strong></td>
            					<td><?php echo ucfirst($user->mobile1) ?></td>
            				</tr>
							
            				<tr>
            					<td><strong>Email</strong></td>
            					<td><?php echo ucfirst($user->emailId) ?></td>
            				</tr>
            				<tr>
            					<td><strong>Company</strong></td>
            					<td><?php if($user->companyName != ""){ echo ucfirst($user->companyName); } ?></td>
            				</tr>
							<tr>
            					<td><strong>Website</strong></td>
            					<td><?php if($user->website != "" && $user->website != "0") { echo $user->website; }?></td>
            				</tr>
            			</tbody>
            		</table>

            	</div>
            	
            	<div class="col-sm-6">
            		<table class="table table-bordered">
            			<tbody>
            				<th colspan="2" align="center">CURRENT PLAN</th>
            				<tr>
            					<td><strong>Plan</strong></td>
            					<td style="text-transform:capitalize"><?php echo $planName ?></td>
            				</tr>
							<tr>
            					<td><strong>Start Date</strong></td>
            					<td><?php echo $startDate ?></td>
            				</tr>
							
            				<tr>
            					<td><strong>Expiry Date</strong></td>
            					<td><?php echo $expDate ?></td>
            				</tr>
            				
            				<tr>
            					<td><strong>Total Listings</strong></td>
            					<td><?php echo $limit ?></td>
            				</tr>
            				
            				<tr>
            					<td><strong>Listings Left</strong></td>
            					<td><?php echo $leftLimit ?></td>
            				</tr>
            				
            			</tbody>
            		</table>

            	</div>

            	
			<div class="row">
            	<div class="col-sm-6">
            		<table class="table table-bordered ">
            			<tbody>
                            <th colspan="2" align="center">  <b>SELECTED PLAN</b></th> 
            				<tr>
            					<td><strong>Plan</strong></td>
            					<td><span id="planName" style="text-transform:capitalize;">Plan name</span></td>
            				</tr>
            				<tr>
            					<td><strong>Amount</strong></td>
            					<td><span class="currency">₹</span><span id="planAmount">4,800/</span></td>
            				</tr>
            				<tr>
            					<td><strong>Listings</strong></td>
            					<td><span id="listing">900</span></td>
            				</tr>
            				<tr>
            					<td><strong>Start Date</strong></td>
            					<td><?php echo $expDate ?></td>
            				</tr>
							<tr>
            					<td><strong>Expiry Date</strong></td>
            					<td><span id="validity"></span></td>
            				</tr>
            			</tbody>
            		</table>

            	</div>
			</div>

            <div class="row">
            	<table class="table table-bordered" >
				<tbody>
				<tr>
                <td class="text-right right"><strong>Sub-Total</strong></td>
                <td class="text-right right"><span class="currency">₹</span> <span id="subTotal">109.00 </span></td>
				</tr>
				<!--
				<tr>
                <td class="text-right right"><strong>Service Tax:</strong></td>
                <td class="text-right right"><span class="currency">₹</span> <span id="serviceTax">45.00 </span></td>
				</tr>
                -->
					
				<tr>
                <td class="text-right right"><strong>Total</strong></td>
                <td class="text-right right"><span class="currency">₹</span><span id="total">109.00</span></td>
              </tr>
              <tr>
              	<td colspan="2">
              	<div class="buttons">
          
          <div class="pull-right"><a href="javascript:void(0)" id="checkoutbtn" class="btn btn-primary button">Checkout</a></div>
        </div>
              	</td>
              </tr>
                          </tbody></table>
                        
            </div>
            <!-- END / DESCRIPT -->
        </div>
        </div>        
       
    </section>
  
   
   
     <!-- PRICING TABLE -->
    <section id="pricing" class="pricing">
        <div class="bg-parallax bg-2"></div>
        <div class="bg-overlay"></div>
        <div class="container">
            <!-- SECTION HEAD -->
            <div class="section-head text-center">
                <h2 class="h4 text-uppercase">Pricing table</h2>
                <p class="sub-title text-uppercase">WHAT WE PROVIDE COMES FOR A MINIMAL PRICE</p>
            </div>
            <!-- END / SECTION HEAD -->

            <div class="row">
                <!-- PRICING ITEM -->
                <div class="col-md-4">
                    <div class="pricing-item  light-item text-center">
                        <div class="item-heading bg-1">
                            <h4 class="h4 text-uppercase"><?php echo $plan[0]->name?></h4>
                        </div>
                        <div class="item-price">
                            <span class="currency">₹</span>
                            <span class="amount"><?php echo $plan[0]->priceFormate?></span>
                      <!--  <span class="mo">mo</span> -->
                        </div>
                        <div class="item-body">
                            <ul>
                                <li><?php echo $plan[0]->totalproperties ?> Listings</li>
                                <li><?php echo $plan[0]->description ?></li>
                                <li>Validity: <?php echo $plan[0]->month ?> months</li>
                            </ul>
                        </div>
                        <div class="item-footer">
                            <a class="on-btn btn-style-1 text-uppercase" href="#details"  onclick="plan1()">Get Plan</a>
                        </div>
                    </div>
                </div>
                <!-- END / PRICING ITEM -->

                <!-- PRICING ITEM -->
                <div class="col-md-4">
                    <div class="pricing-item light-item text-center">
                        <div class="item-heading bg-2">
                            <h4 class="h4 text-uppercase"><?php echo $plan[1]->name?></h4>
                        </div>
                        <div class="item-price">
                            <span class="currency">₹</span>
                            <span class="amount"><?php echo $plan[1]->priceFormate ?></span>
                            <!-- <span class="mo">mo</span> -->
                        </div>
                        <div class="item-body">
                            <ul>
                                <li><?php echo $plan[1]->totalproperties ?> Listings</li>
                               <li><?php echo $plan[1]->description ?></li>
                                <li>Validity: <?php echo $plan[1]->month ?> months</li>
                            </ul>
                        </div>
                        <div class="item-footer">
                            <a class="on-btn btn-style-1 text-uppercase" href="#details"  onclick="plan2()">Get Plan</a>
                        </div>
                    </div>
                </div>
                <!-- END / PRICING ITEM -->

                <!-- PRICING ITEM -->
                <div class="col-md-4">
                    <div class="pricing-item  light-item text-center">
                        <div class="item-heading bg-3">
                            <h4 class="h4 text-uppercase"><?php echo $plan[2]->name?></h4>
                        </div>
                        <div class="item-price">
                            <span class="currency">₹</span>
                            <span class="amount"><?php echo $plan[2]->priceFormate?></span>
                            <!-- <span class="mo">mo</span> -->
                        </div>
                        <div class="item-body">
                            <ul>
                                <li><?php echo $plan[2]->totalproperties?> Listings</li>
                                <li><?php echo $plan[2]->description?></li>
                                <li>Validity: <?php echo $plan[2]->month?> months</li>
                            </ul>
                        </div>
                        <div class="item-footer">
                            <a class="on-btn btn-style-1 text-uppercase" href="#details" onclick="plan3()" >Get Plan</a>
                        </div>
                    </div>
                </div>
                <!-- END / PRICING ITEM -->
            </div>
        </div>
    </section>
    <!-- END / PRICING TABLE -->
   
   
   <!--CONTACT -->
   
   <!-- CONTACT -->
    <section id="contact" class="contact ryt-proprty">
        <div class="container">
            <!-- SECTION HEAD -->
            <div class="section-head text-left">
                <h2 class="h4 text-uppercase">CONTACT</h2>
                <p class="sub-title text-uppercase">Don't hesitate to get in touch with us, we would love to discuss on your project</p>
            </div>
            <!-- END / SECTION HEAD -->

            <div class="row">
                <div class="col-md-6">
                    <form class="contact-form">
                        <div class="form-item fl">
                            <input type="text" placeholder="Name">
                        </div>
                        <div class="form-item fr">
                            <input type="text" placeholder="Email">
                        </div>
                        <div class="form-textarea-wrapper">
                            <textarea placeholder="Message"></textarea>
                        </div>
                        <div class="form-submit">
                            <input type="submit" value="Send" class="on-btn btn-style-2 text-uppercase">
                        </div>
                    </form>
                </div>
                <div class="col-md-5 col-md-offset-1">
                    <div class="address-info">
                        <!-- <div class="address">
                            <i class="fa fa-map-marker"></i>
                            <span>121 King Street, Melbourne Victoria 3000 Australia</span>
                        </div> -->
                        <div class="email">
                            <i class="fa fa-envelope"></i>
                            <a href="#">info@bro-king.com</a>
                        </div>
                       <!--  <div class="phone">
                            <i class="fa fa-phone"></i>
                            <span>+0987654321 (+012345678)</span>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
		<div style="margin:0 0 40px 0;width:100%;float:left;">&nbsp;</div>
        <!-- <div id="map" data-map-zoom="14" data-map-latlng="45.738028, 21.224535" data-snazzy-map-theme="grayscale" data-map-marker="images/marker.png" data-map-marker-size="22*31"></div> -->
    </section>
    <!-- END / CONTACT Retail109 -->
    
    
    
<form method="post" id="paymentForm" action="<?php echo base_url() ?>payment/PaytmWeb/pgRedirect.php">
	<input type="hidden" id="ORDER_ID" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off" value="<?php echo  $user->id."ORDS".time(); ?>" >
	<input type="hidden" id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="<?php echo 'CUS00'.$user->id;?>"></td>
	<input type="hidden" id="sub_id" tabindex="2" maxlength="12" size="12" name="sub_id" autocomplete="off" value="<?php echo $user->id;?>"></td>
	<input type="hidden"  id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail">
	<input type="hidden"  id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
	<input type="text"  id="plan" tabindex="4" maxlength="12" size="12" name="plan" autocomplete="off" value="HALF YEARLY">
	
	<input type="text"  id="planId" tabindex="4" maxlength="12" size="12" name="planId" autocomplete="off" value="HALF YEARLY">
	
	<input type="hidden"  title="TXN_AMOUNT"  tabindex="10" id="TXN_AMOUNT"  name="TXN_AMOUNT" value="1">
</form>
   
<script type="text/Jscript">
	var selectedPlan = "<?php echo $planId ?>";
	
	if(selectedPlan == 'plan1'){
		plan1();
	}
	else if(selectedPlan == 'plan2'){
		plan2();
		
	}
	else if(selectedPlan == 'plan3'){
		plan3();
	}
	
	$("#checkoutbtn").on("click",function(){
		
		$("#paymentForm").submit();
	});
	
	
	
	/*
	<td><span id="planAmount">4,800/</span></td>
	<td><span id="validity">3 months</span></td>
	<td><span id="planName">Plan name</span></td>
	<td><span id="listing">900</span></td>
            QUARTERLY 	
            
            
            
            description
	
           
							
							<h4 class="h4 text-uppercase"><?php echo $plan[0]->name?></h4>
							<span class="amount"><?php echo $plan[0]->priceFormate ?></span> 
							<li><?php echo $plan[0]->totalproperties ?> Listings</li>
                                <li><?php echo $plan[0]->description ?></li>
                                <li>Validity: <?php echo $plan[0]->month ?> months</li>
							
							
							
    
    
	*/
	
	function plan1(){
		$("#planName").html("<?php echo ucwords($plan[0]->name)?>");
		$("#planAmount").html("<?php echo $plan[0]->priceFormate?>");
		$("#listing").html("<?php echo $plan[0]->totalproperties?>");
		$("#serviceTax").html("00.00/-");
		
		//$("#validity").html("<?php echo ucfirst($plan[0]->month)?> months");
		$("#subTotal").html("<?php echo $plan[0]->priceFormate?>");
		$("#total").html("<?php echo $plan[0]->priceFormate?>");
		$("#plan").val('<?php echo ucwords($plan[0]->name)?>');
		$("#planId").val('1');
		$("#validity").html("<?php echo $threeMonthExpDate;?>");
		
	}
	
	function plan2(){
		$("#planName").html("<?php echo ucwords($plan[1]->name)?>");
		$("#planAmount").html("<?php echo $plan[1]->priceFormate?>");
		$("#listing").html("<?php echo $plan[1]->totalproperties?>");
		$("#serviceTax").html("00.00/-");
		//$("#validity").html("6 months");
		$("#subTotal").html("<?php echo $plan[1]->priceFormate?>");
		$("#total").html("<?php echo $plan[1]->priceFormate?>");
		$("#plan").val("<?php echo ucwords($plan[1]->name)?>");
		$("#planId").val('2');
		$("#validity").html("<?php echo $sixMonthExpDate;?>");
	}
	
	function plan3(){
		$("#planName").html("<?php echo ucwords($plan[2]->name)?>"); 
		$("#planAmount").html("<?php echo $plan[2]->priceFormate?>");
		$("#listing").html("<?php echo $plan[2]->totalproperties?>");
		$("#serviceTax").html("00.00/-");
		$("#subTotal").html("<?php echo $plan[2]->priceFormate?>");
		$("#total").html("<?php echo $plan[2]->priceFormate?>");
		$("#plan").val('<?php echo ucwords($plan[2]->name) ?>');
		$("#planId").val('3');
		$("#validity").html("<?php echo $twelveMonthExpDate;?>");
	}
	
</script>  

