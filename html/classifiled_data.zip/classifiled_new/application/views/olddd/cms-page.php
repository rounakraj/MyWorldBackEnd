<!-- BREADCRUMB -->



    <section class="breadcrumbs-wrapper">
        <div class="container">
            <ul class="breadcrumbs text-center">
                <li><a href="<?php echo base_url(); ?>">Home</a></li>
                <li><span><?php echo $page_content->page_title ?></span></li>
            </ul>
        </div>
    </section>
    <!-- END / BREADCRUMB -->
<?php if($page_content->id != 20) { ?>
<style type="text/css">
   .num-list-aa ol {
  list-style-type: none;
  counter-reset: item;
  margin: 0;
  padding: 0;
}

.num-list-aa ol > li {
  display: table;
  counter-increment: item;
  margin-bottom: 0.6em;
}

.num-list-aa ol > li:before {
  content: counters(item, ".") ". ";
  display: table-cell;
  padding-right: 0.6em;    
}
.alpfa-listt ul{list-style-type: lower-alpha; margin: 0; padding: 0;}
.alpfa-listt ul li{list-style-type: lower-alpha; }
a.link{word-break: break-word;}
</style>
<?php }  else {?>
<style type="text/css">
	ul {
    list-style: none;
    padding:0;
    margin:0;
}

li { 
    padding-left: 1em; 
    text-indent: -.7em;
    margin:5px !important;
}

li:before {
    content: "• ";
   // color: red; /* or whatever color you prefer */
}
	
</style>

<?php } ?>
 <!-- ABOUT US -->
    <section id="about_us_pg" class="inner_page">

        <div class="container">
            <!-- SECTION HEAD -->
            <div class="section-head text-center">
                <h2 class="h4 text-uppercase"><?php echo $page_content->page_title ?></h2>
                <!--<p class="sub-title text-uppercase"><?php echo $page_content->page_heading ?></p>-->
            </div>
           
			<div class="row">
				<div class="col-lg-12">
					<div class="inner_pg_content">
						<?php echo $page_content->page_content?>
					</div>
				</div>
			</div>
            
            
        </div>
    </section>
    <!-- END / ABOUT US -->

