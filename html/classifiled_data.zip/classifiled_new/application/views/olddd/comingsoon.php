<!DOCTYPE html>
<!--[if IE 7 ]> <html class="ie ie7"> <![endif]-->
<!--[if IE 8 ]> <html class="ie ie8"> <![endif]-->
<!--[if IE 9 ]> <html class="ie ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html class="" lang="en"> <!--<![endif]-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    
    
    <title>Bro-King: Empowering Brokers</title>
    <link rel="icon" href="<?php echo base_url('html')?>/images/metaLogo.png" type="image/png" sizes="16x16">
    
    <meta name="description" content="Bro-King is designed to give a complete back office support to real estate brokers at almost 5% the cost on subscription basis- acting as a virtual office on the go. The app covers almost all functions carried out by any real estate broker in a very effective manner.">
    
    <meta name="keywords" content="Register your property, Download app, About us, Selecte your subscription plan,Renew subscription">
    
	<meta property="og:title" content="Bro-King : Empowering Brokers">
	<meta property="og:image" content="<?php echo base_url('html')?>/images/metaLogo.png">
	<meta property="og:description"  content="Bro-King is designed to give a complete back office support to real estate brokers at almost 5% the cost on subscription basis- acting as a virtual office on the go. The app covers almost all functions carried out by any real estate broker in a very effective manner.">
		

    <!-- GOOGLE FONT -->
  <!--   <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'> -->
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>
    <!-- <link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,400italic' rel='stylesheet' type='text/css'> -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800' rel='stylesheet' type='text/css'>

    <!-- CSS LIBRARY -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>html/comming/css/lib/bootstrap.min.css">
  <!--   <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>html/comming/css/lib/owl.carousel.css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>html/comming/css/lib/font-awesome.min.css">

    <!-- ANIMATION -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>html/comming/css/lib/animate.css">


    <!-- PAGE STYLE -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>html/comming/css/style.css">
    <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->
  
    <title>Bro-King</title>
</head>
<body id="page-top" data-spy="scroll">

<!-- PRELOADER -->
<!-- <div class="preloader">
    <div class="loading-wrap">
        <div class="p-loading" data-loading="Loading">Loading</div>
    </div>
</div> -->
<!-- END / PRELOADER -->

<!-- PAGE WRAP -->
<div id="page-wrap">

    <!-- HEADER -->
    <!-- HEADER -->
    <header id="header" class="header header-sticky">
        <div class="container">
            <!-- LOGO -->
            <div class="logo">
                <a href="<?php echo base_url()?>">
                    <img src="<?php echo base_url()?>html/comming/images/logo.png" alt="Image">
                </a>
            </div>
            <!-- END / LOGO -->

            <div class="open-menu">
                <span class="item-1"></span>
                <span class="item-2"></span>
                <span class="item-3"></span>
            </div>
<div class="on-social" style="text-align: right;">
                                <a href="mailto:info@bro-king.com"><i class="fa fa-envelope" ></i>  info@bro-king.com</a>
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-google-plus"></i></a>
               
            </div>
            <!-- NAVIGATION -->
           <!--  <nav class="on-navigation text-right" data-menu-type="1200">

              
                <ul class="nav text-uppercase">
                    <li class="menu-item"><a href="#intro">Home</a></li>
                    <li class="menu-item"><a href="#about">About</a></li>
                    <li class="menu-item"><a href="#pricing">Pricing</a></li>
                    <li class="menu-item"><a href="#download">Download</a></li>
                    <li class="menu-item"><a href="#contact">Contact</a></li>
                </ul>
         
            </nav> -->
            <!-- END / NAVIGATION -->
        </div>

    </header>
    <!-- END / HEADER -->
	
	<!--begin_section -->
	<section id="intro" class="begin_download">
		<div class="container">
			<div class="row">
	    		<div class="col-md-6">
	    			<h2 class="dark-text"><span>Download Our App</span> </h2>
					<p class="mid-text dark-text">Available on Android and iOS.</p>
					<p style="margin-top:30px;">
						<a onclick="ga('send', 'event', 'Link Click', 'Android', 'BroEx');" class="google-play" href="https://play.google.com/store/apps/details?id=com.broking&hl=en" target="_blank" ></a>
						<a onclick="ga('send', 'event', 'Link Click', 'iOS', 'BroEx');" class="app-store" href="#"></a>
					</p>
	    		</div>

	    		<div class="large-6 columns large-text-left small-text-center">
	    		<h2 class="white-text comming-tag"><span>We 're coming <br> soon..</span></h2>
          <p class="heading bold">TIME REMAINING TO LAUNCH:</p>

            <!-- start timer, reference to <?php echo base_url() ?>html/comming/js/countdown.js for change date -->
            <div id="timer"></div>
            <!-- end timer -->

        </div>
	    		
	    	</div>
		</div>
	</section>

	<!-- ABOUT -->
 
    <!-- END / ABOUT -->
	
	<!-- TWITTER -->
    
    <!-- END / TWITTER -->
	
	<!--feature -->
	<!-- <section class="feature" id="feature">
		<div class="container">
			<div class="row">
    			<div class="col-md-3 text-center feature">
    				<img alt="News Feed" src="img/newsfeed.png">
    				<h3>News Feed</h3>
    				<p>News feed brings the pulse of the<br>property market in your area at<br>your finger tips.</p>
    				<p><a href="#news_feeds" class="page-scroll">Know More</a></p>
    			</div>
    			<div class="col-md-3 text-center feature">
    				<img alt="Search Properties" src="img/searchproperties.png">
    				<h3>Search Properties</h3>
    				<p>Search the broker with<br>precise property that your<br>party wants.</p>
    				<p><a href="#searchprop" class="page-scroll">Know More</a></p>
    			</div>
    			<div class="col-md-3 text-center feature">
    				<img alt="Auto Match Alerts" src="img/automatch.png">
    				<h3>Auto Match Alerts</h3>
    				<p>Get notified when a requirement<br>matching your inventory<br>surface in the market.</p>
    				<p><a href="#automatch" class="page-scroll">Know More</a></p>
    			</div>
    			<div class="col-md-3 text-center feature">
    				<img alt="Borker Network" src="img/brokernetwork.png">
    				<h3>Broker Network</h3>
    				<p>Be part of India's largest<br>network on real estate<br>professionals.</p>
    				<p><a href="#brokernetwork" class="page-scroll">Know More</a></p>
    			</div>
    		</div>
		</div>
	</section> -->
	
	<!-- end feature -->
	
    <!-- NEWS FEEDS -->
	

	<!-- END /NEWS FEED -->
	
	 
	
	<!-- SEARCH PROPERTIES-->
	
	<!--END SEARCH PROPERTIES-->
	
	<!-- AUTO MATCH-->
		
	
	<!--END AUTO MATCH-->
	
	<!--BROKER NETWORK -->

	<!--ENDS BROKER NETWORK -->
	
	
	
	
	
	

   
   
   
   

  
   
   
   
   <!-- END CONTACT -->
   <!--footer -->
   <footer class="footer">
	<div class="container">
		<div class="row">
    		<div class="col-md-8 col-md-offset-2 text-center">

    			<ul>
    				<li><a href="<?php echo base_url('about-us'); ?>">About Us</a></li>
					<li><a href="<?php echo base_url('privacy-policy'); ?>">privacy policy</a></li>
					<!-- <li><a href="about-us.html">How To Use</a></li> -->
    	           <li><a href="<?php echo base_url('terms-and-conditions'); ?>">Terms & Conditions</a></li>
    			</ul>

    		</div>
    		<!-- <div class="col-md-4 text-right">
			 <div class="foot-social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-dribbble"></i></a>
                <a href="#"><i class="fa fa-google-plus"></i></a>
            </div>
			</div> -->
			<div style="font-size:12px; margin-top: 20px;" class="col-lg-12 text-center col-md-12 col-sm-12 col-xs-12">
				&copy; 2016 Japri Tech Private Limited.
			</div>
    	</div>
	</div>
   </footer>
   <!-- ends footer-- >
 
    

</div>
<!-- END / PAGE WRAP -->



<!-- LOAD JQUERY -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>  
 
<script type="text/javascript">
	$(document).ready(function(){
	var viewHeight = $(window).height();
 var footHeight = $(".footer").outerHeight();
  var headHeight = $(".header").outerHeight();
  //var bread_head  = $('.al-fnd').height();
  var minus_h =  parseInt(headHeight) + parseInt(footHeight);
var finalHeight = parseInt(viewHeight) - parseInt(minus_h);
// console.log(viewHeight);
// console.log(footHeight);
// console.log(headHeight);
// console.log(bread_head);

// console.log(finalHeight);

//alert(finalHeight);
$(".begin_download").css('height',finalHeight+'px');
});
</script>
<script type="text/javascript" src="<?php echo base_url() ?>html/comming/js/lib/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>html/comming/js/countdown.js"></script>
<script type="text/javascript">
	
/* ==============================================
   Countdown
=============================================== */
    // Create a countdown instance. Change the launchDay according to your needs.
    // The month ranges from 0 to 11. I specify the month from 1 to 12 and manually subtract the 1.
    // Thus the launchDay below denotes 7 May, 2014.
    var launchDay = new Date(2016, 9+1, -3);
    $('#timer').countdown({
    until: launchDay
    });




</script>

<script type="text/javascript" src="<?php echo base_url() ?>html/comming/js/lib/jquery.easing.min.js"></script>


<script type="text/javascript" src="<?php echo base_url() ?>html/comming/js/scripts.js"></script>
<script type="text/javascript">
 

	$(document).ready(function(e) {
	
	$('.handle').click(function () {
		$(".handle-opn").show();
		$("a.handle").hide();
		//alert('hello');
		//$( "a.handle span" ).removeClass( "quote_img" ).addClass( "quote_img_opn" );
        $( ".slide-out-div" ).css( {"right": "-1px"});
	
		
		});
	
	$('.handle-opn').click(function () {
		
		$("a.handle").show();
		$(".handle-opn").hide();
		//alert('hello');
		//$( "a.handle span" ).removeClass( "quote_img" ).addClass( "quote_img_opn" );
        $( ".slide-out-div" ).css( {"right": "-350px", "transition": "all 0.4s ease-in" });
	
		
		});
	
	
	});
</script>

</body>
</html>