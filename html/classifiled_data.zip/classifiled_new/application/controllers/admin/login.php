<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
class Login extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('admin/model_login');
		$this->load->helper('cookie');
		$this->load->library('encrypt');
		if($this->session->userdata('logged_in'))
			redirect('admin/dashboard');
		else 	
			return TRUE;
		exit;
	}
	public function index(){
		$data['title'] = "Admin | Login";
		if(isset($_COOKIE["remenber_me"]) && $_COOKIE["remenber_me"] == 1){
			$data['setuser'] = 	$_COOKIE["setuser"];
			$data['setpass'] = 	$_COOKIE["setpass"];
			$data['remenber_me'] = 	1;
		} 
		else{
			$data['setuser'] = '';
			$data['setpass'] = '';
			$data['remenber_me'] = 	'';
		}
		$this->load->view('admin-html/login',$data);
	}
	public function authentication(){
		
		
		if($this->input->post()){
			$this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('userpass', 'User Password', 'trim|required|xss_clean');				
			$this->form_validation->set_error_delimiters('<strong class="ferror"> ' ,'</strong>,');
			if(!$this->form_validation->run() == FALSE){
				
				$username = mysql_real_escape_string($this->input->post("username"));
				$password = mysql_real_escape_string($this->input->post("userpass"));
				$result = $this->model_login->authentication($username,$password);
				
				if($result){
					$session_data = array("username"  => "$result->	admin_user","	admin_id" => "$result->	admin_id","admin_logged_in" => TRUE);			
					$this->session->set_userdata($session_data);
					if($this->input->post('remenber_me') == 1) {
						setcookie("setuser", $username, time()+3600*12*30); 
						setcookie("setpass", $password, time()+3600*12*30); 
						setcookie("remenber_me", $this->input->post('remenber_me'),time()+3600*12*30); 
					}
					
					
				redirect('admin/dashboard');
				}else{
					$data['msg'] = "Opps Error ! <br> Invalid Username or Password.";
					$this->session->set_flashdata('msg','<strong class="ferror"> Opps Error ! <br> Invalid Username or Password. </</strong>');
					redirect('admin/login');
				}
			
			}else{
				$this->session->set_flashdata('msg','<strong class="ferror"> Opps Error ! <br> Invalid Username or Password. </</strong>');
				redirect('admin/login');
			}
		} 
	}
	public function forgotPassword(){
		$email = $this->input->post('email');
		$where = array('email'=> mysql_real_escape_string($email));
		$emailCount = $this->common_model->getCount('tbl_user',$where);
		
		if($emailCount > 0){
			$admin = $this->common_model->getSingleRow('*','tbl_user',$where);
			if($admin['email'] == $email ){
				$this->load->library('email');
				$this->email->from('email_address', $admin['email']);
				$this->email->to($email);
				$email_msg  = $this->common_model->getSingleRow('*','tbl_email_notification',array('id' => '12'));
				
				$this->email->subject($email_msg['subject']);
				$message = str_replace('##admin##',ucwords($admin['firsr_name']),$email_msg['message']);
				$message = str_replace('##username##',$admin['username'],$message);
				$message = str_replace('##password##',$admin['password'],$message);
				$message = setEmailTemplate($message);
				$this->email->message($message);
				$this->email->send();
				echo 'true';
				exit;
			}else{
				echo "<strong> Opps Error ! <br> Invalid Email Id.</strong>";
				exit;
			}
		}
		echo "<strong> Opps Error ! <br> Invalid Email Id.</strong>";
		exit;
	}
		
}
/* End of file Login.php */
/* Location: ./application/controllers/welcome.php */