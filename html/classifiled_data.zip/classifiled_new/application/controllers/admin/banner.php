<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Banner extends CI_Controller {
	public function __construct() 
    {
		 parent::__construct();		 
		 $this->load->model('admin/banner_model', 'Banner',TRUE);
		  $this->load->library('image_lib');
	}

	public function index(){	
		redirect('admin/banner/lists');
	}
	
	public function add(){		
		$data['title'] = 'Add';
		$header['title'] = 'Add Banner :: Banner';
		
		if($this->input->post()) {
					
			$this->form_validation->set_rules('title', 'Please Enter Title', 'trim|required|xss_clean');	
			$this->form_validation->set_rules('width', 'Please Enter Only Numeric', 'trim|required|xss_clean');	
			$this->form_validation->set_rules('height', 'Please Enter Only Numeric', 'trim|required|xss_clean');	
			
			if(!$this->form_validation->run() == FALSE){
				if($this->Banner->insert())
					$this->session->set_flashdata('msg','Banner Added Successfully.');
				else
					$this->session->set_flashdata('msg','Some Error Occured. Please Try Again');
				redirect('admin/banner/add');
			}
		}
		$this->load->view('admin-html/include/header',$header);     
        $this->load->view('admin-html/add-banner',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function lists(){		

		$data['title'] = "Lists";
		$header['title'] = "Banner List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/banner/lists/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $this->Banner->dataCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		
		$data['result'] = $this->Banner->getAll($pconfig['per_page'], $c_page,$key);
	
		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        //$this->load->view('admin-html/include/left-sidebar',$data);
        $this->load->view('admin-html/banner-list',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	  $this->common_model->updateValue(array('isDeleted'=>'1'),'tbl_banner', array('id' => $var)); 
         	}
    	}
		redirect('admin/banner/lists');
 	} 

	function del($var){
		if($var){
			$this->common_model->updateValue(array('isDeleted'=>1),'tbl_banner', array('id' => $var)); 
			$this->session->set_flashdata('msg','Banner Deleted Successfully.');
			redirect('admin/banner/lists');
		}
	}

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_banner',$where);
			$this->session->set_flashdata('msg','Status Change Successfully.');
			redirect('admin/banner/lists/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Status Not be Change Successfully.');
		redirect('admin/banner/lists/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_banner',$where);
			}
			$this->session->set_flashdata('msg','Status Change Successfully.');
			redirect('admin/banner/lists/'); 
			exit;
		}
		redirect('admin/banner/lists/'); 
		exit;
	}
	
}