<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class client extends CI_Controller {
	
	public function __construct() {
		 parent::__construct();		 
		 $this->load->model('Common_model');
		 $this->load->model('admin/client_model','ClientModel',TRUE);
	}

	public function index(){	
		redirect('admin/client/all');
	}
	
	public function add($client_id){		
		$data['title'] = 'Add New client';
		$header['title'] = 'Add New client : Admin';
		
		if($client_id){
			$data['title'] = 'Update client';
			$header['title'] = 'Update client';
			$where = array('id' => $client_id );
			$data['client']=$this->Common_model->getSingle('tbl_clients',$where,'','','','');
		}
		if($this->input->post()) {
			$this->form_validation->set_rules('client_name', 'Please Enter Client Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('user_type', 'Please Select User Type', 'trim|xss_clean');
			
			if($this->form_validation->run() == TRUE){
				if($this->ClientModel->addNew()==true){			
					$this->session->set_flashdata('msg','Client Added Successfully.');
					redirect('admin/client/all');
				}
			}
		}		
		
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/add-client',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function all(){		

		$data['title'] = "client List";
		$header['title'] = "All client List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/client/all/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_client = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_client = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_client = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->ClientModel->AllCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_client);
		
		$data['result'] =  $this->ClientModel->GetAll($pconfig['per_page'], $c_client,$key);
		
		
		//pr($data); exit; 

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/clientList',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	function del($var){
		if($var){
			$this->db->delete('tbl_clients', array('id' => $var)); 
			redirect('admin/client/all');
		}
	}
			 
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	   $this->db->delete('tbl_clients', array('id' => $var)); 
		  	}
    	}
		redirect('admin/client/all');
 	} 

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_clients ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/client/all/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/client/all/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_clients ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/client/all/'); 
			exit;
		}
		redirect('admin/client/all/'); 
		exit;
	}

	function reSetOrder(){
		$client_id = $this->input->post("id");
		$row['order'] = $this->input->post("filed_val");
		$where = array('id' => $client_id );
		$this->common_model->updateValue($row,'tbl_clients',$where);
		//echo $this->db->last_query();
		//exit;
		echo 'Rank is update';
	}
	public function get_area(){
		$city_id = $this->uri->segment('3');
		$where = array('status' => 'active', 'city_id' => $city_id);
		$city = $this->common_model->getResults('id,area_name','tbl_city_area',$where);
		echo $this->db->last_query();
		$option = '';
		foreach($city as $obj){
			$option .='<option value="'.$obj->id.'">'.$obj->area_name.'</option>'; 
		}
		echo $option;
	}	
	
					 		   
}