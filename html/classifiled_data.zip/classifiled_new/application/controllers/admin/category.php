<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Category extends CI_Controller {
	public function __construct() 
    { 
		 parent::__construct();	
         $this->load->model('common_model');		 
		 $this->load->model('admin/category_model','Category',TRUE);
		 $this->load->library('image_lib');
	}
	
	public function index(){
		redirect('admin/category/listing');
	}
	
	public function add_new(){	
		if($this->input->post('submit')){
			$this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('page_heading', 'Page Heading', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_keywords', 'Email', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_description', 'Username', 'trim|xss_clean');
			$this->form_validation->set_rules('description', 'Password ', 'trim|xss_clean');
			
			if(!$this->form_validation->run() == FALSE){ 
				$lastInsertId = $this->Category->insert();
				if($lastInsertId >0)
					$this->session->set_flashdata('msg','Information saved successfully!');
				else
					$this->session->set_flashdata('msg','Some error occured!');
				redirect('admin/category/add_new');
			}
		}
		$data['parentCategories']=$this->common_model->getAll('tbl_category',array('parent_id'=>'0'));
		$data['title'] = "Add New";
		$header['title'] = "Add Category : Admin";
		$this->load->view('admin-html/include/header',$header);       
        $this->load->view('admin-html/add-category',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	function update(){
		$category_id = $this->uri->segment(4); 
        $data['categorydetails'] = $this->common_model->getSingle('tbl_category',array('id'=>$category_id));
		if($this->input->post('submit')){
			$category_id = $this->input->post('category_id'); 
            $this->form_validation->set_rules('title', 'Please enter page title', 'trim|required|xss_clean');
			if(!$this->form_validation->run() == FALSE){				
				$lastInsertId = $this->Category->update_category();
				if($lastInsertId >0){
				   $this->session->set_flashdata('msg','Information saved successfully!');
				   redirect('admin/category/update/'.$category_id);
				}else{
				   $this->session->set_flashdata('msg','Some error occured!');
				redirect('admin/category/update/'.$category_id);} 
			}else{
				$this->session->set_flashdata('msg', 'please enter page title');
				redirect('admin/category/update/'.$category_id);
			}
		}
		$data['parentCategories']=$this->common_model->getAll('tbl_category',array('parent_id'=>'0'));
        $data['title'] = 'Edit';		
		$header['title'] = "Edit Category : Admin";
		$this->load->view('admin-html/include/header',$header);       
        $this->load->view('admin-html/update-category',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function listing(){
		$data['title'] = "Lists";
		$header['title'] = "Category Lists : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$key = '';
		$base_url = base_url().'admin/category/listing/';
		$data['action'] = $base_url;
		
		/*********************************** Searching Pagination Order **********************************/
		
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->Category->pageCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		
		$data['result'] = $this->Category->getAllData($pconfig['per_page'], $c_page,$key);
		
		/********************************************* End Pagination , Searching ,Order ********************************************/
		
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();
		
		$this->load->view('admin-html/include/header',$header);       
        $this->load->view('admin-html/category-list',$data);
        $this->load->view('admin-html/include/footer');
	}	
	
    public function changestatus(){
    	$category_id = $this->uri->segment(4);  
		$status = $this->uri->segment(5);
		if($category_id){
			$updateArray = array('status'=>$status);
			$updateStatus['rowData'] = $this->common_model->updateValue($updateArray, 'tbl_category',array('id'=>$category_id));
			if($updateStatus){
			 $this->session->set_flashdata('msg', 'Updated Successfully');
			}else{
			   $this->session->set_flashdata('msg', 'Some Error Occurred');
			}		
			redirect('admin/category/listing');
		}
	}
	
    function del(){
		$category_id = $this->uri->segment(4);
		$isDeleted = $this->uri->segment(5);
		if($category_id){
			$updateArray = array('isDeleted'=>'1');
			$deleteRow=$this->common_model->updateValue($updateArray, 'tbl_category' ,array('id'=>$category_id));
			if($deleteRow){
				 $this->session->set_flashdata('actMsg', 'Delete Successfully');
			}else{
			   $this->session->set_flashdata('actMsg', 'Some Error Occurred');
			}
		 redirect('admin/category/listing');
		}
	}	
	
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	   	$updateArray = array('isDeleted'=>'1');
				$deleteRow=$this->common_model->updateValue($updateArray, 'tbl_category',array('id'=>$var));
         	}
    	}
		redirect('admin/category/listing');
 	} 
	
	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_category ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/category/listing');
			exit;
		}
		redirect('admin/category/listing');
		exit;
	}
	
	function all(){
		$data['tablevalues'] = $this->common_model->getAll('tbl_category', array('isDeleted'=>'0'));
		$data['content'] = "Admin/category-list";	  
		$this->load->view('Admin/Layout/main_layout', $data); 
	}
	
	function active(){
		$data['tablevalues'] = $this->common_model->getAll('tbl_category', array('status'=>'1','isDeleted'=>'0'));
		$data['content'] = "Admin/category-list";	  
		$this->load->view('Admin/Layout/main_layout', $data); 
	}
	
	function inactive(){
		$data['tablevalues'] = $this->common_model->getAll('tbl_category', array('status'=>'0','isDeleted'=>'0'));
		$data['content'] = "Admin/category-list";	  
		$this->load->view('Admin/Layout/main_layout', $data); 
	}
}

/* End of file Category.php */
/* Location: ./application/controllers/Category.php */ 