<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Job extends CI_Controller {
	private $password_key = 'Admin';
	function __construct(){
        parent::__construct();
		$this->load->model('admin/model_dashboard');
		$this->load->model('admin/job_model','JobModel',TRUE);
		$this->load->library('encrypt');
		$this->load->library('image_lib');
    }

	public function read_file(){
		
		date_default_timezone_set('Asia/Kolkata');
		$where_client = array('status' => '1');		
		$data['Allclients'] = $this->common_model->getResults('id,client_name','tbl_clients',$where_client);
		
		
		 
		if($this->input->post('PathName')){
			
			$files = array();
			$path = ($this->input->post('PathName'))? $this->input->post('PathName') : 'payment/PaytmApp/';   
			$dir = new DirectoryIterator($path);
			
			$date = $this->input->post('DownloadDT');
			$time = $this->input->post('DownloadTime');
			$i = 0;
			foreach($dir as $fileinfo) {
				$time = filemtime($path.$fileinfo->getFilename());
				$info = pathinfo($path.$fileinfo->getFilename());
				
				if(!empty($info['extension'])){
					$files[$i]['base_file_name'] = $info['filename']; 
					$files[$i]['file_name'] = $fileinfo->getFilename();
					$files[$i]['date_time'] = $time;
					$i++;
				}				
			}
			
			$data['download_date'] = date('Y-m-d',strtotime($date)); 
			$data['download_time'] = $time; 
			$data['files'] = $files; 
			
		}		
	  
	  $data['title'] = "Admin | Job";	
	  $header['title'] = "Admin |Job ";
	  
	 
	  $this->load->view('admin-html/include/header',$header);
	  $this->load->view('admin-html/read_file',$data);
	  $this->load->view('admin-html/include/footer');
	  
	  
	}
	
	public function addJobs(){
		if($this->input->post()){
			$jobname = array_filter($this->input->post('jobname'));
			$chk = $this->input->post('chk');
			$download_date = $this->input->post('download_date');
			$download_time = $this->input->post('download_time');
			
			for($i=0 ; $i < count($chk); $i++){
				if($jobname[$chk[$i]]){
					$input['JobFileName'] 			= $jobname[$chk[$i]]; 
					$input['EnggDownloadTime'] 		= $download_time;
					$input['EnggDownloadDate'] 		= $download_date;
					$input['clientId'] 				= $this->input->post('client_id');	
					$insertId = $this->common_model->insertValue('tbl_jobs',$input);
					echo $this->db->last_query();
				
				}
			}
			redirect('admin/job/all'); 
			die;
		}
	}
	
	
	public function readDirectory(){
		date_default_timezone_set('Asia/Kolkata');
		$where_client = array('status' => '1');		
		$data['Allclients'] = $this->common_model->getResults('id,client_name','tbl_clients',$where_client);
	
		
	  $data['title'] = "Admin | Job";	
	  $header['title'] = "Admin |Job ";
	  $this->load->view('admin-html/include/header',$header);
	  $this->load->view('admin-html/read_directory',$data);
	  $this->load->view('admin-html/include/footer');
	}
	
	function editJob($jobId=NULL){
		
		if($this->input->post()){
			
			$update['JobFileName'] = $this->input->post('JobFileName');
			$update['MTTimeIn'] = $this->input->post('MTTimeIn');
			$update['MT'] = $this->input->post('MT');
			$update['MTTotLine_65'] = $this->input->post('MTTotLine_65');
			$update['MTTotLine_normal'] = $this->input->post('MTTotLine_normal');
			$update['QA'] = $this->input->post('QA');
			$update['QATotLine_65'] = $this->input->post('QATotLine_65');
			$update['QATotLine_normal'] = $this->input->post('QATotLine_normal');
			$this->common_model->updateValue($update, 'tbl_jobs',array('id' => $this->input->post('job_id')) );
			
			$this->session->set_flashdata('msg','Job Updated Successfully.');
			redirect('admin/job/all');
			
		}
		$where_job = array('id' => $jobId);		
		$data['job'] = $this->common_model->getSingle('tbl_jobs',$where_job);
		$data['title'] = "Admin | Job";	
		$header['title'] = "Admin |Job ";
		$this->load->view('admin-html/include/header',$header);
		$this->load->view('admin-html/edit_job',$data);
		$this->load->view('admin-html/include/footer');
		
		
	}
	public function manualEntry(){
		if($this->input->post()){
			$jobname = array_filter($this->input->post('jobname'));
			
			$jobtime = $this->input->post('time');
			
			for($i=0 ; $i < count($jobname); $i++){
				$input['JobFileName'] 		= $jobname[$i]; 
				$input['EnggDownloadTime'] 		= $jobtime[$i]; 
				$input['EnggDownloadDate'] 	= date('Y-m-d',strtotime($this->input->post('download_date')));
				$input['clientId'] 			= $this->input->post('client_id');
				$insertId = $this->db->insert('tbl_jobs',$input);
			}
		} 
		$where_client = array('status' => '1');		
		$data['Allclients'] = $this->common_model->getResults('id,client_name','tbl_clients',$where_client);		
		$data['title'] = "Admin | Job";	
		$header['title'] = "Admin |Job ";
		$this->load->view('admin-html/include/header',$header);
		$this->load->view('admin-html/manual_entry',$data);
		$this->load->view('admin-html/include/footer');
	}
	
	public function deleteJobs(){
			$data['title'] = "Admin | Job";	
			$header['title'] = "Admin |Job ";
			$this->load->view('admin-html/include/header',$header);
			$this->load->view('admin-html/delete_jobs',$data);
			$this->load->view('admin-html/include/footer');
	} 

   public function all(){		

		$data['title'] = "Job List";
		$header['title'] = "All Job List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/Job/all/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_Job = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_Job = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_client = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->JobModel->AllCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_client);
		
		$data['result'] =  $this->JobModel->GetAll($pconfig['per_page'], $c_client,$key);
		
		
		//pr($data); exit; 

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/JobList',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	
	function testCRSF(){
		$this->checkToken(); 
		$this->load->view('admin-html/Test',$data);
        
	}
	
	
	function checkToken(){
		if($this->input->post()){
			
			if($this->input->post('token') == $this->security->get_csrf_hash()){
				die("valid");
				//return true;
			}else{
				die("Invalid Hash Token");
			}
			
		}
		else{
			return true;
		}
		
	}
	
	
 }  