<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Items extends CI_Controller {
	
	public function __construct() {
		 parent::__construct();		 
		 $this->load->model('Common_model');
		 $this->load->model('admin/item_model','ItemModel',TRUE);
		 $this->load->library('image_lib');
	}

	public function index(){	
		redirect('admin/pages/add_new');
	}
	
	public function add_new($item_id){		
		$data['title'] = 'Add New Item';
		$header['title'] = 'Add New Item : Admin  ';
		
		$where = array('status' => 'active');
		$data['city']	=	$this->Common_model->getResults('','tbl_city',$where);	
		$data['area']	=	$this->Common_model->getResults('','tbl_city_area',$where);	
		$data['vendor']	=	$this->Common_model->getResults('','tbl_vendor',$where);	
		$data['category']	=	$this->Common_model->getResults('','tbl_category',$where);	
		
		//pr($data);

		if($this->input->post()) {
			
			$this->form_validation->set_rules('item_name', 'Please Enter Item Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('vendor', 'Please Enter Page Heading', 'trim|xss_clean');
			$this->form_validation->set_rules('item_category', 'item_category', 'trim|xss_clean');
			$this->form_validation->set_rules('item_price', 'price', 'required|trim|xss_clean');
			$this->form_validation->set_rules('city', 'city', 'required|trim|xss_clean');
			$this->form_validation->set_rules('item_details', '', 'trim|xss_clean');
			//$this->form_validation->set_rules('area', 'Please Enter Page Content', 'trim|xss_clean');
			
			if($this->form_validation->run() == TRUE){
				
				if($this->ItemModel->addNew()==true){			
					$this->session->set_flashdata('msg','Page Added Successfully.');
					redirect('admin/items/all');
				}
			}
		}
		if($item_id){
			$data['title'] = 'Update Item';
			$header['title'] = 'Update Item';
			$where = array('id' =>$item_id );
			$data['item_data']	=	$this->ItemModel->getSingleItem($item_id);	
			//echo $this->db->last_query();
			
		}		
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/add-item',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function all(){		

		$data['title'] = "Add New Items";
		$header['title'] = "Add New Items : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/items/all/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->ItemModel->AllCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		
		$data['result'] =  $this->ItemModel->GetAll($pconfig['per_page'], $c_page,$key);

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        //$this->load->view('admin-html/include/left-sidebar',$data);
        $this->load->view('admin-html/all-items',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function page_update(){
		$page_id=$this->uri->segment(4);
		$update=$this->input->post('update');
		$data['pages_display']='';
		$data['title'] = 'Edit Page';
		$header['title'] = 'Edit Page : Admin';

		$where_page_id=array('id'=>$page_id);
		$data['page_id'] = $page_id;

		$data['update_page_display']=$this->Common_model->getSingle('tbl_pages',$where_page_id);

		if($this->input->post()){
			$this->form_validation->set_rules('page_title', 'Please Enter Page Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('page_heading', '', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_keywords', '', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_description', '', 'trim|xss_clean');
			$this->form_validation->set_rules('parent_page', '', 'trim|xss_clean');
			$this->form_validation->set_rules('page_content', '', 'trim|xss_clean');
			$this->form_validation->set_message('is_natural_no_zero', 'The Parent Page field is required.');

			if(!$this->form_validation->run()== FALSE){	
				$this->Page_model->editPage($page_id);	
				$this->session->set_flashdata('msg','Page Updated Successfully.');
				redirect("admin/items/all_pages");	
			}				
		}	
		$data['parentpages']=$this->Common_model->getAll('tbl_pages','','','','','');	
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/page_update', $data);
		$this->load->view('admin-html/include/footer');	
	}	

	function del($var){
		if($var){
			$this->db->delete('tbl_items', array('id' => $var)); 
			$this->db->delete('item_area', array('item_id' => $var)); 
			 redirect('admin/items/all');
		}
	}
			 
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	   $this->db->delete('tbl_items', array('id' => $var)); 
		  	   $this->db->delete('item_area', array('item_id' => $var)); 
         	}
    	}
		redirect('admin/items/all');
 	} 

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_items ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/items/all_pages/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/items/all/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_items ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/items/all/'); 
			exit;
		}
		redirect('admin/items/all/'); 
		exit;
	}

	function reSetOrder(){
		$page_id = $this->input->post("id");
		$row['order'] = $this->input->post("filed_val");
		$where = array('id' => $page_id );
		$this->common_model->updateValue($row,'tbl_pages',$where);
		//echo $this->db->last_query();
		//exit;
		echo 'Rank is update';
	}
	public function get_area(){
		$city_id = $this->uri->segment('3');
		$where = array('status' => 'active', 'city_id' => $city_id);
		$city = $this->common_model->getResults('id,area_name','tbl_city_area',$where);
		echo $this->db->last_query();
		$option = '';
		foreach($city as $obj){
			$option .='<option value="'.$obj->id.'">'.$obj->area_name.'</option>'; 
		}
		echo $option;
	}	
	
					 		   
}