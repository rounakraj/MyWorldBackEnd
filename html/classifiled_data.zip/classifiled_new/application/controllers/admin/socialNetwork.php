<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SocialNetwork extends CI_Controller {
	function __construct(){
        parent::__construct();
		$this->active_template = activeTemplate();
		
	}
	public function index(){
		$data['title'] = "Social Media";
		$header['title'] = "Social Media Lists | Admin";
		$data['result'] = $this->common_model->getResults('*','tbl_social_meida_link');
		$this->load->view('admin-html/include/header',$header);
      	$this->load->view('admin-html/modifysocialmedia',$data);
        $this->load->view('admin-html/include/footer');
	}
    
	function add(){
		
	  $data['title'] = "Social Media";	
	  $header['title'] = "Social Media Info | Admin ";
	 
	  if($this->input->post('submit2')){
	  
	  		$this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('link', 'Link', 'trim|xss_clean');
			if(!$this->form_validation->run() == FALSE){
				
				$media['social_media'] = $this->input->post('title');
				$media['link'] = $this->input->post('link');
				$media['date'] = date('Y-m-d');
				if($_FILES['image']['name']){
					$icon = $this->upload();
					$media['image'] = $icon['upload_data']['file_name'];
				}
				$this->common_model->insertValue('tbl_social_meida_link',$media);
				$this->session->set_flashdata('msg','Social Media Change Successfully');
				redirect('admin/socialNetwork/');
			}
		
	  }
	  //$data['result'] = $this->common_model->getSingleRow('*','tbl_social_meida_link',array('id' => $id));
	  $this->load->view($this->active_template.'/include/header',$header);
	  $this->load->view($this->active_template.'/add-social-media',$data);
	  $this->load->view($this->active_template.'/include/footer');
	}
	
	function editSocialInfo(){
		
	  $data['title'] = "Social Media";	
	  $header['title'] = "Social Media Info | Admin ";
	  $id = $this->uri->segment('4');
	  if($this->input->post('submit2')){
	  
	  		$this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('link', 'Link', 'trim|xss_clean');
			if(!$this->form_validation->run() == FALSE){
				
				$media['social_media'] = $this->input->post('title');
				$media['link'] = $this->input->post('link');
				$media['date'] = date('Y-m-d');
				if($_FILES['image']['name']){
					$icon = $this->upload();
					$media['image'] = $icon['upload_data']['file_name'];
				}
			
				$where = array('id' => $id);
				$this->common_model->updateValue($media,'tbl_social_meida_link',$where);
				$this->session->set_flashdata('msg','Social Media Change Successfully');
				redirect('admin/socialNetwork/index/');
			
			}
		
	  }
	  $data['result'] = $this->common_model->getSingleRow('*','tbl_social_meida_link',array('id' => $id));
	  $this->load->view($this->active_template.'/include/header',$header);
	  $this->load->view($this->active_template.'/edit_social_info',$data);
	  $this->load->view($this->active_template.'/include/footer');
	} 
	
	function upload(){
		$config['upload_path'] = './uploaded/social-media';
		$this->input->post('media_type');
		$config['allowed_types'] = 'jpg|png|gif|JPEG|PNG|GIF|JPG|jpeg';
		
    	$config['max_size'] = '1000';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		
		if (! $this->upload->do_upload('image')){
			 return $error = array('error' => $this->upload->display_errors());
			
		}
		else{
			return $data = array('upload_data' => $this->upload->data());
			
		}
	}
	
	function del(){
		$id = $this->uri->segment(4);
		$isDeleted = $this->uri->segment(5);
		if($category_id){
			$updateArray = array('isDeleted'=>'1');
			$deleteRow=$this->common_model->updateValue($updateArray, 'tbl_category' ,array('id'=>$category_id));
			if($deleteRow){
				 $this->session->set_flashdata('actMsg', 'Delete Successfully');
			}else{
			   $this->session->set_flashdata('actMsg', 'Some Error Occurred');
			}
		 redirect('admin/category/listing');
		}
	}	
	
	function reSetOrder(){
		$id = $this->input->post("id");
		$row['rank'] = $this->input->post("filed_val");
		$where = array('id' => $id );
		$this->common_model->updateValue($row,'tbl_social_meida_link',$where);
		echo $this->db->last_query();
		exit;
		echo 'Rank is update';
		
	}		

 }  

