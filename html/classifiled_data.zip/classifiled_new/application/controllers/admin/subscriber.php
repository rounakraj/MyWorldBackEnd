<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subscriber extends CI_Controller {
	public function __construct()
	{
		 parent::__construct();
		 $this->load->model('admin/subscriber_model','Subscriber',TRUE);
	}
	
	public function index()
	{
		redirect('admin/subscriber/lists');
	}

	public function lists(){		

		$data['title'] = "Lists";
		$header['title'] = "Subscriber Lists : Admin"; 
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/subscriber/lists/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';	

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $this->Subscriber->dataCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		
		$data['result'] = $data['pages'] = $this->Subscriber->getAll($pconfig['per_page'], $c_page,$key);
	
		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header); 
        $this->load->view('admin-html/subscriber-list',$data);
        $this->load->view('admin-html/include/footer');
	}

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_newsletter_subscriber',$where);
			$this->session->set_flashdata('msg','Status Change Successfully.');
			redirect('admin/subscriber/lists/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Status Not be Changed Successfully.');
		redirect('admin/subscriber/lists/'); 
		exit;
 	}	

	function del($var){
		if($var){
			$this->common_model->updateValue(array('isDeleted'=>'1'),'tbl_newsletter_subscriber', array('id' => $var)); 
			$this->session->set_flashdata('msg','Subscriber Deleted Successfully.');
			redirect('admin/subscriber/lists');
		}
	}
	
	
	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_newsletter_subscriber',$where);
			}
			$this->session->set_flashdata('msg','Status Change Successfully.');
			redirect('admin/subscriber/lists/'); 
			exit;
		}
		redirect('admin/subscriber/lists/'); 
		exit;
	}
	
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	  $this->common_model->updateValue(array('isDeleted'=>'1'),'tbl_newsletter_subscriber', array('id' => $var)); 
         	}
    	}
		redirect('admin/subscriber/lists');
 	} 

	public function add()
	{
		if($this->input->post('save'))
		{
			$this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
			
			if(!$this->form_validation->run() == FALSE)
			{
				$title = $this->input->post('title');
				$subject = $this->input->post('subject');
				$content = $this->input->post('content');			

				$newsletterInsertArray = array('title'=>$title,
										  'subject'=>$subject,
										  'content'=>$content,
										  'created_date'=>date('Y-m-d')
										  );
				$lastInsert = $this->common_model->insertValue('tbl_newsletter_subscriber',$newsletterInsertArray);
				if($lastInsert > 0){
					$this->session->set_flashdata('msg','Subscriber Information Saved Successfully.');
					redirect('admin/subscriber');
				}
			}	
		}
		//$data['sportDetails'] = $this->Common_model->getSingle('sports','','','','','');	
		$data['title'] = "Add New";
		$header['title'] = "Add Subscriber Template : Admin";
		$this->load->view('admin-html/include/header',$header);       
        $this->load->view('admin-html/add-subscriber-template',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function update()
	{	 
		$newsletter_id = $this->uri->segment(4);
		$where = array('id'=>$newsletter_id);
		$data['singleRow'] = $this->common_model->getSingle('tbl_newsletter_subscriber',$where);
		if($this->input->post('update'))
		{
			$this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
			
			if(!$this->form_validation->run() == FALSE)
			{
				$title = $this->input->post('title');
				$subject = $this->input->post('subject');
				$content = $this->input->post('content');			

				$newsletterArray = array('title'=>$title,
										  'subject'=>$subject,
										  'content'=>$content,
										  'created_date'=>date('Y-m-d')
										  );
				$lastInsert = $this->common_model->updateValue($newsletterArray, 'tbl_newsletter_subscriber',$where);
				if($lastInsert > 0){
					$this->session->set_flashdata('msg','Subscriber Information Updated Successfully.');
					redirect('admin/subscriber/update/'.$newsletter_id);
				}
			}	
		}
		//$data['sportDetails'] = $this->Common_model->getSingle('sports','','','','','');	
		$data['title'] = "Edit";
		$header['title'] = "Edit Subscriber Template : Admin";
		$this->load->view('admin-html/include/header',$header);       
        $this->load->view('admin-html/update-subscriber-template',$data);
        $this->load->view('admin-html/include/footer');	

	}

	
	public function delete_newsletter()
	{
		$newsletterId=$this->uri->segment(4);
		$this->Common_model->deleteData('holiday_newsletter',array('id'=>$newsletterId));
		$this->session->set_flashdata('actionmsg','Subscriber Deleted successfully.');
		redirect('admin/subscriber'); 
	}


	function send_mail()
	{
		$sentMail2 = '';
		$email_id_arr = explode(',',$_GET['customer_email_id']);
		$no_of_subscriber_to_sent = count($email_id_arr);
		$whereNewsId=array('id'=>$_GET['email_template_id']);
		//print_r($wherePageId);exit;

		$email_template_display = $this->Common_model->getSingle('holiday_newsletter',$whereNewsId,'','','','');
		$emailSubject = $email_template_display->subject;
		$emailContent = $email_template_display->content;
		foreach($email_id_arr as $val)
		{		

			$newsLetterSubscriber = $this->Common_model->getSingle('holiday_newsletter_subscriber',array('email'=>$val),'','','','');

			if($newsLetterSubscriber->subscriber_status == 'Subscribed')
			{					
				$this->load->library('email');
				$this->email->set_mailtype("html");
				$this->email->from("Holidaybooked.com");
				$this->email->to($val);
				$this->email->subject($emailSubject);
				
				$msg = $emailContent;
				//$msg.='<br><br>Thanks';
				//$msg.='<br>Holidaybooked';
				$this->email->message($msg);
				$sentMail2=$this->email->send();
				//echo $this->email->print_debugger();
			}
		}	
		if($sentMail2)
		{
			echo 'Sent successfully';
		}
		else
		{
			echo 'Please try after sometime';
		}
	}	
}

?>