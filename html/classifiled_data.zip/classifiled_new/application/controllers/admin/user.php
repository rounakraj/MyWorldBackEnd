<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Controller {
	public function __construct(){
		 parent::__construct();		 		 
		 $this->load->model('admin/user_model','User','true');
		 $this->load->library('encrypt');
	}

	public function index(){	
		redirect('admin/user/allUsers/');
	}

	public function add_new(){		
		$data['title'] = 'Add New';
		$header['title'] = 'Add New User : Admin  ';
		
		if($this->input->post()) {
			$this->form_validation->set_rules('name', 'Please Enter First Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('username', 'Please Enter Username', 'trim|required|xss_clean');
			$this->form_validation->set_rules('password', 'Please Enter Password', 'trim|required|xss_clean');
		
			if(!$this->form_validation->run() == FALSE){
				if($this->User->add_new()==true){			
					$this->session->set_flashdata('msg','User Added Successfully.');
					redirect('admin/user/add_new');
				}			
			}
		}
		$this->load->view('admin-html/include/header',$header);     
        $this->load->view('admin-html/add-user',$data);
        $this->load->view('admin-html/include/footer');
	}

	public function allUsers(){		
		$data['title'] = "List";
		$header['title'] = "Users List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/user/allUsers/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}
		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}

		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}
		$total_rows = $total_rows = $this->User->dataCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		$data['result'] = $data['pages'] = $this->User->dataGetAll($pconfig['per_page'], $c_page,$key);

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();
		$this->load->view('admin-html/include/header',$header);		
        $this->load->view('admin-html/all-users',$data);
        $this->load->view('admin-html/include/footer');
	}

	public function update(){		
		$user_id=$this->uri->segment(4);
		$data['title'] = 'Edit';
		$header['title'] = 'Edit User : Admin  ';
		//$data['countryDetail']=$this->common_model->getAll('tbl_country', array('status'=>1));	
		$data['user_detail']=$this->common_model->getSingle('tbl_user',array('id'=>$user_id));

		if($this->input->post()) {
			$this->form_validation->set_rules('name', 'Please Enter First Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('username', 'Please Enter Username', 'trim|required|xss_clean');
			$this->form_validation->set_rules('password', 'Please Enter Password', 'trim|required|xss_clean');
					
			if(!$this->form_validation->run() == FALSE){
				if($this->User->update($user_id)==true){			
					$this->session->set_flashdata('msg','User Updated Successfully.');
					redirect('admin/user/allUsers');
				}			
			}
		}

		$this->load->view('admin-html/include/header',$header);     
        $this->load->view('admin-html/update-user',$data);
        $this->load->view('admin-html/include/footer');
	}

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_user ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/user/allUsers/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/user/allUsers/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_user ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/user/allUsers/'); 
			exit;
		}
		redirect('admin/user/allUsers/'); 
		exit;
	}

	function del($id){
		if((int)$id > 0){
        	$this->db->delete('tbl_user', array('id' => $id));
			$this->session->set_flashdata('msg','User Deleted Successfully.');
	        //$this->db->delete('tbl_user', array('id' => $id));
			  redirect('admin/user/allUsers/');
	    }
	}

	function delmul(){
	    $var=$this->input->post("chk");
	    if($var!=''){
          for($i=0; $i<count($var); $i++){
          	$this->db->delete('tbl_user', array('id' => $var[$i]));
          }
		   $this->session->set_flashdata('msg','User record deleted successfully.');
		} 
		redirect('admin/user/allUsers/');
 	}		 		   

}