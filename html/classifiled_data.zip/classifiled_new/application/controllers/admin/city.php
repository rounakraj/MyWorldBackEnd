<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class City extends CI_Controller {
	function __construct(){
        parent::__construct();
		$this->load->model('admin/city_model','City',TRUE);
	}
	public function index(){	
		redirect('admin/city/allCity/');
		
	}

	public function add_new(){		
		$data['title'] = 'Add New';
		$header['title'] = 'Add New City : Admin  ';
		
		if($this->input->post()) {
			$this->form_validation->set_rules('city_name', 'Please Enter City Name', 'trim|required|xss_clean');
			if(!$this->form_validation->run() == FALSE){
				$city['city_name'] = $this->input->post('city_name');
				$this->common_model->insertValue('tbl_city',$city);
				$this->session->set_flashdata('msg','City Updated Successfully.');
					redirect('admin/city/allCity');			
			}
		}
		$this->load->view('admin-html/include/header',$header);     
        $this->load->view('admin-html/add-City',$data);
        $this->load->view('admin-html/include/footer');
	}

	public function allCity(){		
		$data['title'] = "List";
		$header['title'] = "City List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/city/allCity/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}
		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}

		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}
		$total_rows = $total_rows = $this->City->dataCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		$data['result'] = $data['pages'] = $this->City->dataGetAll($pconfig['per_page'], $c_page,$key);

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();
		$this->load->view('admin-html/include/header',$header);		
        $this->load->view('admin-html/all-city',$data);
        $this->load->view('admin-html/include/footer');
	}

	public function update(){		
		$city_id=$this->uri->segment(4);
		
		$data['title'] = 'Edit';
		$header['title'] = 'Edit User : Admin  ';
		$data['city_detail']=$this->common_model->getSingle('tbl_city',array('id'=>$city_id));
		

		if($this->input->post()) {
			$this->form_validation->set_rules('city_name', 'Please Enter City Name', 'trim|required|xss_clean');
					
			if(!$this->form_validation->run() == FALSE){
				$city['city_name'] = $this->input->post('city_name');
				$where = array('id'=> $city_id);
				if($this->common_model->updateValue($city,'tbl_city',$where)==true){			
					$this->session->set_flashdata('msg','City Updated Successfully.');
					redirect('admin/city/allCity');
				}			
			}
		}

		$this->load->view('admin-html/include/header',$header);     
        $this->load->view('admin-html/update-city',$data);
        $this->load->view('admin-html/include/footer');
	}

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_city ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/city/allCity/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/city/allCity/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_city ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/city/allCity/'); 
			exit;
		}
		redirect('admin/city/allCity/'); 
		exit;
	}

	function del($id){
		if((int)$id > 0){
        	$this->db->delete('tbl_city', array('id' => $id));
			$this->session->set_flashdata('msg','City Deleted Successfully.');
	        redirect('admin/city/allCity/');
	    }
	}

	function delmul(){
	    $var=$this->input->post("chk");
	    if($var!=''){
          for($i=0; $i<count($var); $i++){
          	$this->db->delete('tbl_city', array('id' => $var[$i]));
          }
		   $this->session->set_flashdata('msg','City record deleted successfully.');
		} 
		redirect('admin/city/allCity/');
 	}	

 }  

