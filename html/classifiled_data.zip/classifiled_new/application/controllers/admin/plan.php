<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class plan extends CI_Controller {
	
	public function __construct() {
		 parent::__construct();		 
		 $this->load->model('Common_model');
		 $this->load->model('admin/plan_model','PlanModel',TRUE);
	}

	public function index(){	
		redirect('admin/plan/all');
	}
	
	public function add($plan_id){		
		$data['title'] = 'Add New Plan';
		$header['title'] = 'Add New Plan : Admin';
		
		if($plan_id){
			$data['title'] = 'Update Plan';
			$header['title'] = 'Update Plan';
			$where = array('id' => $plan_id );
			$data['plan']=$this->Common_model->getSingle('tbl_plan',$where,'','','','');
			
			// echo $this->db->last_query(); 
		}
		
		
		if($this->input->post()) {
			
			$this->form_validation->set_rules('name', 'Please Enter Plan Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('price', 'Please Enter Plan Amout', 'trim|xss_clean');
			$this->form_validation->set_rules('month', 'Please Enter Month', 'trim|xss_clean');
			
			if($this->form_validation->run() == TRUE){
				
				if($this->PlanModel->addNew()==true){			
					
					$this->session->set_flashdata('msg','Plan Added Successfully.');
					redirect('admin/plan/all');
				}
			}
		}		
		
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/add-plan',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function all(){		

		$data['title'] = "Plan List";
		$header['title'] = "All plan List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/plan/all/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_Plan = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_Plan = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_Plan = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->PlanModel->AllCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_Plan);
		
		$data['result'] =  $this->PlanModel->GetAll($pconfig['per_page'], $c_Plan,$key);
		
		
		//pr($data); exit; 

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/planList',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function edit(){
		$Plan_id=$this->uri->segment(4);
		$update=$this->input->post('update');
		$data['Plan_display']='';
		$data['title'] = 'Edit Plan';
		$header['title'] = 'Edit Plan : Admin';

		$where_Plan_id=array('id'=>$Plan_id);
		$data['Plan_id'] = $Plan_id;

		$data['update_Plan_display']=$this->Common_model->getSingle('tbl_plan',$where_Plan_id);

		if($this->input->post()){
			$this->form_validation->set_rules('Plan_title', 'Please Enter Plan Title', 'trim|required|xss_clean');
			$this->form_validation->set_rules('Plan_heading', '', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_keywords', '', 'trim|xss_clean');
			$this->form_validation->set_rules('meta_description', '', 'trim|xss_clean');
			$this->form_validation->set_rules('parent_Plan', '', 'trim|xss_clean');
			$this->form_validation->set_rules('Plan_content', '', 'trim|xss_clean');
			$this->form_validation->set_message('is_natural_no_zero', 'The Parent Plan field is required.');

			if(!$this->form_validation->run()== FALSE){	
				$this->Plan_model->editPlan($Plan_id);	
				$this->session->set_flashdata('msg','Plan Updated Successfully.');
				redirect("admin/plan/all_Plans");	
			}				
		}	
		$data['parentPlans']=$this->Common_model->getAll('tbl_plan','','','','','');	
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/Plan_update', $data);
		$this->load->view('admin-html/include/footer');	
	}	

	function del($var){
		if($var){
			$this->db->delete('tbl_plan', array('id' => $var)); 
			redirect('admin/plan/all');
		}
	}
			 
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	   $this->db->delete('tbl_plan', array('id' => $var)); 
		  	   $this->db->delete('Plan_area', array('Plan_id' => $var)); 
         	}
    	}
		redirect('admin/plan/all');
 	} 

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_plan ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/plan/all/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/plan/all/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_plan ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/plan/all/'); 
			exit;
		}
		redirect('admin/plan/all/'); 
		exit;
	}

	function reSetOrder(){
		$Plan_id = $this->input->post("id");
		$row['order'] = $this->input->post("filed_val");
		$where = array('id' => $Plan_id );
		$this->common_model->updateValue($row,'tbl_plan',$where);
		//echo $this->db->last_query();
		//exit;
		echo 'Rank is update';
	}
	public function get_area(){
		$city_id = $this->uri->segment('3');
		$where = array('status' => 'active', 'city_id' => $city_id);
		$city = $this->common_model->getResults('id,area_name','tbl_city_area',$where);
		echo $this->db->last_query();
		$option = '';
		foreach($city as $obj){
			$option .='<option value="'.$obj->id.'">'.$obj->area_name.'</option>'; 
		}
		echo $option;
	}	
	
					 		   
}