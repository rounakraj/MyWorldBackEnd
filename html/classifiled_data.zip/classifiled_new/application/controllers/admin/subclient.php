<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class subclient extends CI_Controller {
	
	public function __construct() {
		 parent::__construct();		 
		 $this->load->model('Common_model');
		 $this->load->model('admin/sub_client_model','SubClientModel',TRUE);
	}

	public function index(){	
		redirect('admin/subclient/all');
	}
	
	public function add($sub_client_id=NULL){		
		$data['title'] = 'Add New  Sub client';
		$header['title'] = 'Add New Sub client : Admin';
		$where_client = array('status' => '1');
		$data['Allclients'] = $this->common_model->getResults('id,client_name','tbl_clients',$where_client);
		
		if($sub_client_id > 0){
			$data['title'] = 'Update Sub client';
			$header['title'] = 'Update Sub client';
			$where = array('id' => $sub_client_id );
			$data['client']=$this->Common_model->getSingle('tbl_sub_clients',$where,'','','','');
		}
		
		$this->db->last_query();
		if($this->input->post()) {
			$this->form_validation->set_rules('client_id', 'Please Select Client', 'trim|required|xss_clean');
			$this->form_validation->set_rules('name', 'Please Enter Client Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('code', 'Please Enter code', 'trim|xss_clean');
			
			if($this->form_validation->run() == TRUE){
				if($this->SubClientModel->addNew()==true){			
					$this->session->set_flashdata('msg','Client Added Successfully.');
					redirect('admin/subclient/all');
				}
			}
		}		
		
	
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/add-sub-client',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	public function all(){		

		$data['title'] = "Sub client List";
		$header['title'] = "All Sub client List : Admin";
		$header['statuslink'] = "true"; /* active/Inactive  searching*/
		$key = '';
		$base_url = base_url().'admin/subclient/all/';
		$data['action'] = $base_url;
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
			$this->session->unset_userdata('status');
		}

		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_client = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_client = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_client = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}else if(strlen($this->uri->segment(4)) > 2){
			$key  = $this->uri->segment(4);
		}

		$total_rows = $total_rows = $this->SubClientModel->AllCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_client);
		
		$data['result'] =  $this->SubClientModel->GetAll($pconfig['per_page'], $c_client,$key);
		
		
		//pr($data); exit; 

		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		$data["links"] = $this->pagination->create_links();

		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/subclientList',$data);
        $this->load->view('admin-html/include/footer');
	}
	
	function del($var){
		if($var){
			$this->db->delete('tbl_sub_clients', array('id' => $var)); 
			redirect('admin/subclient/all');
		}
	}
			 
	function delmul(){
    	$var=$this->input->post("chk");
		if($var!=''){
        	foreach($var as $var){
		  	   $this->db->delete('tbl_sub_clients', array('id' => $var)); 
		  	}
    	}
		redirect('admin/subclient/all');
 	} 

	function changeStatus($id,$status){
		if($id){
			$where = array('id' => $id );
			$row['status'] = $status;
			$this->common_model->updateValue($row,'tbl_sub_clients ',$where);
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/subclient/all/'); 
			exit;
		}
		$this->session->set_flashdata('msg','Operation not successful.');
		redirect('admin/subclient/all/'); 
		exit;
 	}

	function makeChangeStatus($status){
		if($this->input->post("chk")){
			foreach($this->input->post("chk") as $id ){
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_sub_clients ',$where);
			}
			$this->session->set_flashdata('msg','Status Changed Successfully.');
			redirect('admin/subclient/all/'); 
			exit;
		}
		redirect('admin/subclient/all/'); 
		exit;
	}

	function reSetOrder(){
		$sub_client_id = $this->input->post("id");
		$row['order'] = $this->input->post("filed_val");
		$where = array('id' => $sub_client_id );
		$this->common_model->updateValue($row,'tbl_sub_clients',$where);
		//echo $this->db->last_query();
		//exit;
		echo 'Rank is update';
	}
	public function get_area(){
		$city_id = $this->uri->segment('3');
		$where = array('status' => 'active', 'city_id' => $city_id);
		$city = $this->common_model->getResults('id,area_name','tbl_city_area',$where);
		echo $this->db->last_query();
		$option = '';
		foreach($city as $obj){
			$option .='<option value="'.$obj->id.'">'.$obj->area_name.'</option>'; 
		}
		echo $option;
	}	
	
					 		   
}