<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller {
	private $password_key = 'Admin';
	function __construct(){
        parent::__construct();
		$this->load->model('admin/model_dashboard');
		$this->load->library('encrypt');
		$this->load->library('image_lib');
    }

	public function index(){
		
		
		
	  $data['title'] = "Admin | Dashboard";	
	  $header['title'] = "Admin |Dashboard ";
	  $this->load->view('admin-html/include/header',$header);
	  $this->load->view('admin-html/dashboard',$data);
	  $this->load->view('admin-html/include/footer');
	}
	
	
	public function viewStatus(){
			
			
			$date = ($this->input->post('date')) ? date('Y-m-d', strtotime($this->input->post('date'))) :date('Y-m-d'); 
			
			$this->db->select("count(tbl_jobs.id) as total, sum(case WHEN tbl_jobs.ClientUploadDate IS NULL THEN 0 ELSE 1 END) AS total_uploaded, tbl_clients.client_name");
			$this->db->from('tbl_jobs');
			$this->db->join('tbl_clients','tbl_clients.id = tbl_jobs.clientId','INNER');
			$this->db->where('tbl_jobs.EnggDownloadDate',$date);
			$this->db->group_by('tbl_jobs.clientId');
			
			$query = $this->db->get();
			
			$data['reports'] = $query->result_array();
			$data['title'] = "Admin | Dashboard";	
			$header['title'] = "Admin |Dashboard ";
			
			$this->load->view('admin-html/include/header',$header);
			$this->load->view('admin-html/view_status',$data);
			$this->load->view('admin-html/include/footer');
	} 

    public function administrator(){
		$data['title'] = "Change Admin Info";
		$header['title'] = "Setting Admin Info : Admin";
		
		if($this->input->post('submit2')){
			$this->form_validation->set_rules('fname', 'Fast Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', 'Admin Email', 'trim|required|xss_clean');
			$this->form_validation->set_rules('uname', 'User Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('pass', 'Password ', 'trim|required|xss_clean');
			$this->form_validation->set_rules('cpass', ' Confirm Password', 'trim|required|xss_clean|matches[pass]');
			
			if(!$this->form_validation->run() == FALSE){
				$where = array('admin_id'=>'1');
				$admin['fname'] = trim($this->input->post('fname'));
				$admin['lname'] = trim($this->input->post('lname'));
				$admin['admin_user'] = trim($this->input->post('uname'));
				$admin['admin_pass'] = $this->encrypt->encode(trim($this->input->post('pass')));
				$admin['email_address'] = trim($this->input->post('email'));
				$admin['modified_date'] = date('Y-m-d');
				
				
				$this->common_model->updateValue($admin,'tbl_admin',$where);
				$this->session->set_flashdata('msg','Admin Info Changed Successfull.');
				redirect('admin/dashboard/administrator');
			}
		}

		$data['query'] = $this->model_dashboard->admin_data_val();
		$data['admin_pass'] = $this->encrypt->decode($data['query']['admin_pass']);
		$this->load->view('admin-html/include/header',$header);
        $this->load->view('admin-html/administator_settings_inner',$data);
        $this->load->view('admin-html/include/footer');
    } 

	function email_template(){
	  $data['title'] = "Set Mail Data";	
	  $header['title'] = "Admin |Dashboard ";
	  $id = $this->uri->segment('4');
	  if($this->input->post('submit1')){
	  		$this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
			$this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');
			if(!$this->form_validation->run() == FALSE){
				$email['subject'] = $this->input->post('subject');
				$email['message'] = $this->input->post('message');
				$email['date'] = date('Y-m-d');

				$where = array('id' => $id);
				$this->common_model->updateValue($email,'tbl_email_notification',$where);
				redirect('admin/dashboard/email_template/'.$id);
			}
	  }

	  $data['result'] = $this->common_model->getSingleRow('*','tbl_email_notification',array('id' => $id));
	  $this->load->view('admin-html/include/header',$header);
	  $this->load->view('admin-html/edit_email_template',$data);
	  $this->load->view('admin-html/include/footer');
	} 
								 
	function siteInfo(){
		$this->load->library('image_lib');
		$where = array('id'=>'1');
		if ( $this->input->post('submit2')){
			$this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('phone', 'Phone No', 'trim|required|xss_clean');
			$this->form_validation->set_rules('mobile_no', 'Mobile No', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');

			if(!$this->form_validation->run() == FALSE){

				$site_info['company_name'] = trim($this->input->post('name'));
				$site_info['address'] = addslashes(trim($this->input->post('address')));
				$site_info['phone_no'] = trim($this->input->post('phone'));
				$site_info['mobile_no'] = trim($this->input->post('mobile_no'));
				$site_info['email'] = trim($this->input->post('email'));
				$site_info['meta_title'] = trim($this->input->post('meta_title'));
				$site_info['meta_description'] = trim($this->input->post('meta_description'));
				$site_info['meta_keyword'] = trim($this->input->post('meta_keyword'));
				$site_info['google_analytics'] = trim($_POST['google_analytics']);
				$site_info['google_map'] = trim($_POST['google_map']);
								
				if($_FILES['image']['name']){
					$icon = $this->upload();
					$site_info['logo'] = $icon['upload_data']['file_name'];
				} 
				
				$this->common_model->updateValue($site_info,'tbl_site_info',$where);
				$this->db->last_query(); 
				$this->session->set_flashdata('msg','Change Site Info');
				redirect('admin/dashboard/siteInfo/1');
			}
		}

		$data['site_info'] = $this->common_model->getSingleRow('*','tbl_site_info',$where);

		$data['title'] = 'Site Info';
		$header['title'] = 'Site Info : Admin';
		$this->load->view('admin-html/include/header',$header);
	  	$this->load->view('admin-html/site_info.php',$data);
	  	$this->load->view('admin-html/include/footer');
	}	
	
/*-------- Upload Site Logo -------------- */
	function upload(){		
		$config['upload_path'] = './uploaded/logo';
		$this->input->post('media_type');
		$config['allowed_types'] = 'jpg|png|JPEG|PNG|JPG|jpeg';
		
    	$config['max_size'] = '1000';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		
		if (! $this->upload->do_upload('image')){
			 return $error = array('error' => $this->upload->display_errors());
		}
		else{
			$data = array('upload_data' => $this->upload->data());
			
			$config['image_library'] = 'gd2';
			$config['source_image'] = $this->upload->upload_path.$this->upload->file_name;
			$config['new_image'] = $this->upload->upload_path."thumbs/".$this->upload->file_name;
			$config['thumb_marker'] = '';
			$config['create_thumb'] = TRUE;
			$config['maintain_ratio'] = TRUE;
			$config['width'] = 100;
			$config['height'] = 100;
			$this->image_lib->initialize($config); 
			$this->load->library('image_lib', $config); 
			$this->image_lib->resize();
			return $data;
		}
	}
	
	/*------ Databse back up ------ */
	public function db_backup()
	{
		$this->load->dbutil();
		$backup = $this->dbutil->backup();	
		$this->load->helper('download');
		force_download($this->db->database.'_'.date("dmY").'.gz', $backup);
	}
 }  