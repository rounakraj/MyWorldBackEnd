<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dbbackup extends CI_Controller {	
	function __construct(){        
		parent::__construct();		
		$this->load->dbutil();				
	}	
	
	function index(){		 
		$prefs = array(                     
					   'format'      => 'sql',                             
					   'filename'    => 'my_db_backup.sql' 
					   );		
		$backup =& $this->dbutil->backup($prefs);
		$this->load->helper('file');		
		write_file('media/mybackup.sql', $backup);		
		$this->load->helper('download');				
		force_download('mybackup.sql', $backup);	
	}
}
?>	