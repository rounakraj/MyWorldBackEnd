<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class emailTemplate extends CI_Controller {
	var $active_template ;
	function __construct(){
        parent::__construct();
		$this->active_template = activeTemplate();
		$this->load->model('admin/model_email_template');
    }
	
	public function index(){
	  
	    $data['title'] = "Email Template Details";
		$header['title'] = "Email Template Details : Admin";
		$key = '';
		$base_url = base_url().'admin/emailTemplate/index/';
		$data['action'] = $base_url;
		
		/* Searching Pagination Order */
		$data['order'] = 'ASC';
		$data['order'] = 'ASC';
		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			if($this->uri->segment(4) == 'ASC'){
				$data['order'] = 'DESC'; 
			}else {
				$data['order'] = 'ASC'; 
			}
		}

		if(!$this->uri->segment(4)){
			$this->session->unset_userdata('search_key');
		}

		
		if($this->uri->segment(4) == 'ASC' || $this->uri->segment(4) == 'DESC' ){
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
		}else {
			$c_page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		}
		
		if (in_array($this->uri->segment(4),searchkey())) {
    		$this->session->unset_userdata('search_key');
			$c_page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$base_url = $base_url.$this->uri->segment(4).'/';
			$key  = $this->uri->segment(4);
		}
		
		$total_rows = $this->model_email_template->emailTemplateCount($key);
		$pconfig = setPaginationConfig($base_url,$total_rows,$c_page);
		
		/* End Pagination , Searching ,Order */
		$this->load->library('pagination');
		$this->pagination->initialize($pconfig);
		
		$data['result'] = $this->model_email_template->emailTemplateGetAll($pconfig['per_page'], $c_page,$key);
		
		
		$data["links"] = $this->pagination->create_links();
		
		$this->load->view($this->active_template.'/include/header',$header);
       // $this->load->view('admin-html/include/left-sidebar',$data);
        $this->load->view($this->active_template.'/modifyemailtemplate',$data);
        $this->load->view($this->active_template.'/include/footer');
	 
	}
    
	function email_template(){
		
	  $data['title'] = "Set Mail Data";	
	  $header['title'] = "Admin |Dashboard ";
	  $id = $this->uri->segment('4');
	  if($this->input->post('submit1')){
	  
	  		$this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
			$this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');
			if(!$this->form_validation->run() == FALSE){
				
				$email['subject'] = $this->input->post('subject');
				$email['message'] = $this->input->post('message');
				$email['declaimer'] = $this->input->post('declaimer');
				$email['heading'] = $this->input->post('heading');
				$email['date'] = date('Y-m-d');
				
				$where = array('id' => $id);
				$this->common_model->updateValue($email,'tbl_email_notification',$where);
				$this->session->set_flashdata('msg','Email Template Change Successfully');
				redirect('admin/emailTemplate/index/');
				
			
			}
		
	  }
	  $data['result'] = $this->common_model->getSingleRow('*','tbl_email_notification',array('id' => $id));
	  
	  $this->load->view($this->active_template.'/include/header',$header);
	  $this->load->view($this->active_template.'/edit_email_template',$data);
	  $this->load->view($this->active_template.'/include/footer');
	} 
	
		function changeStatus($id,$status){
	
	if($id){
		$where = array('id' => $id );
		$portal['status'] = $status;
		$this->common_model->updateValue($portal,'tbl_email_notification',$where);
		//$this->db->last_query(); 
		$this->session->set_flashdata('msg','Status Change Successfully.');
		redirect('admin/emailTemplate/index');
		exit;
	}
		$this->session->set_flashdata('msg','Status Not be Change Successfully.');
		redirect('admin/emailTemplate/index');
		exit;
						      
 }  
	
	function makeChangeStatus($status){
		if($this->input->post("chk")){
			
			foreach($this->input->post("chk") as $id ){
				
				$where = array('id' => $id );
				$row['status'] = $status;
				$this->common_model->updateValue($row,'tbl_email_notification',$where);
			}
			$this->session->set_flashdata('msg','Status Change Successfully.');
			redirect('admin/emailTemplate/index');
			exit;
		}
		redirect('admin/emailTemplate/index');
			exit;
	}
								 

 }  

