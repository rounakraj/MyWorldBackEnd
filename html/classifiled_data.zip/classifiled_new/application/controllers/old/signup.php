<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Signup extends CI_Controller{
	public function __construct(){
		 parent::__construct();	
		 $this->load->model('common_model');		 
	} 
	
	public function index(){	
		
		$data['content'] = 'index';
		$data['home'] = '1';
		$data['byMobileLink'] = '1';
		$this->load->library('captcha');
		$data['captcha'] = $this->captcha->main();
		$this->load->view('Layout/home_layout', $data);		
		
		//$this->load->view('comingsoon', $data);		
	}
	
	
	
} 
/* End of file index.php */
/* Location: ./application/controllers/index.php */