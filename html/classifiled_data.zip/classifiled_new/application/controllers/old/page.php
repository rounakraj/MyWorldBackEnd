<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller {

	public function __construct() 

    {

		 parent:: __construct();		 

		 $this->load->model('Common_model');

	}



	public function _remap($method){	

		$method=str_replace('_','-',$method);

		if($method){

			$displayPage = $this->Common_model->getSingle('tbl_pages',array('slug'=>$method,'status'=>'Active'));

			if($displayPage){	

				$data['page_content'] = $displayPage;
				$data['content'] = 'cms-page';
				$this->load->view('Layout/home_layout', $data);	

			  }

		}else{

			$data['content'] = '';

			$this->load->view('Layout/home_layout', $data);			

		}			

	}

}

?>