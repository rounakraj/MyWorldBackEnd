<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home extends CI_Controller{
	public function __construct(){
		 parent::__construct();	
		 $this->load->model('common_model');		 
	} 
	
	public function index(){	
		
		$data['content'] = 'index';
		$data['home'] = '1';
		$this->load->library('captcha');
		$data['captcha'] = $this->captcha->main();
		$this->load->view('Layout/home_layout', $data);		
		
		//$this->load->view('comingsoon', $data);		
	}
	
	function captchLoad(){
		$this->load->library('captcha');
		$data['captcha'] = $this->captcha->main();
		$this->session->set_userdata('captcha_info', $data['captcha']);
		echo $data['captcha']['image_src'];
		
	}
	
	function captchaValid(){
		$captcha_info = $this->session->userdata('captcha_info');
		if ($captcha_info['code'] != $this->input->post('captchcode')){
    		echo "Not valid";	}
		else{
			echo "Success";
		}
		exit; 
		
	}
	
	public function development(){	
		$data['content'] = 'index';
		$this->load->view('Layout/home_layout', $data);		
	}
	
	
	function mobilePrivacy(){
		
		$displayPage = $this->Common_model->getSingle('tbl_pages',array('id'=> '14','status'=>'Active'));
		if($displayPage){	
				$data['page_content'] = $displayPage;
				$data['content'] = 'cms-page';
				$this->load->view('Layout/mobile_layout', $data);	
				
		}
		else{
			$data['content'] = '';
			$this->load->view('Layout/home_layout', $data);			
		}			
		
		
	}
	
	function mobileDisclaimer(){
		
		$displayPage = $this->Common_model->getSingle('tbl_pages',array('id'=>'16','status'=>'Active'));
		if($displayPage){	
				$data['page_content'] = $displayPage;
				$data['content'] = 'cms-page';
				$this->load->view('Layout/mobile_layout', $data);	
				
		}
		else{
			$data['content'] = '';
			$this->load->view('Layout/home_layout', $data);			
		}			
	}

	function emailTest(){
		$to = "dkumarchudhary@gmail.com";
		$subject = "HTML email";
		echo $header = '
<html>
	<head>
		<title> </title>		
	</head>
	<body style="font-family: Open Sans,sans-serif">
		
<table id="bgtable" align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
    <tr>
        <td align="center" valign="top">
            <!-- container 600px -->
            <table border="0" cellpadding="0" cellspacing="0" class="container" width="80%" style="...">
                <tr>
                    <td align="left" style="background-color: #000; margin:5px; "  >
                        <img src="http://www.bro-king.com/website/html/images/logo@2x.png" style="margin: 10px;"/>
                    </td>
                </tr>
                <tr>
                    <td align="left" style="background-color: #EDEDED" >';
                    
                       $content = '<div style="margin: 40px 20px 40px 20px">
                       <p>Hi *Subscriber Name*!</p>
                       <p>To verify your email, please click on the link below:</p>
                       <p>
                       	<a href="http://www.bro-king.com/verification">http://www.___________________________</a> 
                       </p>
                       <p style="font-weight: bold">
                       	Regards,</br>
                       	Team Bro-King
                       	
                       </p>

                       </div>';
                       
                       
                    $footer = '</td>
                </tr>
                <tr>
                    <td style="background-color:#EFC70B" background="http://www.bro-king.com/website/html/images/emailfoter.png" height="140">
                    <div class="address">
					
                        
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
	</body>
</html>';

echo $body = $header.$content.$footer; 


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <info@bro-king.com>' . "\r\n";
//$headers .= 'Cc: myboss@example.com' . "\r\n";

//mail($to,$subject,$message,$headers,'bro-king');
	
	
	}
	
	
	function contact(){
		
		
		$name = $this->input->post('name'); 
		$email = $this->input->post('email'); 
		$message = $this->input->post('message'); 
		$mobile = $this->input->post('mobile'); 
		
		 $content = '<div style="margin: 40px 20px 40px 20px">
                       <p>Hi,</p>
                       <p>Some one wants to contact you.</p>
                       <div><p>Name: '.$name.'</p><p>Mobile Number: '.$mobile.'</p> <p>Email: '.$email.'</p><p>Message: '.$message.'</p></div>
						<p style="font-weight: bold">
                       	Regards,</br>
                       	Team Bro-King
                       	</p>
					</div>';
		 $html = setEmailTemplate($content);  
		 
		 $html = setEmailTemplate($body);  
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From: <info@bro-king.com>' . "\r\n";
				$subject = "Bro-king Contact Form"
				mail('info@bro-king.com',$subject,$html,$headers,'bro-king');   
		
		
		
	}

	function test2(){
	   $content = '<div style="margin: 40px 20px 40px 20px">
                       <p>Hi *Subscriber Name*!</p>
                       <p>To verify your email, please click on the link below:</p>
                       <p>
                       	<a href="http://www.bro-king.com/verification">http://www.___________________________</a> 
                       </p>
                       <p style="font-weight: bold">
                       	Regards,</br>
                       	Team Bro-King
                       	
                       </p>

                       </div>';
	  
      $html = setEmailTemplate($content);     
		echo $html; 
	exit; 
	}
	
	function emailVerficationMail(){
			
			$userName = $this->input->post('subscriberName'); 
			$userid = $this->input->post('userid'); 
			$emailId = $this->input->post('emailId');
			$url = "http://52.25.167.123/broking/webServices/api/verifyUserEmail/$userid"; 
			
			
			if($emailId){
				$subject = "Bro-King: Email Verification"; 
				$body = ""; 
				$body .= '<div style="margin: 40px 20px 40px 20px">';
				$body .= "Hi ".ucwords($userName).",";
				$body .= "<p>To verify your email, please click on the link below.</p>";
				
				
				$body .= "<p><a href='".$url."'>Click here verify email </a> </p>";
				$body .= "<p> <b>Regards, <br> Team Bro-King </b></p>";
				$body .= "</div>"; 
				
				$html = setEmailTemplate($body);  
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From: <info@bro-king.com>' . "\r\n";
				mail($emailId,$subject,$html,$headers,'bro-king');
				$this->session->set_flashdata('msg','Mobile no is invalid');
				redirect(base_url()); 
			}
			exit;
	}
	
	
} 
/* End of file index.php */
/* Location: ./application/controllers/index.php */