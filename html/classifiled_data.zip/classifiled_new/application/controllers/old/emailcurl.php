<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Emailcurl extends CI_Controller{
	public function __construct(){
		 parent::__construct();	
		 $this->load->model('common_model');		 
	}
	
	
	function sendEmail(){
		$emailType = $this->input->post('type');
		$subscriberName = $this->input->post('subscriberName');
		$emailId = $this->input->post('emailId');
		$userid = $this->input->post('userid');
		$link = "";
		$otp = $this->input->post('opt');
		$emailData = array();
		$emailType = 'emailVerification';
		if($emailType == 'emailVerification'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '13','status'=>'1'));
			$url = "http://52.25.167.123/broking/webServices/api/verifyUserEmail/$userid";
			$link .= "<a href='".$url."'>Click here verify email</p>";
			 
		}
		
		if($emailType == 'forgetPassword'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '12','status'=>'1'));
		}
		
		if($emailType == 'registraion'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '14','status'=>'1'));
		}
		
		if($emailData){
			$subject = $emailData->subject;
			$body = $emailData->message;
			$body = str_replace('#NAME#',$subscriberName,$body);
			$body = str_replace('#OTP#',$otp,$body);
			$body = str_replace('#LINK#',$link,$body);
			$html = setEmailTemplate($body);  
			
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From:Bro-king <info@bro-king.com>' . "\r\n";
			@mail($emailId,$subject,$html,$headers,'bro-king');
			
		}
		exit; 
	} 
	
	function emailVerficationMail(){
			
			$userName = $this->input->post('subscriberName'); 
			$userid = $this->input->post('userid'); 
			$emailId = $this->input->post('emailId');
			$url = "http://52.25.167.123/broking/webServices/api/verifyUserEmail/$userid"; 
			
			if($emailId){
				$subject = "Bro-King: Email Verification"; 
				$body = ""; 
				$body .= '<div style="margin: 40px 20px 40px 20px">';
				$body .= "Hi ".ucwords($userName).",";
				$body .= "<p>To verify your email, please click on the link below.</p>";
				
				
				$body .= "<p><a href='".$url."'>Click here verify email </a> </p>";
				$body .= "<p> <b>Regards, <br> Team Bro-King </b></p>";
				$body .= "</div>"; 
				
				$html = setEmailTemplate($body);  
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From:Bro-king <info@bro-king.com>' . "\r\n";
				mail($emailId,$subject,$html,$headers,'bro-king');
			}
			
			exit;
	}
	
	
} 
/* End of file index.php */
/* Location: ./application/controllers/index.php */