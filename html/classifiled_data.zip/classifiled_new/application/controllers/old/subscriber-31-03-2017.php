<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Subscriber extends CI_Controller{
	public function __construct(){
		 parent::__construct();	
		 $this->load->model('common_model');	
		 $this->session->unset_userdata('verificationPOP');	 
	}
	
	function plan($mobile){
		$mobile = ($mobile) ? $mobile : $this->input->post('mobileNo'); 
		$data['plan']	=	$this->common_model->getResults('*','tbl_plan',$where,'','','','');
		if($this->input->post('mobileNo')){
			$data['content'] = 'plan';
			
			$param['mobileNo'] = $this->input->post('mobileNo'); 
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			
			$url = "http://52.25.167.123/broking/webServices/webapi/getSubcriberInfo"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$response = json_decode($server_output);
			 
			if($response->status == 'Success'){
				$data['user'] = $response->user; 
				$data['planId'] = $this->input->post('planId');;
				$this->load->view('Layout/home_layout', $data);	
			}
			else{
				$this->session->set_flashdata('msg','Mobile no is invalid');
				redirect(base_url()); 
			}
			
			
			
		}
		else{
			$this->session->set_flashdata('msg','Mobile no is invalid');
			redirect(base_url()); 
		}
		
	}
	
	function chkMobile(){
		
			$param['mobileNo'] = $this->input->post('mobileNo'); 
			$param['password'] = $this->input->post('password'); 
			
			
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			  
			$url = "http://52.25.167.123/broking/webServices/webapi/chkMobile"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			$data = json_decode($server_output);
			
			if($data->status == 'Success'){
				echo "Success";
			}
			else{
				echo "Fail";
			}
			exit;
		
	}
	
	
	function chkMobileUnique(){
		
			$param['mobileNo'] = $this->input->post('mobileNo'); 
			
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			  
			$url = "http://52.25.167.123/broking/webServices/webapi/chkMobileUnique"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			$data = json_decode($server_output);
			if($data->status == 'Success'){
				echo "Success";
			}
			else{
				echo "Fail";
			}
			exit;
		
	}
	
	
	
	
	
	function chkOTP(){
		
			$param['id'] = $this->session->userdata('subId');
			$param['otp'] = $this->input->post('otp'); 
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			  
			$url = "http://52.25.167.123/broking/webServices/webapi/chkOTP"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$data = json_decode($server_output);
			if($data->status == 'Success'){
				echo "Success";
			}
			else{
				echo "Fail";
			}
			exit;
		
	}
	
	
	function sumnitproperty(){
		
		
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|xss_clean');
		$this->form_validation->set_rules('name', 'name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('for', 'for', 'trim|required|xss_clean');
		$this->form_validation->set_rules('ptype', 'PpropertyType', 'trim|required|xss_clean');
		$this->form_validation->set_rules('city', 'PpropertyType', 'trim|required|xss_clean');
		$this->form_validation->set_rules('subType', 'subType', 'trim|required|xss_clean');
		
		
		
		if($this->form_validation->run() == TRUE){
			$captcha_info = $this->session->userdata('captcha_info');
			if (strtolower($captcha_info['code']) != strtolower($this->input->post('captchcode'))){
				$this->session->set_flashdata('msg','We will be contact with you soon to verification.');
					$this->session->set_flashdata('msg','Invalid Form Data');
					redirect('home/Invalid Code'); 
				exit;
				
			}
		
			
			
			
			$price = $this->input->post('price');
       	
       		if($this->input->post('priceTag') == 'Thousand'){
				$price  = $price * 1000;
			}
			if($this->input->post('priceTag') == 'Lakh'){
				$price  = $price * 100000;
			}
			if($this->input->post('priceTag') == 'Cr.'){
				$price  = $price * 10000000;
			}
			$location = implode(',',array_filter($this->input->post('locations')));
			$param['name'] = $this->input->post('name'); 
			$param['mobile'] = $this->input->post('mobile'); 
			$param['for'] = $this->input->post('for'); 
			$param['propertyType'] = $this->input->post('ptype'); 
			$param['city'] = $this->input->post('city'); 
			$param['subType'] = $this->input->post('subType'); 
			$param['locality'] = $location;  
			
			$project = $this->input->post('project');
			$param['project'] =  $project[0]; //$this->input->post('project');
			 
			$param['areaSize'] = $this->input->post('areaSize'); 
			$param['unit'] = $this->input->post('unit');
			if($this->input->post('priceTag') == $param['unit']){
				
				$param['priceRate'] = $price;
				$param['price'] = $price * $param['areaSize'];
				
				
			}
			else{
				$param['price'] = $price;
				$param['priceRate'] = ceil($price/$param['areaSize']);
			}
			
			$param['address'] = $this->input->post('remark'); 
			
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			
			$url = "http://52.25.167.123/broking/webServices/webapi/addProperty"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			$this->session->set_flashdata('msg','Thank you for registering your property with us!</br> Our team would contact you soon for verification.');
			redirect(base_url()); 
			exit;
		}
		
		else{
			$this->session->set_flashdata('msg','Invalid Form Data');
			redirect('home/index'); 
		 
		}
		
	}
	
	function sendEmail(){
		$emailType = $this->input->post('type');
		$subscriberName = $this->input->post('subscriberName');
		$emailId = $this->input->post('emailId');
		$userid = $this->input->post('userid');
		$link = "";
		$otp = $this->input->post('opt');
		$emailData = array();
		$emailType = 'emailVerification';
		if($emailType == 'emailVerification'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '13','status'=>'1'));
			$url = "http://52.25.167.123/broking/webServices/api/verifyUserEmail/$userid";
			$link .= "<a href='".$url."'>Click here verify email</p>";
			 
		}
		
		if($emailType == 'forgetPassword'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '12','status'=>'1'));
		}
		
		if($emailType == 'registraion'){
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '14','status'=>'1'));
		}
		
		if($emailData){
			$subject = $emailData->subject;
			$heading = $emailData->heading;
			$declaimer = $emailData->declaimer;
			$body = $emailData->message;
			$body = str_replace('#NAME#',$subscriberName,$body);
			$body = str_replace('#OTP#',$otp,$body);
			$body = str_replace('#LINK#',$link,$body);
			$html = setEmailTemplate($body,$heading,$declaimer);  
			
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From:Bro-king <info@bro-king.com>' . "\r\n";
			@mail($emailId,$subject,$html,$headers,'bro-king');
			
		}
		exit; 
	} 
	
	function emailVerficationMail(){
			
			$userName = $this->input->post('subscriberName'); 
			$userid = $this->input->post('userid'); 
			$emailId = $this->input->post('emailId');
			$url = "http://52.25.167.123/broking/webServices/api/verifyUserEmail/$userid"; 
			
			if($emailId){
				$subject = "Bro-King: Email Verification"; 
				$body = ""; 
				$body .= '<div style="margin: 40px 20px 40px 20px">';
				$body .= "Hi ".ucwords($userName).",";
				$body .= "<p>To verify your email, please click on the link below.</p>";
				
				
				$body .= "<p><a href='".$url."'>Click here verify email </a> </p>";
				$body .= "<p> <b>Regards, <br> Team Bro-King </b></p>";
				$body .= "</div>"; 
				
				$html = setEmailTemplate($body);  
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= 'From:Bro-king <info@bro-king.com>' . "\r\n";
				mail($emailId,$subject,$html,$headers,'bro-king');
			}
			
			exit;
	}
	
	
	function getProject(){
		  
			
			$param['ptype'] = $this->input->post('ptype'); 
			$param['city'] = $this->input->post('city'); 
			//$param['for'] = $this->input->post('for'); 
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
		
			$url = "http://52.25.167.123/broking/webServices/webapi/getProjectList"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			//echo $server_output; die();
			$projects = json_decode($server_output);
			
			$option = '';
			foreach($projects as $obj){
					$option .='<option value="'.$obj->id.'">'.$obj->projectName.'</option>';
			}
			echo $option;
			exit; 
		
	}
	
	function locality(){
		
			//$param['propertyType'] = $this->input->post('propertyType'); 
			$param['ptype'] = '1'; //$this->input->post('propertyType'); 
			
			$param['city'] = $this->input->post('city'); 
			$param['for'] = $this->input->post('for'); 
			
				
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
		
			$url = "http://52.25.167.123/broking/webServices/webapi/getLocalityList"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			$loclities = json_decode($server_output);
			
			//pr($loclities->locality); exit;
			
			$option = '';
			foreach($loclities->locality as $obj){
					$option .='<option value="'.$obj->id.'">'.$obj->locality.'</option>';
			}
			echo $option;
			exit; 
		
	}
	
	function getProjectLocality(){
		
			$project = $this->input->post('projectId'); 
			$param['projectId'] = $project[0]; 
			$param['propertyType'] = $this->input->post('ptype');
			$param['city'] = $this->input->post('city'); 
		
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
		
			$url = "http://52.25.167.123/broking/webServices/webapi/getProjectLocality"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$loclities = json_decode($server_output);
			$option = '';
			foreach($loclities->locality as $obj){
					$option .='<option selected="selected" value="'.$obj->Lid.'">'.$obj->localityName.'</option>';
			}
			echo $option;
			exit; 
		
	}

	function chkSubEmail(){
		
			$param['email'] = $this->input->post('email'); 
			$request = ""; 
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			
			$url = "http://52.25.167.123/broking/webServices/webapi/chkSubEmail"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$data = json_decode($server_output);
			
			
			if($data->status == 'Success'){
				echo "Success";
			}
			else{
				echo "Fail";
			}
			exit;
		
	}
	
	function regSubcriber(){
		
		$this->form_validation->set_rules('subName', 'name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|xss_clean');
		$this->form_validation->set_rules('password', 'password', 'trim|required|xss_clean');
		
		if($this->form_validation->run() == TRUE){
			
			$param['name'] = $this->input->post('subName'); 
			$param['mobile'] = $this->input->post('mobile'); 
			$param['email'] = $this->input->post('email'); 
			$param['password'] = $this->input->post('password'); 
			$param['company'] = $this->input->post('company'); 
			$param['website'] = $this->input->post('website'); 
			$param['city'] = $this->input->post('Scity'); 
			$param['refCode'] = $this->input->post('refCode'); 
			
			$request = '';
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			
			$url = "http://52.25.167.123/broking/webServices/webapi/signUp"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			
			$data = json_decode($server_output);
			
			
			
			if($data->status == 'Success'){
				$this->sendRegOtpEmail($param['name'],$param['email'],$data->regOtp);
				$this->session->set_userdata('subId',$data->userId);
				$this->session->set_userdata('verificationPOP','1');
				$this->session->set_userdata('mobile',$data->mobile);
				$this->session->set_userdata('regOtp',$data->regOtp);
				redirect(base_url()); 
			}
			else{
				echo "Fail";
			}
			
			
		}
		
		exit; 	
	}
	
	function closeVerificationPOP(){
		$this->session->unset_userdata('verificationPOP');
		$this->session->unset_userdata('mobile');
		$this->session->unset_userdata('subId');
		echo "Success";
	 
	}
	
    function sendRegOtpEmail($subName=NULL,$email=NULL,$otp=NULL){
			if($this->input->post('otp')){
				$subName = $this->input->post('subName'); 
				$email = $this->input->post('email'); 
				$otp = $this->input->post('otp');
				
			}
			
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '14','status'=>'1'));			
			
			if($emailData){
				$subject = $emailData->subject;
				$body = $emailData->message;
				$body = str_replace('#NAME#',$subName,$body);
				$body = str_replace('#OTP#',$otp,$body);
				$html = setEmailTemplate($body);  
				$this->sendMail($email,$subject,$html);
			}
			
			
		
    }
    
	function sendForgetPasswordEmail(){
			$req_dump = print_r($_REQUEST, TRUE);
			$fp = fopen('request.log', 'a');
			fwrite($fp, $req_dump);
			fclose($fp);
			
			if($this->input->post('otp')){
				$subName = $this->input->post('subName'); 
				$email = $this->input->post('email'); 
				$otp = $this->input->post('otp');
				
			}
			
			$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '12','status'=>'1'));			
			
			if($emailData){
				$subject = $emailData->subject;
				
				$body = $emailData->message;
				$body = str_replace('#NAME#',$subName,$body);
				$body = str_replace('#OTP#',$otp,$body);
				
				$html = setEmailTemplate($body);  
				$this->sendMail($email,$subject,$html);
			}
    }
    
	
  	function verifyOTP(){
			$param['id'] = $this->session->userdata('subId');
			$param['otp'] = $this->input->post('otp'); 
			
			foreach($param as $key=>$val) { 
				$request.= $key."=".urlencode($val); 
				$request.= "&"; 
			} 
			
			$url = "http://52.25.167.123/broking/webServices/webapi/verifyOTP"; 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$data = json_decode($server_output);
			
			if($data->status == 'Success'){
				$this->session->unset_userdata('subId');
				$this->session->set_flashdata('verificationPOP','2');
				$this->session->set_flashdata('msg','Congratulations! You are now registered with us. You can now log in on the app using the same account.');
				redirect(base_url()); 
				exit;
			}
			else{
				echo "Fail";
			}
			exit;
		
	}
	
	
	function payment($orderId){
		$orderId = base64_decode($orderId) ; 
		$plan = $this->common_model->getSingle('tbl_transaction',array('orderId' => $orderId)); 
		
		
		
		if($plan->status == "TXN_FAILURE"){
			$this->session->set_flashdata('msg','Sorry! Your payment failed.');
			redirect(base_url()); 
			exit;
		}
		

		if($plan->plan == 'ANNUAL'){
			$prop_view_limit = "3600";
			$month = 12; 
		}

		if($plan->plan == 'HALF YEARLY'){
			$prop_view_limit = "1800";
			$month = 6; 
		}

		if($plan->plan == 'QUARTERLY'){
			$prop_view_limit = "900";
			$month = 3; 
		}
		
			/*
			$param['month'] = $month;
			$param['amount'] = $plan->amount;
			$param['prop_view_limit'] = $prop_view_limit; 
		
		
		*/
		
		$param['subscriber_id'] = $plan->subscriber_id; 
		$param['plan'] = $plan->plan;
		$param['month'] = $plan->month;
		$param['amount'] = $plan->amount;
		$param['totalLimitView'] = $plan->listing;
		$param['planId'] = $plan->plan_id;
		
		
		$request = '';
		foreach($param as $key=>$val) { 
			$request.= $key."=".urlencode($val); 
			$request.= "&"; 
		} 
		
		$url = "http://52.25.167.123/broking/webServices/webapiTest/payment"; 
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		//pr($server_output); exit; 
		$data = json_decode($server_output);
		
		
		
			
		if($data->status == 'Success'){
			$this->session->set_flashdata('msg','Payment Successful! Your plan is now active. You would get a confirmation message on your registered mobile number.');
			redirect(base_url()); 
			
			
		}
		else{
			$this->session->set_flashdata('msg','Payment Fail! Your payment is failed.');
			redirect(base_url()); 
			
		}
		exit;
	
		
	}
	
	function test(){
				
				$emailData = $this->common_model->getSingle('tbl_email_notification',array('id'=> '14','status'=>'1'));
				pr($emailData); 
				$subject = $emailData->subject;
				$body = $emailData->message;
				$body = str_replace('#NAME#',$subscriberName,$body);
				$body = str_replace('#OTP#',$otp,$body);
				$body = str_replace('#LINK#',$link,$body);
				echo $html = setEmailTemplate($body);  
				
				 $config = Array(       
		            'protocol' => 'sendmail',
		            'smtp_host' => 'smtp.office365.com',
		            'smtp_port' => 587,
		            'smtp_user' => 'info@bro-king.com',
		            'smtp_pass' => 'Alohomora@71',
		            'smtp_timeout' => '4',
		            'mailtype'  => 'html',
		            'charset'   => 'utf-8',//'iso-8859-1'
					'newline'    => "\r\n",
					'validation' => true
				);
        		$this->load->library('email', $config);
    			//$this->email->set_newline("\r\n");
    			$this->email->from('info@bro-king.com', 'Bro-king');
    			$this->email->to('info@bro-king.com,dfordharma@gmail.com');  // replace it with receiver mail id
    			$this->email->subject($subject); // replace it with relevant subject
   				$this->email->message($html);  
        		$this->email->send();
				
				exit; 
		
	}
   
   	function sendMail($to,$subject,$html){
			
			$config = Array(       
				'protocol' => 'sendmail',
				'smtp_host' => 'smtp.office365.com',
				'smtp_port' => 587,
				'smtp_user' => 'info@bro-king.com',
				'smtp_pass' => 'Alohomora@71',
				'smtp_timeout' => '4',
				'mailtype'  => 'html',
				'charset'   => 'utf-8',//'iso-8859-1'
				'newline'    => "\r\n",
				'validation' => true
			);

			$this->load->library('email', $config);
			//$this->email->set_newline("\r\n");
			$this->email->from('info@bro-king.com', 'Bro-king');
			$this->email->to($to);  // replace it with receiver mail id
			$this->email->subject($subject); // replace it with relevant subject
			$this->email->message($html);  
			$this->email->send();
		
		
	}
	
	
	function reSendRegOTP(){
		
		if($this->input->post()){
			
			$subId 	= $this->input->post('subId');
			$id 	= $this->session->userdata('subId');
			
			if($subId == $id){
				
				$mobile = $this->session->userdata('mobile');
				$otp 	= $this->session->userdata('regOtp');
				
				$request =""; 
				$param['username'] = "t1prithvi"; 
				$param['password'] = "66284730"; 
				$param['sender'] = "BROKNG"; 
				$param['sendto'] =  (strlen($mobile) == 10 ) ? '+91'.$mobile : $mobile ; 
				$param['message'] = "Your Bro-King verification code is $opt. Fill in the same and complete your sign-up process. Happy Bro-King!";			

				foreach($param as $key=>$val) { 
					$request.= $key."=".urlencode($val); 
					$request.= "&"; 
				} 

				$request = substr($request, 0, strlen($request)-1);
				$url = "http://nimbusit.co.in/api/swsendSingle.asp?".$request; 
				$ch = curl_init($url); 
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
				$curl_scraped_page = curl_exec($ch); 
				curl_close($ch);
				echo "success";
			 	//$curl_scraped_page;
			}
		}
		
	}	
	
   	
} 


/* End of file index.php */
/* Location: ./application/controllers/index.php */