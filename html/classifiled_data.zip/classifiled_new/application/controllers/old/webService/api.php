<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Api extends CI_Controller {

    public $success = array();
    public $failed = array();
    
    

    public function __construct() {
        parent::__construct();
        $this->load->model('webServices/apiModel', 'Api', TRUE);
        $this->success = array(
            "responseCode" => "200"
        );
        $this->failed = array(
            "responseCode" => "0"
        );
    }
?>    
    