<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mobileapp extends CI_Controller {

	public function __construct() {
		 parent:: __construct();		 
		 $this->load->model('Common_model');

	}
	
	
	public function page($slag){
		
		$displayPage = $this->Common_model->getSingle('tbl_pages',array('slug'=>$slag,'status'=>'Active'));

			if($displayPage){	

				$data['page_content'] = $displayPage;
				$data['content'] = 'mobile-page';
				$this->load->view('Layout/mobile_layout', $data);	

			}
			else{

				$data['content'] = '';

				$this->load->view('Layout/home_layout', $data);			

			}		
	}

}

?>