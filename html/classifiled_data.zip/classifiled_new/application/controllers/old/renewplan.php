<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Renewplan extends CI_Controller{
	public function __construct(){
		 parent::__construct();	
		 $this->load->model('common_model');		 
	} 
	
	public function index(){	
		
		$data['content'] = 'renew';
		$data['home'] = '1';
		$data['plan']	=	$this->common_model->getResults('*','tbl_plan',$where,'','','','');
		$this->load->library('captcha');
		$data['captcha'] = $this->captcha->main();
		$this->load->view('Layout/home_layout', $data);		
		
		//$this->load->view('comingsoon', $data);		
	}
	
	
	
} 
/* End of file index.php */
/* Location: ./application/controllers/index.php */