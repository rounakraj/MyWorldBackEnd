<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Webservices extends CI_Controller {

    public $success = array();
    public $failed = array();

     function __construct() {
        parent::__construct();
     }
    
	function index(){
		header("Content-type:application/json");
        $action = $this->input->post('method');
        
        if( isset($action) && !empty($action) && method_exists($this,$action)){
			unset($action);
            $response = $this-> $action();
        }
        else{
            $response['status']     = "Fail";
            $response['message']    = "Invalid method";
        } 
		echo json_encode($response); exit; 
	}


	function singup(){
		if($this->request->post()){
			if($this->input->post('email') && $this->input->post('mobile') && $this->input->post('name') ){
				if($this->input->post('user_type')){
					$new_user = $this->input->post();
					$user_id = $this->common_model->insertValue($new_user,'tbl_users');
					if($user_id){
						$response['data'] = $new_user; 
						$response['data']['user_id'] = $user_id;
						$response['status'] = "success";	
						$response['message'] = "Sing-up new user";	
					}
					else{
						$response['status'] = "Fail";
						$response['message'] = "Server Error.";
					}
				}
				else{
					$response['status'] = "Fail";
					$response['message'] = "User type is required.";
				}
			}
			else{
				$response['status'] = "Fail";
				$response['message'] = "Invalid Post Data";
			}
			
		}
		else{
			$response['status'] = "Fail";
			$response['status'] = "Invalid Post Data";
		}
		return $response;
	}	
    
	function change_password(){
		if($this->input->post() && $this->input->post('user_id')){
			$where['id'] = $this->input->post('user_id'); 
			$isvalid = $this->common_model->getCount('tbl_users',$where);
			
			if($isvalid){
				$this->load->library('encrypt');
				$user['password'] = $this->encrypt->encode($this->input->post('password'));
				$where['id'] = $this->input->post('user_id'); 
				$isupdate = $this->common_model->updateValue($user,'tbl_users',$where); 
				if($isupdate){
					$response['data'] = array();
					$response['status'] = "Success";
					$response['message'] = "Password has been changed successfully.";
				}
				else{
					$response['status'] = "Fail";
					$response['message'] = "Server Error." ;
				}
			}
			else{
				$response['status'] = 'Fail';
				$response['message'] = 'Invalid user_id';
			}
		}
		else{
			$response['status'] = "Fail";
			$response['message'] = "Invalid Post Data";
		}
		return $response;
	}
	
	function forget_password(){
		if($this->input->post() && $this->input->post('email')){
			$email =  $this->input->post('email');
			$where = '(email="'.$email.'" or mobile = "'.$email.'")'; 
			$isvalid = $this->common_model->getCount('tbl_users',$where);
			if($isvalid){
				$response['status'] = "success";
				$response['message'] = "password has been send on your mail/contact.";
			}
			else{
				$response['status'] = "Fail";
				$response['message'] = "invalid credential";
			}
		}
		else{
			$response['status'] = "Fail";
			$response['message'] = "Invalid post data";
		}
		return $response;
	}
	
	function change_profile_pic(){
		if($this->input->post() && $this->input->post('user_id')){
			$where['id'] = $this->input->post('user_id'); 
			$isvalid = $this->common_model->getCount('tbl_users',$where);
			
			if($isvalid){
				$this->load->library('encrypt');
				$user['password'] = $this->encrypt->encode($this->input->post('password'));
				
				
				
				$where['id'] = $this->input->post('user_id'); 
				$isupdate = $this->common_model->updateValue($user,'tbl_users',$where); 
				if($isupdate){
					$response['data'] = array();
					$response['status'] = "Success";
					$response['message'] = "Password has been changed successfully.";
				}
				else{
					$response['status'] = "Fail";
					$response['message'] = "Server Error." ;
				}
			}
			else{
				$response['status'] = 'Fail';
				$response['message'] = 'Invalid user_id';
			}
		}
		else{
			$response['status'] = "Fail";
			$response['message'] = "Invalid Post Data";
		}
		return $response;
	}
	
	
	private function notificationList(){
		 		
		 		$userId = $this->input->post('userId');
		 		$notificationlist = $this->Api->getAllNotification($userId);
		 		$i = 0;
		 
		 		
		 		foreach($notificationlist as $obj){
					
					$notification[$i]['notificationId'] = $obj->notificationId;
					$notification[$i]['title'] = $obj->title;
					$notification[$i]['dtails'] = $obj->content;
					$notification[$i]['short_dtails'] = substr(strip_tags($obj->content),0,100);
					$notification[$i]['date'] = date('d M Y',$obj->notificationDate);
					$notification[$i]['satus'] = $obj->status;
					$notification[$i]['image'] = base_url()."uploaded/blogImages/".$obj->image;
					$notification[$i]['media'] = base_url()."uploaded/blogImages/".$obj->media;
					$notification[$i]['mediaposition'] = "top";
                    
					$i++;	
				}
		 		
		 		
		 
		 		/*
		 
                $notification[0]['title'] = "Where can I get some";
                $notification[0]['image'] = "http://52.25.167.123/broking/uploaded/blogImages/image2.jpg";
                $notification[0]['dtails'] = "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.";
                $notification[0]['date'] = "2 days ago";
                $notification[0]['status'] = "0";
                $notification[0]['notificationId'] = '13';    
            
            
                $notification[1]['title'] = "Lorem Ipsum";
                $notification[1]['image'] = "http://52.25.167.123/broking/uploaded/blogImages/images.jpeg";
                $notification[1]['dtails'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
                $notification[1]['date'] = "3 days ago";
                $notification[1]['status'] = "0";      
                $notification[1]['notificationId'] = '12';  
         
         
                $notification[2]['title'] = "The standard Lorem Ipsum passage, used since the 1500s";
                $notification[2]['image'] = "http://52.25.167.123/broking/uploaded/blogImages/image2.jpg";
                $notification[2]['dtails'] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
                $notification[2]['date'] = "3 days ago";
                $notification[2]['status'] = "1";     
                $notification[2]['notificationId'] = '11';  
                
                $response['status']     = "Success";
                $response['date']     = date('d M Y H:i:s');
                $response['notification']    = $notification;
                    
               
                $notification[2]['title'] = "The standard Lorem Ipsum passage, used since the 1500s";
                $notification[2]['image'] = "http://52.25.167.123/broking/uploaded/blogImages/image2.jpg";
                $notification[2]['content'] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
                $notification[2]['date'] = date('Y-m-d H:i:s');
         
                /*       
         
               $this->db->insert('sb_tbl_blogs', $notification[2]);
                */ 
		
         	   $response['status']     = "Success";
               $response['date']     = date('d M Y H:i:s');
               $response['notification']    = $notification;	
               return $response; 
        
        
    }
     
    private function readNotification(){
         
        if($this->input->post('notificationId') && $this->input->post('userId') ){
			
			$where = array('id' => $this->input->post('notificationId'));
			$row['status'] = '1'; 
			$result =$this->common_model->updateValue($row,'sb_tbl_blogs',$where);
		    $response['status']     = "Success";
        
        }
        else {
            $response['status']     = "Fail";
            $response['msg']     = "notificationId and userId are required";
        }
         
        return  $response;
     }
    
    private function deleteNotification(){
         
         if($this->input->post('userId') &&  $this->input->post('notificationId')){
			
			$cond['id'] =  $this->input->post('notificationId');
			$this->common_model->deleteData('sb_notifications',$cond);
			$response['status']     = "Success";
             
         }
         else {
            $response['status']     = "Fail";
            $response['msg']    	= "notificationId and userId are required";
        }
         
        return  $response;
         
     }   
    
    public function test($deviceToken=null){
       
        $users =  $this->Api->getUserById(152);
      
		 $message = "Hi this is testing for other project.";
		 $body['message'] =  "Hi Blog message..";
		 $body['type'] = 'normal';
		 $body['title'] = "The standard Lorem Ipsum passage, used since the 1500s";
		 $body['details'] = "The standard Lorem Ipsum passage, used since the 1500s";
		 $body['image'] = "http://52.25.167.123/broking/uploaded/blogImages/image2.jpg";
		 $body['badge'] = "2";
        
         $deviceToken =  $users['regId']; 
		 //$deviceToken = "27d533470fecf4cfe2d395df3ebf9a090ac672d810e74d8d7a05cc25273ae9bd"; 	
		
		 $response =  iosPushNotification($deviceToken,$body);
		
        return  $response;
	
	}
	
	function tetAndroid(){
		
		$message = ($this->input->post('message')) ? $this->input->post('message') : "Hi, This is test. message";
		
		$deviceToken = ($this->input->post('deviceToken')) ? $this->input->post('deviceToken') : "cSTAhDl0UCU:APA91bExiud6uS7xSE1mcvO7Pa2okoZbjQOdf11FVV3QeV6FW1cwNBIgDDKenWsyWBEl3emwqSfBGiqsDMnsmJKQ4p8gys12zCNZcrLWwCLv_LB8k3qmL-aFCoX15pbpApHg51KKsLP1";
		
		$fields = array(
            'to' => $deviceToken,
            'notification' => array('title' => 'Bro-king', 'body' => 'The standard Lorem Ipsum passage, used since the 1500s'),
            'data' => array(
				'message' => $message,
				'type' => 'type',
				'title' => "The standard Lorem Ipsum passage, used since the 1500s",
				'details' => "The standard Lorem Ipsum passage, used since the 1500s",
				'blogId' => '5',
				'NotificationId' => '23',	
				'image' => "http://52.25.167.123/broking/uploaded/blogImages/image2.jpg",
				'badge' => "2",
			)
        );
		
		$response['serverResponse'] =  sendPushNotificationToGCMSever($fields);
		$response['fields'] = $fields;
	
		return $response; 
	
	}
    
	function createPost(){
		
		if($this->input-post('category_name') && $this->input->post('title') ){
			$where = array('name' => $this->input-post('category_name')); 
			$category = $this->common_model->getSingleRow('id','tbl_category',$where); 
			if($category) {
				
				$post['title'] = $this->input->post('name');
				$post['category_name'] = $this->input->post('category_name');
				$post['category_id'] = $category['id']; 
				$post['title'] = $this->input->post('title');
				$post['description'] = $this->input->post('description');
				$post['contact'] = $this->input->post('contact');
				$post['address'] = $this->input->post('address');
				
				$post_id = $this->common_model->insertValue('tbl_post',$post);
				$response['status'] = 'Success';
				$response['messagee'] = 'Post has been successfully create';
			}
			else{
				$response['status'] = 'Fail';
				$response['message'] = 'invalid category.';
			}
			
		}
		else{
			$response['status'] = "Fail";
			$response['message'] = "category_name is required.";
		}
	}

}
