<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	

	function pr($var){ 

		echo "<pre>";

		print_r($var);

		echo "</pre>";

	}



	function activeTemplate(){

		return 'admin-html';

	}



	function setPaginationConfig($base_url,$total_rows,$c_page,$per_page=15){

		$config['base_url'] = $base_url;

		$config['total_rows'] = $total_rows;

		$page = ($c_page) ? $c_page : 0;

		$config['per_page'] = $per_page;

		$config['num_tag_open'] = '<li>';

		$config['num_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li><a>';

		$config['cur_tag_close'] = '</a></li>';

		$config['cur_page'] = $c_page;

		$config['last_tag_open'] = '<li>';

		$config['last_tag_close'] = '</li>';

		$config['next_tag_open'] = '<li>';

		$config['next_tag_close'] = '</li>';

		$config['prev_tag_open'] = '<li>';

		$config['prev_tag_close'] = '</li>';

		$config['first_tag_open'] = '<li>';

		$config['first_tag_close'] = '</li>';

		$config['first_link'] = '<<';

		$config['last_link'] = '>>';

		$config['cur_tag_open'] = '<li> <a class="pagiCurrent" >';

		$config['cur_tag_close'] = '</a></li>';

		return $config;

	}



	function searchkey(){

		return $key = array ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');

	}



function setEmailTemplate($msg,$heading='BRANDING',$desclimer=NULL){

$message_header= '<!doctype html><html><head><meta charset="utf-8"><title>Untitled Document</title></head><body style="margin:0;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td height="20" bgcolor="#FDB813"></td></tr><tr><td bgcolor="#000" style="padding:3px 0;"><table width="610" border="0" cellspacing="0" cellpadding="0" align="center" class="main">
<tbody><tr><td width="5"></td><td><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td class="hide2" style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:12px; line-height:22px; color:#ffffff;">
<a href="#" style="color:rgb(255,255,255);text-decoration:none" target="_blank">Email not displaying correctly? View in your browser</a></td><td width="20"></td><td align="right" width="173" class="social"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td><a href="https://www.facebook.com/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/fb.png" alt="facebook" border="0"></a></td>
<td><a href="https://twitter.com/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/twitter.png" alt="twitter" border="0"></a></td>
<td><a href="https://plus.google.com/u/0/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/google-plus.png" alt="google" border="0"></a></td>
<td><a href="http://in.linkedin.com/in/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/linked-in.png" alt="youtube" border="0"></a></td>
</tr></tbody></table></td></tr></tbody></table></td><td width="5"></td></tr></tbody></table></td></tr><tr><td height="10" bgcolor="#FDB813"></td></tr><tr bgcolor="#eeeeee">
<td bgcolor="#eee"><table width="610" border="0" cellspacing="0" cellpadding="0" align="center" class="main"><tbody><tr><td width="5"></td><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody bgcolor="#000"><tr><td height="10"></td></tr><tr><td align="center"><a href="#" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/logo.png" width="140" height="" alt="logo" border="0"></a></td>
</tr><tr><td height="10"></td></tr><tr><td valign="top" style="background:#f1c40f; min-height:150px; text-align: center;">
<div style="background:url(http://bro-king.com/website/html/mailer/images/building.png) no-repeat right top;   background-size:cover; padding:38px 100px;">
<span style="font-size:38px; font-family:arial; color:#000; display: block;">'.$heading.'</span>
<span style="color:#fff; text-shadow:1px 1px 2px #000; font-family:arial;font-size: 17px; display: none;">We specialize in producing thoughtful web products that meet your requirements. Our interfaces are agile and adaptive, building meaningful connections between brand and audience</span>
</div></td></tr></tbody></table></td> <td width="5"></td></tr></tbody></table></td></tr><tr><td valign="top"><table width="610" border="0" cellspacing="0" cellpadding="0" align="center" class="main">
<tbody><tr><td width="5"></td><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td bgcolor="#ffffff" valign="top" style="border: 1px solid #ddd; border-radius: 0 0 4px 4px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td width="20"></td><td><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td height="18"></td></tr><tr><td style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:20px; line-height:26px; color:#FDB813; text-align:center;"><span style="color:#FDB813; margin-bottom: 30px; display: block; text-decoration:none;">WHERE <strong>CREATIVITY</strong> MEETS YOUR DEMAND</span></td></tr>';

	//$desclimer = "In today's information age of Marketting and Web 2.0, a company's website is the key to their entire business In today's information age of Marketting and Web 2.0, a company's website is the key to their entire business In today's information age of Marketting and Web 2.0, a company's website is the key to their entire business";
	
	
$message_footer='<tr><td height="16"></td></tr><tr><td align="left" style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:14px;  width:50px; height:50px; background-position: center; color:#313440;">Thanks and Regards,<br>Team Bro-King </td>
</tr><tr><td height="20"></td></tr> </tbody></table></td> <td width="20"></td></tr></tbody></table></td></tr><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody></tbody></table></td></tr></tbody></table></td></tr><tr><td height="25"></td></tr><tr><td valign="bottom"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td bgcolor="#FFFFFF" style="border:1px solid #ddd; border-bottom:0; border-radius: 4px 4px 0 0;" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td height="12"></td></tr><tr><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td width="20"></td><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:12px; line-height:26px; color:#FDB813; text-align:left;"><a href="#" target="_blank" style="color:#FDB813; text-decoration:none;"><strong>Disclaimer :-</strong></a></td>
</tr><tr><td align="left" style="text-decoration:none; font-family:arial;color:#626363; font-size:12px;">Place the spotlight on your brand and be seen where it matters most. Get to the first page of search engine and enjoy more leads, more sales and an online presence that sparks crucial brand awareness. Place the spotlight on your brand and be seen where it matters most. Get to the first page of search engine and enjoy more leads, more sales and an online presence that sparks crucial brand awareness Get to the first page of search engine.</td>
</tr></tbody></table></td><td width="20"></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td><td width="5"></td></tr>
</tbody></table></td></tr><tr><td bgcolor="#000"><table width="610" border="0" cellspacing="0" cellpadding="0" align="center" class="main"><tbody><tr><td width="5"></td><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td bgcolor="#FFFFFF" style="" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr style="background-color: #fff;padding: 0;"><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr style="padding: 0px 20px 15px;display: block;"><td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody><tr><td valign="top" class="box1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr><td style="font-family:arial;font-size: 12px;text-align: left;color: #626363;">'.$desclimer.'</td>
</tr></tbody></table></td><td valign="top" class="box3"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tbody></tbody></table></td></tr></tbody></table></td>
</tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr><tr><td style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:13px; line-height:22px; color:#ffffff; text-align:center; padding-top:8px;"> &copy;  2017 JAPRI TECH PRIVATE LIMITED.  ALL RIGHTS RESERVED.</td>
</tr><tr><td height="15"></td></tr><tr><td><table width="" border="0" cellspacing="0" cellpadding="0" align="center"><tbody><tr><td style="float:left; margin-right: 5px;"><a href="https://www.facebook.com/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/fb.png" width="39" height="40" alt="facebook" border="0"></a></td>
<td style="float:left;margin-right: 5px;"><a href="https://twitter.com/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/twitter.png" width="39" height="40" alt="twitter" border="0"></a></td>
<td style="float:left;margin-right: 5px;"><a href="https://plus.google.com/u/0/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/google-plus.png" width="39" height="40" alt="google" border="0"></a></td>
<td style="display:flex;"><a href="http://in.linkedin.com/" target="_blank"><img style="display:block;" src="http://bro-king.com/website/html/mailer/images/linked-in.png" width="39" height="40" alt="youtube" border="0"></a></td>
</tr></tbody></table></td></tr><tr><td height="20"></td></tr></tbody></table></td> <td width="5"></td></tr></tbody></table></td></tr></tbody></table></body></html>';
	
	  $content = '<tr>
     	<td style="font-family:Arial, Helvetica, sans-serif, Trebuchet MS; font-size:13px; line-height:22px; color:#313440; text-align:left; padding-top:4px; text-indent: 30px;">'.$msg.'</td></tr>'; 
                                  	
		
		
	$message = $message_header.$content.$message_footer;
	
	return $message; 


}

	
	function setEmailTemplateOLd($msg){

		$message_header= '<html>
	<head>
		<title> </title>		
	</head>
	<body style="font-family: Open Sans,sans-serif">
		
<table id="bgtable" align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
    <tr>
        <td align="center" valign="top">
            <!-- container 600px -->
            <table border="0" cellpadding="0" cellspacing="0" class="container" width="100%" style="...">
                <tr>
                    <td align="left" style="background-color: #000; margin:5px; "  >
                        <img src="http://www.bro-king.com/website/html/images/logo@2x.png" style="margin: 10px;"/>
                    </td>
                </tr>
                <tr>
                    <td align="left" style="background-color: #EDEDED" ><div style="margin: 20px 20px 20px 20px">';

	$message_footer='</div></td>
                </tr>
                <tr>
                    <td style="background-color:#EFC70B" background="http://www.bro-king.com/website/html/images/emailfoter.png" height="140">
                    <div class="address">
					
                        
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
	</body>
</html>';

	$message = $message_header.$msg.$message_footer;
	return $message; 


	}



	function pdfHeader(){

		$message_header= '<table width="740" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #ccc;">

		<tr>

		    <td align="left" valign="top"><img src="'.base_url().'admin-html/images/newsLetterHdr.jpg" width="740" height="110" alt=""></td>

	  	</tr>

	  	<tr><td valign="top" align="left" style="padding:65px 30px 60px; color:#646464; font:15px/20px proxima_nova_rgregular;"><?tr></table>';

		return 	$message_header;

	}



	function getEmailNotification(){

		$CI =& get_instance();

		return $notification = $CI->common_model->getResults('*','rbd_email_notification');

	}



	function getHeaderMenu(){

		$CI =& get_instance();

		return $menu = $CI->common_model->getHeaderMenu();

	}



	function getFooterMenu(){

		$CI =& get_instance();

		return $menu = $CI->common_model->getFooterMenu();

	}



	function getAllMenu(){

		$CI =& get_instance();

		$where = array('status' => '1');

		return $menu = $CI->common_model->getResults('page_title,slug','tbl_pages',$where);

	}

	

	function getSocialMedia(){

		$CI =& get_instance();

		$where = array('status' => '1');

		return $menu = $CI->common_model->getResults('social_media,link,image','tbl_social_meida_link',$where,'rank','ASC');

	}



	function dateDiffTime($date2=null,$date1=null){

		$diff = abs(strtotime($date2) - strtotime($date1)); 

		$years   = floor($diff / (365*60*60*24)); 

		$months  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 

		$days    = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

		$hours   = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60)); 

		$minuts  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 

		$seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60)); 

		//printf("%d years, %d months, %d days, %d hours, %d minuts\n, %d seconds\n", $years, $months, $days, $hours, $minuts, $seconds);

		$str = '';

		if($years > 0){

			$str = $years.'Years ,';

		}

	

		if($months > 0){

			$str .= $years.'Months';

		}

	

		if($days > 0){

			$str .= $days.'days';

		}



		if($hours > 0){

			$str .= $hours.'hours,';

		}

	

		if($minuts > 0){

			$str .= $minuts.'minuts,';

		}

		if($seconds > 0){

			$str .= $seconds.'seconds,';

		}

		return $str;

	}





	function displayDate($date=null,$formate='Y-m-d'){

		date_default_timezone_set('Asia/Singapore');

		if($date){

		 	$strtime = strtotime($date);

			 return date($formate,$strtime);

		}else{

			return date($formate);

		}

	}





	function getMetaData($table){

		$CI =& get_instance();

		return $CI->common_model->getSingleRow('*',$table);

	}



	function getHomePageVidoId(){

		$CI =& get_instance();

		$link =  $CI->common_model->getValue('tbl_youtube','link',array('id'=> 1)); 

		//echo $CI->db->last_query();exit;

		return get_youtube_videos($link);

	}

	function getSiteSetting(){
		$CI =& get_instance();
		return $notification = $CI->common_model->getSingleRow('*','tbl_site_info');
	}



	function get_youtube_videos($string) {

	  	$url = $string;

		parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );

		return $my_array_of_vars['v']; 

	}



	function checkCookies(){

		$CI =& get_instance();

		$CI->load->helper('cookie');

		//print_r($_COOKIE);exit;

		$ip = $_SERVER["REMOTE_ADDR"];

		//$user_id = $_COOKIE['user_id'];

		$registeredUser =  $CI->common_model->getSingle('tbl_user',array('ip'=>$ip,'status'=>'1','is_deleted'=>'0'));

		//echo $CI->db->last_query();exit;

		return $registeredUser; 

	}

	

	/*function imgResize($inFile, $outFile="", $width=100, $height=100){

		$CI =& get_instance();

		$config['image_library'] = 'gd2';

		$config['source_image'] = $inFile;

		$config['new_image'] = $outFile;

		$config['thumb_marker'] = '';

		$config['create_thumb'] = TRUE;

		$config['maintain_ratio'] = FALSE;

		$config['width'] = $width;

		$config['height'] = $height;

		$CI->image_lib->initialize($config);	

		$CI->image_lib->resize();		  

    }*/

	

	function imgResize($inFile, $outFile="", $width=100, $height=100){

		$CI =& get_instance();

		$config['image_library'] = 'gd2';

		$config['source_image'] = $inFile;

		$config['new_image'] = $outFile;

		$config['thumb_marker'] = '';

		$config['create_thumb'] = TRUE;

		$config['maintain_ratio'] = TRUE;

		$config['width'] = $width;

		$config['height'] = $height;

		$CI->image_lib->initialize($config);

		$CI->image_lib->resize();		

    }

	

	function imgResize2($inFile, $outFile="", $width=100, $height=100){

		$CI =& get_instance();

		$config['image_library'] = 'gd2';

		$config['source_image'] = $inFile;

		$config['new_image'] = $outFile;

		$config['thumb_marker'] = '';

		$config['create_thumb'] = TRUE;

		$config['maintain_ratio'] = FALSE;

		$config['width'] = $width;

		$config['height'] = $height;

		$CI->image_lib->initialize($config);

		$CI->image_lib->resize();

		

    }

	

	function randomPasword($length){

		$smallAlphabets = range('a','z');

		$capsAlphabets = range('A','Z');

		$numbers = range('1','9');

		$additional_characters = array('_','-');

		$final_array = array_merge($smallAlphabets,$numbers,$additional_characters,$capsAlphabets);

		$password = '';

		while($length--) {

		  $key = array_rand($final_array);

		  $password .= $final_array[$key];

		}

		return $password;

	}

	

	function create_unique_slug($string, $table)

	{		

		$CI =& get_instance();

		$slug = url_title($string);

		$slug = strtolower($slug);

		$i = 0;

		$params = array ();

		$params['slug'] = $slug;

		while ($CI->db->where($params)->get($table)->num_rows()) {

			if (!preg_match ('/-{1}[0-9]+$/', $slug )) {

				$slug .= '-' . ++$i;

			} else {

				$slug = preg_replace ('/[0-9]+$/', ++$i, $slug );

			}

			$params ['slug'] = $slug;

			}

		return $slug;

	}  	