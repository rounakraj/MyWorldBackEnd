<?php
class Database {
	
	private $conn   = "";
	
	private $_pre      = "";
	private $_link_id = 0;
	
	public $last_query ;
	public $record = array();
	public $error = "";
	public $errno = 0;
	
	public $field_table= "";
	public $affected_rows = 0;
	public $query_id = 0;
	public $databse = '';
	
	public $type = 'object';

	function __construct(){
		//$this->conn = mysql_connect(HOST,USER,PASSWORD);
		//$this->databse = mysql_select_db(DATABASE,$this->conn);
	}
	function deleteRow($tbl,$where){
		$query = "DELETE FROM ".$tbl;
		if($where)
			$query .= " WHERE ".$where;
		$this->last_query = $query ;
		if(mysql_query($$query))
			return TRUE;
		else
			return FALSE;
				
	}
	
function countData($tbl,$filed = '*',$where = NULL ,$order = NULL , $limit = NULL ){
		$sql = "SElECT " .$filed . " FROM ".$tbl ." WHERE 1 = 1";
		
		if(isset($where) && $where != NULL){
			$sql .= " AND ". $where;
		}
		if($order){
			$sql .= $order;
		}
		if($limit)
			$sql .= "LIMIT ". $limit;
			
		$this->last_query = $sql;
			
		$result = mysql_query($sql);
		return mysql_num_rows($result);
	}
	
	public function fetchRecodQuery($sql){
		$data = array();
		if($sql){
			$this->last_query = $sql;
			$result = mysql_query($sql);
				if(mysql_num_rows($result) > 0 ){
					if($this->type == 'object'){
						
						while($row = @mysql_fetch_object($result)){
							$data[] = $row;
						}
					}else {
						while($row = mysql_fetch_assoc($result)){
							$data[] = $row;
						}
					}
					return $data;
				}
				else{
					
					return FALSE;	
				} 
			}
			return FALSE;
						
		}
	
	
	function getAll($tbl,$filed = '*',$where = NULL ,$order = NULL , $limit = NULL ){
		$sql = "SElECT " .$filed . " FROM ".$tbl ." WHERE 1 = 1";
		
		if(isset($where) && $where != NULL){
			$sql .= " AND ". $where;
		}
		if($order){
			$sql .= $order;
		}
		if($limit)
			$sql .= "LIMIT ". $limit;
		return $this->fetchRecodQuery($sql);
		
	}

	function getSingle($tbl,$filed = '*',$where = NULL ,$order = NULL , $limit = NULL ){
	
		$sql = "SELECT $filed FROM ".$tbl ." WHERE 1 = 1 ";
		
		if(isset($where) && $where != NULL){
			$sql .= " AND ".$where;
		}
		if($order){
			$sql .= $order;
		}
		if($limit)
			$sql .= " LIMIT ".$limit;
			
			$data = $this->fetchRecodQuery($sql);
			return $data[0];
	}
	
	
	public function insert($table, $data) {
		$q="INSERT INTO `".$this->_pre.$table."` ";
		$v=''; $n='';
		
		foreach($data as $key=>$val) {
			$n.="`$key`, ";
			if(strtolower($val)=='null') $v.="NULL, ";
			elseif(strtolower($val)=='now()') $v.="NOW(), ";
			else $v.= "'".$this->escape($val)."', ";
		}
		
		$q .= "(". rtrim($n, ', ') .") VALUES (". rtrim($v, ', ') .");";
		  
		
		if(mysql_query($q)){
			$this->free_result();
			return mysql_insert_id();
		}else {
			return false ;
		}
	}
	
	public function free_result($query_id=-1) {
		if ($query_id!=-1) {
			$this->last_query = $query_id;
		}
		if(!@mysql_free_result($this->last_query)) {
			//$this->oops("Result ID: <b>$this->query_id</b> could not be freed.");
		}
	}
	
	public function query_update($table, $data, $where='1') {
	$q="UPDATE `".$table."` SET ";
	foreach($data as $key=>$val) {
		if(strtolower($val)=='null') $q.= "`$key` = NULL, ";
		elseif(strtolower($val)=='now()') $q.= "`$key` = NOW(), ";
		else $q.= "`$key`='".$this->escape($val)."', ";
	}

	$q = rtrim($q, ', ') . ' WHERE '.$where.';';
	/*print $q;
	exit;*/
	$this->last_query = $q;
	if(mysql_query($q))
		return true;
	else
		return FALSE;		
	
	}
	
	public function escape($string) {
		if(get_magic_quotes_gpc())
			$string = stripslashes($string);
		return mysql_real_escape_string($string);
	}

	
}

?>


