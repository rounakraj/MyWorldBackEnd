 <?php
class AuthLogin{
    var $CI;
	 function AuthLogin() {
        $this->CI =& get_instance();
    }
    
	function session_check() {
		$class =  $this->CI->router->fetch_class();
		$auth_class = array('Student','Leader','QuizExam','Forum');
		
		$admin_auth_class = 'login';
		
		if(strpos($this->CI->uri->uri_string ,'admin') !== FALSE){
			if(!$this->CI->session->userdata("logged_in") && $class != $admin_auth_class ) {	
		 		redirect('admin/login', 'refresh'); 
			}
        }else{
			return TRUE;
			exit;
		}
		
		if(in_array($class,$auth_class)){
			if(!$this->session->userdata('member_login')){
				redirect('login','refresh');
			}
		}else{
			return TRUE;
			exit;
		}
		
	}
}
?>  
