$(function(){

$('select.styled').customSelect();

});
