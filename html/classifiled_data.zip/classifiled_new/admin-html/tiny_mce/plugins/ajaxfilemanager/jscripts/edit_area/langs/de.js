editAreaLoader.lang["de"]={
new_document: "neues leeres Dokument",
search_button: "suchen und ersetzen",
search_command: "suche n&auml;chsten / &ouml;ffne Suchfeld",
search: "suche",
replace: "ersetze",
replace_command: "ersetze / &ouml;ffne Suchfeld",
find_next: "finde n&auml;chsten",
replace_all: "ersetze alle Treffer",
reg_exp: "regul&auml;re Ausdr&uuml;cke",
match_case: "passt auf den Begriff<br />",
not_found: "Nicht gefunden.",
occurrence_replaced: "Die Vorkommen wurden ersetzt.",
search_field_empty: "leeres Suchfeld",
restart_search_at_begin: "Ende des zu durchsuchenden Bereiches erreicht. Es wird die Suche von Anfang an fortgesetzt.", //find a shorter translation
move_popup: "Suchfenster bewegen",
font_size: "--Schriftgr&ouml;&szlig;e--",
go_to_line: "gehe zu Zeile",
go_to_line_prompt: "gehe zu Zeilennummmer:",
undo: "r&uuml;ckg&auml;ngig machen",
redo: "wiederherstellen",
change_smooth_selection: "aktiviere/deaktiviere einige Features (weniger Bildschirmnutzung aber mehr CPU-Belastung)",
highlight: "Syntax Highlighting an- und ausschalten",
reset_highlight: "Highlighting zur&uuml;cksetzen (falls mit Text nicht konform)",
help: "&uuml;ber",
save: "sichern",
load: "&ouml;ffnen",
line_abbr: "Ln",
char_abbr: "Ch",
position: "Position",
total: "Gesamt",
close_popup: "Popup schlie&szligen",
shortcuts: "Shortcuts",
add_tab: "Tab zum Text hinzuf&uuml;gen",
remove_tab: "Tab aus Text entfernen",
about_notice: "Bemerkung: Syntax Highlighting ist nur f&uuml;r kurze Texte",
toggle: "Editor an- und ausschalten",
accesskey: "Accesskey",
tab: "Tab",
shift: "Shift",
ctrl: "Ctrl",
esc: "Esc",
processing: "In Bearbeitung...",
fullscreen: "fullscreen"
};
